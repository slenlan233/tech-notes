1. NIO 编程三个组件

   1. 缓冲区Buffer

      1. 是一个数组对象，通常是一个字节数组ByteBuffer
      2. 所有数据都是用缓冲区处理的：在读取数据时，它是直接读到缓冲区中的；在写入数据时，写入缓冲区中
   2. 通道Channel

      1. 创建一个channel，就可以直接read/write，不用像socket一样需要再new一个inputstream
      2. ChannelPipeLine是Channel对象的一个成员变量（属性）

         1. **ChannelPipeline** 就是一个 **处理链（Chain of Responsibility）** ，或者说是一个 **容器**。

            - **容器里装着什么？**  它里面装着一串有序的 ​**​`ChannelHandler`​**​ **（处理器）** 。
            - **它的作用是什么？**  它的作用就是拦截并处理在这个 Channel（通道）上发生的各种事件（比如“数据来了”、“连接连上了”、“出现异常了”）。

            简单来说，​**ChannelPipeline 就是掌管数据如何被一步步处理的“总管”** 。
         2. 为什么叫 Pipeline (流水线/管道)？

            想象一下工厂里的​**流水线**​，或者你坐飞机时的​**安检通道**。

            1. **有序性**​：数据就像传送带上的货物，必须**按顺序**经过一个个工位（Handler）。
            2. **分工明确**：

               - 第一个工位负责​**拆包**（解决你刚才问的半包问题）。
               - 第二个工位负责​**把字节变成对象**（解码）。
               - 第三个工位负责​**业务逻辑**（比如判断密码对不对）。
               - 第四个工位负责​**加密**（把发出去的消息加密）。
            3. **灵活插拔**：如果你想增加一个“压缩数据”的功能，只需要在流水线上插一个“压缩处理器”即可，不用修改其他代码。

            这种“一个接一个处理”的模式，就叫 Pipeline。
         3. 它的流程是什么？（最关键的部分）

            ChannelPipeline 里的流程分为两个方向：**入站（Inbound）**  和 ​**出站（Outbound）** 。

            想象一个 U 形的管道，或者进出两用的关口。

            #### (1) 入站流程 (Inbound) —— “读数据”

            **方向：从底向上（Head ->**  **Tail）** 当网络那边发来数据时：

            1. 数据首先到达 ​**Socket**。
            2. 进入 Pipeline 的 ​**Head（头部）** 。
            3. **Handler A (解码器)** ：先把二进制流转成字符串。
            4. **Handler B (业务逻辑)** ：处理字符串，比如打印出来。
            5. 到达 ​**Tail（尾部）** ，处理结束。

            - **比喻**​：快递寄到你家 -\> 拆快递箱 -\> 拿出商品 -\> 使用商品。

            #### (2) 出站流程 (Outbound) —— “写数据”

            **方向：从顶向下（Tail ->**  **Head）** 当你写代码 `ctx.write("Hello")` 时：

            1. 数据从 **Tail（尾部）**  或者你当前的 Handler 开始。
            2. **Handler C (编码器)** ：把字符串 "Hello" 转成二进制字节。
            3. **Handler D (加密器)** ：给字节加密。
            4. 到达 ​**Head（头部）** 。
            5. 最后真正写入底层的 ​**Socket**，发给网线。

            - **比喻**​：你打包商品 -\> 封箱 -\> 贴快递单 -\> 快递员拿走。
         4. 总结图解

            ```plaintext
                   I/O 请求 (网络数据)
                         |
                         v
                +---------------------------+
                |      ChannelPipeline      |
                |                           |
                |  +---------------------+  |
                |  | Inbound Handler  1  |  |  <--- 1. 解码 (字节变对象)
                |  +----------+----------+  |
                |             |             |
                |             v             |
                |  +---------------------+  |
                |  | Inbound Handler  2  |  |  <--- 2. 业务处理 (你的代码在这里)
                |  +----------+----------+  |
                |             |             |
                |             | 你的代码调用 write()
                |             v             |
                |  +---------------------+  |
                |  | Outbound Handler 2  |  |  <--- 3. 编码 (对象变字节)
                |  +----------+----------+  |
                |             |             |
                |             v             |
                |  +---------------------+  |
                |  | Outbound Handler 1  |  |  <--- 4. 加密/压缩
                |  +----------+----------+  |
                |                           |
                +-------------+-------------+
                              |
                              v
                         I/O 输出 (发给网线)
            ```

            **一句话总结：ChannelPipeline 就是数据进出的大管家，它让数据像过安检一样，按顺序经过一个个处理器（Handler），把复杂的网络操作（拆包、解码、加密）拆解成一个个简单的小步骤。**
         5. **获取方式**：`channel.pipeline()`

            ### 1. 刚开始组装流水线时（初始化）

            这是最常见的地方。当你写 Netty 启动代码时，你需要告诉程序：“这个连接建立后，流水线上要放哪些工人（Handler）？”

            ```java
            // 在 ServerBootstrap 的配置里
            .childHandler(new ChannelInitializer<SocketChannel>() {
                @Override
                public void initChannel(SocketChannel ch) {
                    // 【看这里】：从 Channel 里拿到了 pipeline
                    ChannelPipeline pipeline = ch.pipeline(); 
                    
                    // 往流水线上放工人
                    pipeline.addLast(new HttpServerCodec()); // 放一个翻译官
                    pipeline.addLast(new MyBusinessHandler()); // 放一个处理业务的
                }
            });
            ```

            ### 2. 在业务处理过程中（动态修改）

            你在 Handler 的代码里也能拿到它。比如你想根据不同情况动态调整流水线（比如登录成功后，才把“聊天处理器”加进去）。

            ```java
            public class LoginHandler extends ChannelInboundHandlerAdapter {
                @Override
                public void channelRead(ChannelHandlerContext ctx, Object msg) {
                    // 【看这里】：可以通过上下文（ctx）拿到 pipeline
                    ChannelPipeline pipeline = ctx.pipeline();
                    
                    if (loginSuccess) {
                        // 登录成功了，往流水线后面加个聊天处理器
                        pipeline.addLast(new ChatHandler());
                    }
                }
            }
            ```
      3. `writeAndFlush`​ \= **​`write`​**​  **(写入缓冲区)**  + **​`flush`​**​  **(推送到内核/网络)** 。

         它是 Netty 追求极致性能的体现，利用了缓冲（Buffering）机制来减少昂贵的系统调用。

         1. 核心拆解：Write vs. Flush

            #### 第一步：`write()` —— 仅仅是“暂存”

            当你调用单纯的 `write(msg)`​ 时，​**数据并没有被发送到网络上**，甚至没有离开 Java 虚拟机的内存。

            - **动作**​：Netty 会把你的数据（`ByteBuf`​）指针添加到一个内部的 **出站缓冲区 (ChannelOutboundBuffer)**  链表中。
            - **位置**​：完全在 **用户态 (User Space)**  内存中。
            - **耗时**：极短，几乎仅仅是链表操作。

            #### 第二步：`flush()` —— 真正的“发送”

            当你调用 `flush()` 时，Netty 才会真正干活。

            - **动作**​：它会把 `ChannelOutboundBuffer`​ 里积攒的所有数据，通过 JNI 调用底层的操作系统函数（如 Linux 的 `write`​ 或 `send` 系统调用）。
            - **流向**​：数据从 **用户态 (User Space)**  拷贝到 **内核态 (Kernel Space)**  的 ​**TCP 发送缓冲区 (TCP Send Buffer)** 。
            - **后续**：一旦进入内核的 TCP 发送缓冲区，操作系统网络协议栈就会负责把数据通过网卡发给对方（涉及 TCP 滑动窗口、拥塞控制等）。
         2. 为什么要分开？（CS 视角的性能考量）

            既然是为了发数据，为什么不直接每次都发？为什么要搞个“缓冲区”？

            **核心原因：减少系统调用 (System Call) 的开销。**

            - **背景**：在操作系统中，从用户态切换到内核态（Context Switch）是非常消耗 CPU 资源的。
            - **场景**：假设你要发 1000 个小字符串。

              - **方案 A (没有 buffer)** ：调用 1000 次系统调用。CPU 在用户态和内核态之间疯狂横跳，效率极低。
              - **方案 B (Netty 的做法)** ​：先调用 1000 次 `write()`​（在用户态内存里排队，很快），然后调用 1 次 `flush()`。这 1000 个数据包会被打包，只触发 1 次或极少次的系统调用，一次性搬运给内核。

            **​`writeAndFlush()`​** ​ **就是这两个动作的原子结合体**。它适用于：“我这条数据很重要，或者这是最后一条数据了，请立刻发出去，不要等了。”
         3. 异步机制：它不保证“对方收到”

            你需要特别注意：`writeAndFlush`​ 是 **异步 (Asynchronous)**  的。

            - 当你这行代码 `ctx.channel().writeAndFlush(...)`​ 执行完并返回时，​**并不代表数据已经发到客户端了**，甚至不代表数据已经写到网卡了。
            - **它只代表**：任务已经提交给 Netty 的 IO 线程了。
            - **返回值**​：它会返回一个 `ChannelFuture` 对象。如果你想知道发送是否成功，或者发送完后做点什么（比如关闭连接），你需要给这个 Future 添加监听器：

            ```java
            // 标准写法：发送完毕后，关闭连接
            ctx.writeAndFlush("Bye").addListener(ChannelFutureListener.CLOSE);
            ```
         4. 进阶细节：`ctx.channel().writeAndFlush`​ vs `ctx.writeAndFlush`

            细心的你可能发现，代码里写的是 `ctx.channel().writeAndFlush(...)`​，但有时你会看到别人直接写 `ctx.writeAndFlush(...)`。

            这在 Pipeline 机制里有巨大的区别：

            1. **​`ctx.channel().writeAndFlush(msg)`​** ​  **(你代码里的)** ：

               - **从头开始**​：它会让消息从 Pipeline 的 **尾部 (Tail)**  开始，**倒着** 经过所有的 `OutboundHandler`（编码器等），最后发出去。
               - **覆盖范围**：整个流水线。
            2. **​`ctx.writeAndFlush(msg)`​** ：

               - **从当前位置开始**​：它会让消息从 **当前 Handler** 的 **上一个** `OutboundHandler` 开始往前传。
               - **覆盖范围**：当前节点之前的流水线。如果你在流水线中间截获处理，这很有用。

            **总结**​：`writeAndFlush`​ 是 Netty 发送数据的标准姿势。它先在用户内存中排队（Write），然后批量触发系统调用（Flush），以此在**高吞吐量**和**低延迟**之间找到平衡。
      4. 同一个 Pipeline 里通常既有解码器（Decoder）又有编码器（Encoder）。数据编码发送**是自动跳过解码器的。**  因为 Netty 把“读操作”和“写操作”分成了两条完全不同的逻辑路径（Inbound 和 Outbound），它们虽然在同一个 Pipeline 结构里，但互不干扰。

         1. 核心机制：Inbound 和 Outbound

            在 Netty 中，所有的 Handler 被强制分成了两类（通过接口定义）：

            - **InboundHandler (入站处理器)** ​：只关心 **进来的** 数据（读数据、解码）。例如：`FrameDecoder`​, `SimpleServerHandler`。
            - **OutboundHandler (出站处理器)** ​：只关心 **出去的** 数据（写数据、编码）。例如：`StringEncoder`​, `LengthFieldPrepender`。

            虽然你在代码里是按顺序 `addLast`​ 把它们加进去的，但在 Netty 内部，Pipeline 其实维护了一个​**双向链表**。
         2. 实际场景演示：一个典型的 Pipeline

            假设你的 Pipeline 配置如下（注意顺序）：

            ```java
            // 这是一个常见的“全家桶”配置
            pipeline.addLast(new StringDecoder()); // 1. 解码器 (Inbound)
            pipeline.addLast(new StringEncoder()); // 2. 编码器 (Outbound)
            pipeline.addLast(new BizHandler());    // 3. 你的业务逻辑 (Inbound)
            ```

            **物理结构（双向链表）** ​：`Head`​ \<-\> `StringDecoder`​ \<-\> `StringEncoder`​ \<-\> `BizHandler`​ \<-\> `Tail`

            现在，让我们看看数据是怎么跑的。

            #### 1. 读数据（Inbound 流向）：从头到尾

            当客户端发来数据时，事件是 **从 Head 往 Tail** 传播的。

            1. **Head** 收到二进制数据。
            2. **找下一个 InboundHandler** -\> 也就是 `StringDecoder`。

               - `StringDecoder` 把字节变成字符串。
            3. **找下一个 InboundHandler** -\> ​**注意！这里会自动跳过** **​`StringEncoder`​**。

               - 为什么？因为 `StringEncoder` 是 OutboundHandler，Netty 发现类型不匹配，直接忽略，继续往下找。
            4. **找到** **​`BizHandler`​**。

               - 执行你的业务逻辑。

            #### 2. 写数据（Outbound 流向）：从尾到头（关键！）

            当你在 `BizHandler`​ 里调用 `ctx.writeAndFlush("Hello")`​ 时，事件是 **从当前位置往 Head（反向）**  传播的。

            1. **BizHandler** 发起写操作。
            2. **往回找（向 Head 方向）下一个 OutboundHandler** -\> 也就是 `StringEncoder`。

               - `StringEncoder` 捕获到这个写操作。
               - 它把 "Hello" 编码成 `ByteBuf`。
               - 它调用 `ctx.write(encodedData)` 继续往前传。
            3. **继续往回找下一个 OutboundHandler** -\> ​**注意！这里会自动跳过** **​`StringDecoder`​**。

               - 为什么？因为 `StringDecoder` 是 InboundHandler，它只管进不管出，Netty 直接忽略它。
            4. **找到 Head**。

               - Head 是特殊的，它既处理 Inbound 也处理 Outbound。它负责把最终的 `ByteBuf` 真正写入 Socket 的发送缓冲区。
         3. 为什么能“自动”跳过？

            这不是魔法，是 Netty 的 `AbstractChannelHandlerContext` 里的代码逻辑实现的。

            当你调用 `write()` 时，Netty 内部会运行类似这样的逻辑（伪代码）：

            ```java
            // 寻找上一个 OutboundHandler
            private ChannelHandlerContext findContextOutbound(ChannelHandlerContext ctx) {
                Context current = ctx;
                do {
                    current = current.prev; // 往前找前驱节点
                } while (!current.handler().isOutbound()); // 如果不是 Outbound 类型的 Handler，就继续往前找，直到找到为止
                return current;
            }
            ```

            正是这个 `while` 循环，保证了：

            - **写数据时**​：所有 `InboundHandler`（解码器）会被当作透明的空气，直接穿透。
            - **读数据时**：所有 `OutboundHandler`（编码器）也会被当作透明的，直接穿透。
         4. 总结：虽然代码写在一起，但运行时它们是在不同的“图层”上工作的，所以：

            - **编码发送时，绝对不会经过解码器。**
            - **解码读取时，绝对不会经过编码器。**
      5. `StringEncoder`​就是二进制转换器，因为是主动方，自己知道哪里结束，所以不用加**​`DelimiterBasedFrameDecoder`​**（分隔符帧解码器）了

         1. `StringEncoder` 到底是干嘛的？它就是那个“二进制转换器”！

            你问：“不也应该转换为二进制才能发出去吗？”

            **答案是：是的！而** **​`StringEncoder`​**​ **做的正是这件事。**

            在 Netty 里，网络传输的底层载体是 `ByteBuf`（字节容器）。

            - 如果你直接写 `ctx.writeAndFlush("你好")`​，Netty 会报错，因为它看不懂 `String`​，它只认 `ByteBuf`。
            - **​`StringEncoder`​**​ **的作用**​：它拦截下你传过来的 `String`​，把它按照指定的编码（比如 UTF-8）转换成 `byte[]`​，然后封装进 `ByteBuf` 里传给下一棒。

            **所以：**

            > **StringEncoder**  **=**  **把 String 变成 二进制 (ByteBuf)**
            >

            如果没有它，你就得自己写：

            ```java
            // 如果没有 StringEncoder，你得这么写，累死人：
            byte[] bytes = "你好".getBytes(CharsetUtil.UTF_8);
            ByteBuf buf = Unpooled.wrappedBuffer(bytes);
            ctx.writeAndFlush(buf);
            ```

            有了它，你只需要写 `ctx.writeAndFlush("你好")`。
         2. 为什么不用加“Deli” (Delimiter) 那个 Encoder？

            你提到的“Deli什么”，应该是 ​**​`DelimiterBasedFrameDecoder`​**（分隔符帧解码器）。

            这里有一个​**巨大的误区**​，也是新手最容易晕的地方：**发送（Outbound）和接收（Inbound）的不对称性。**

            #### **场景 A：接收数据 (Inbound) —— 需要“Deli”**

            当你**收**数据时，TCP 是流式的（像水流一样），数据可能粘在一起（粘包）或者断开（半包）。

            - Netty 收到一堆 `010101`，它不知道一句话在哪里结束。
            - 所以你需要 ​**​`DelimiterBasedFrameDecoder`​**​。它的作用是：“盯着水流，一旦看到 `\n` 或者特殊符号，就切一刀，把这一段作为完整消息递给后面”。
            - **它是用来“切”二进制流的。**

            #### **场景 B：发送数据 (Outbound) —— 不需要“Deli Encoder”**

            当你**发**数据时，情况完全不同：

            - 你是​**主动方**​。你手里拿着完整的字符串 `"Hello World\n"`。
            - 你知道这句话在哪里结束（就是字符串末尾）。
            - 你不需要一个专门的 Encoder 去“寻找分隔符”，因为​**你只需要把这串字符变成字节发出去就行了**。

            **关键点：** 如果你和对方约定用 `\n`​ 作为分隔符，那你发送的时候，​**只要确保你的字符串最后带着**  **​`\n`​**​ **就行了**，或者手动用代码加一个。

            Java

            ```
            // 发送端逻辑
            // 方式 1：手动加分隔符，然后由 StringEncoder 转二进制
            ctx.writeAndFlush("Hello World" + "\n"); 

            // 方式 2：确实有个东西叫 LineEncoder
            // 如果你懒得手动加 \n，可以加一个 LineEncoder，它会自动在末尾补一个换行符，再转二进制。
            // 但 StringEncoder 更加通用。
            ```
      6. ### 第一行：正式开张

         ```java
         ChannelFuture f = bootstrap.bind(8080).sync();
         ```

         - **​`bootstrap.bind(8080)`​** ​: 这是告诉 Netty：“去占用 8080 端口，准备接客！”。 但这只是一个**异步**指令。就像你对员工喊了一句“去开门”，员工可能还在走过去的路上，门还没真正打开。
         - **​`.sync()`​** ​  **(同步等待)** ​: 这是关键。它的意思是： **“我就在这里等着，直到门完全打开为止。”**

           - 如果没有 `.sync()`，代码会直接往下跑，可能门还没开好，你就开始做后面的事了，会出问题。
           - 如果端口被占用（比如已经有一个 Tomcat 在跑了），这一步就会抛出异常，程序直接报错停止。
         - **​`ChannelFuture f`​**​: 这相当于你拿到了一个“凭证”，代表了这次“绑定端口”的操作结果。里面包裹的是那个 **唯一的、负责监听的** **​`ServerSocketChannel`​**，而不是某个具体的客户端连接。
         - 前半句：“占用8080端口开始监听”

           **完全正确。**

           - **动作**​：`bootstrap.bind(8080)` 这行代码执行时，Netty 会调用底层 JDK 的 API，向操作系统申请占用 8080 端口。
           - **结果**​：此时创建的是 ​**​`NioServerSocketChannel`​**​（注意多了 *Server* 两个字）。
           - **比喻**：这相当于  **“餐厅的大门打开了，迎宾员（Boss Group）站在门口开始工作了”** 。
         - 后半句：“监听到就创建 socketchannel”

           **逻辑是对的，但要注意发生的时机。**

           - **这行代码执行完时**​：并**没有**创建 `SocketChannel`​。此时只有 `ServerSocketChannel`（监听通道）在运行。
           - **什么时候创建？** ​：是在​**未来的某个时间点**，当真正的客户端（比如手机、浏览器）发起 TCP 连接，并且三次握手成功后。
           - **谁创建的？** ​：是你的 `parentGroup`​（Boss 线程）发现有连接进来了（Accept 事件），它才会去创建一个新的 ​**​`NioSocketChannel`​**（客户端通道）。
         - `f.get()`​ 确实存在，它和 `.sync()` 一样，都能让线程死等（阻塞）在那里

           - 姿势一：死等派之 `.sync()` (Netty 推荐)

             ```java
             // 线程走到这就停了，像被定身了一样，直到连接建立成功或失败
             ChannelFuture f = bootstrap.connect(host, port).sync();
             ```

             - **特点**：阻塞（Blocking）。
             - **异常处理**​：如果连接失败，它会​**直接抛出运行时异常**​（Unchecked Exception）。这在 Netty 编程中很方便，因为不需要你写一大堆 `try-catch`。
             - **返回值**：返回 `ChannelFuture` 对象本身，方便你后面继续写点（链式调用）。
           - 姿势二：死等派之 `.get()` (JDK 原生风格)

             这就是你刚才问的方法。因为 Netty 的 `Future`​ 继承自 Java 原生的 `java.util.concurrent.Future`​，所以它当然有 `get()`。

             ```java
             try {
                 // 线程也走到这就停了，死等结果
                 Void result = f.get(); 
             } catch (InterruptedException | ExecutionException e) {
                 // 麻烦点：你必须强制处理这些“检查型异常”
                 e.printStackTrace();
             }
             ```

             - **特点**：阻塞（Blocking）。
             - **异常处理**​：​**很麻烦**​。Java 强制要求你捕获 `InterruptedException` 等异常，代码写起来显得很啰嗦。
             - **返回值**：返回操作的结果（对于连接操作，通常是 null）。
             - **结论**：**虽然能用，但在 Netty 代码里大家很少这么写**，因为 `.sync()` 更简洁，处理异常更符合 Netty 的风格。
           - 姿势三：通知派 (真正的异步)

             这就是你说的“只有准备好了通知这个线程”。

             如果你不想让主线程卡住（比如你在做一个高并发的网关，主线程很宝贵，不能傻等），你就不能用 `sync()`​ 也不用 `get()`​，而是用 **回调（Callback/Listener）** 。

             ```java
             ChannelFuture f = bootstrap.connect(host, port);

             // 此时主线程直接“路过”，根本不停车！
             // 你只是给这个 Future 贴了一张便利贴（Listener）
             f.addListener(new ChannelFutureListener() {
                 @Override
                 public void operationComplete(ChannelFuture future) {
                     if (future.isSuccess()) {
                         System.out.println("嘿！连接成功了！我是被系统通知回调的！");
                         // 在这里拿到 channel 发数据
                         future.channel().writeAndFlush("Hello");
                     } else {
                         System.out.println("完蛋，连接失败了！");
                     }
                 }
             });

             System.out.println("主线程已经跑去做别的事了...");
             ```

             - **特点**​：​**非阻塞**。
             - **场景**：这才是 Netty 高性能的灵魂。
           - 那要是不用前两种，但在后面想要用时还没准备好系统还没通知线程呢

             这就是一个非常经典的“竞态条件”（Race Condition）问题！

             或者用更通俗的话说：​**你在赌博**。

             如果你不用 `sync()`​（死等），也不用 `addListener`（回调通知），而是像下面这样写代码：

             ```java
             // 1. 发起连接（动作非常快，马上返回，此时还没连上）
             ChannelFuture f = bootstrap.connect(host, port); 

             // 2. 你的业务逻辑（假设这里耗时 50ms）
             doSomethingElse();

             // 3. 你突然想起来要发数据了，直接拿 channel 用
             // 此时系统可能还没连上（还没通知到位）
             Channel channel = f.channel(); 
             channel.writeAndFlush("Hello");
             ```

             这时候会发生什么？会有三种情况，我们称之为“薛定谔的连接”。

             ---

             - 情况一：你赌赢了（运气好）

               在你执行 `doSomethingElse()` 的那 50ms 里，Netty 的后台线程正好把连接建立好了。

               - 当你执行第 3 步时，`channel.isActive()`​ 已经是 `true` 了。
               - **结果**：数据顺利发送，风平浪静。
             - 情况二：你赌输了——连接还没好（缓冲）

               这是你最关心的情况：​ **“后面想要用时还没准备好”** 。

               - **​`f.channel()`​** ​ **能拿到对象吗？**

                 - **能！**  因为 Netty 在发起连接的**一瞬间**就已经把 `Channel`​ 对象创建出来了（虽然它是“未激活”状态）。所以你不会遇到 `NullPointerException`。
               - **​`writeAndFlush`​**​ **会报错吗？**

                 - **不会报错！**  Netty 的设计非常健壮。
               - **那数据去哪了？**

                 - Netty 发现这个 Channel 还没连接成功（`Active`​ 状态为 false），它会把你发的数据暂时​**存放在内存里的一个队列中**​（术语叫 `ChannelOutboundBuffer`）。
                 - **后续剧情 A**​：过了一会儿，连接**成功**了。Netty 会自动把队列里的数据“冲”出去（Flush）。（看起来好像没问题，对吧？）
                 - **后续剧情 B**​：过了一会儿，连接**失败**了（比如对方拒绝连接）。Netty 会清空队列，把你刚才写的数据全部丢弃，并标记这次写入失败。

               **这就是风险所在！**  如果你这时没去检查写入结果（没看 `writeAndFlush`​ 返回的 Future），你的数据就​**悄无声息地丢了**，而你还以为发出去了。
             - 情况三：你赌输了——连接彻底失败

               在你执行第 2 步的时候，连接已经因为网络原因直接断了（Closed）。

               - 这时你再调用 `writeAndFlush`。
               - **结果**​：Netty 可能会直接拒绝写入，或者写入后的 Future 立刻返回失败异常（`ClosedChannelException`）。
             - 总结：为什么千万别这么写？

               虽然 Netty 有缓存机制（情况二）帮你兜底，但在 SSP 级别的开发中，这种写法是​**大忌**。

               因为你失去了“确定性”。

               1. **你不知道数据是立马发出去了，还是被缓存了。**
               2. **如果连接最终失败了，你刚才发的数据就成了“孤魂野鬼”，你很难在一个统一的地方处理这些丢包逻辑。**
             - 正确的“非阻塞”写法

               如果你真的不想 `sync()`​ 阻塞，又想在“后面”某个时刻用，你必须在用之前​**检查状态**：

               ```java
               ChannelFuture f = bootstrap.connect(host, port);

               // ... 过了一会儿 ...

               Channel channel = f.channel();

               // 必须加判断！
               if (channel.isActive()) { 
                   // 只有连接是活的，我才发
                   channel.writeAndFlush("Hello");
               } else {
                   // 如果还没好，或者挂了，我要么存起来下次发，要么报错
                   System.out.println("还没连上呢，别急！");
                   
                   // 或者你可以亡羊补牢，在这时候追加一个监听器
                   f.addListener(future -> {
                       if (future.isSuccess()) {
                            future.channel().writeAndFlush("Hello (迟到的发送)");
                       }
                   });
               }
               ```

               **一句话总结：** 不用 `sync`​ 也不用 `Listener` 直接硬用，就像“没看红绿灯直接过马路”。 虽然车（Netty）看到了你会刹车（缓存数据），但万一刹不住（连接失败），你也得承担后果（丢包）。
           - 总结

             回到你的问题：

             1. **可以用** **​`f.get()`​** ​ **吗？**

                - **可以**​。效果和 `sync()`​ 几乎一样，都会把线程**阻塞**在当前行。
                - 区别只是 `get()` 的异常处理更麻烦，且不返回 Future 对象本身。
             2. **不加 sync 也不加 get 会怎样？**

                - 那代码会**瞬间**执行下去。
                - 这时候 `f` 代表的连接可能还没建立好。
                - 如果你没加 `Listener`​（通知），也没 `sync`​（死等），那你就像发了个快递却没留电话也没拿单号，快递到了还是丢了你都​**完全不知道**。

         ### 第二行：守店（防止程序退出）

         ```java
         f.channel().closeFuture().sync();
         ```

         这行代码是初学者最容易晕的地方。它的作用是 ​**让主线程阻塞（暂停）在这里，不要结束程序**。

         - **为什么要写这行？** Netty 的服务器是运行在独立的线程（NioEventLoop）里的。如果 `main`​ 方法里没有这行代码，主线程（Main Thread）跑完上一行 `bind` 之后，就会认为“没事做了”，然后直接退出。主线程一退出，整个 Java 程序可能就关掉了，服务器也就挂了。
         - **​`f.channel().closeFuture()`​** ​: 这句话的意思是： **“获取那个‘店铺倒闭（关闭）’的信号。”**

           - 注意：它**不是**去关闭服务器！它是去​**获取**“关闭”这个事件的通知对象（Future）。
         - **​`.sync()`​** ​: 再次出现 `sync`​。在这里它的意思是： **“一直等着，直到我收到‘店铺倒闭’的信号为止。”**

           - 因为你的服务器在正常运行中是不会倒闭的，所以这个等待会​**一直持续下去**（死等）。
           - 这就强行把主线程“卡”在这里，让它别结束，从而保证服务器一直运行。
   3. 多路复用器Selector

      1. Selector会不断地轮询注册在其上的Channel，如果某个Channel上面发生读或者写事件，这个Channel就处于就绪状态，会被Selector轮询出来，然后通过SelectionKey可以获取就绪Channel的集合，进行后续的I/O操作。
      2. 一个多路复用器Selector可以同时轮询多个Channel，由于JDK使用了epoll()代替传统的select实现，所以它并没有最大连接句柄1024/2048的限制。这也就意味着只需要一个线程负责Selector的轮询，就可以接入成千上万的客户端，这确实是个非常巨大的进步。
2. TCP 粘包/拆包问题

   1. TCP 粘包/拆包：发出去两个数据包，如果读取到两个独立的则没有粘包或拆包；如果两个数据包粘合在一起，称为TCP粘包；如果一次完整的D1和部分D2，一次D2剩余部分，则称为TCP拆包
   2. 原因：

      1. 应用程序write写入的字节大小大于套接口发送缓冲区大小
      2. 进行MSS大小的TCP分段
      3. 以太网帧的payload大于MTU进行IP分片
   3. 解决策略：由于底层的TCP无法理解上层的业务数据，所以在底层是无法保证数据包不被拆分和重组的，这个问题只能通过上层的应用协议栈设计来解决，根据业界的主流协议的解决方案，可以归纳如下。

      1. 消息定长，例如每个报文的大小为固定长度200字节，如果不够，空位补空格；
      2. 在包尾增加回车换行符进行分割，例如FTP协议；
      3. 将消息分为消息头和消息体，消息头中包含表示消息总长度(或者消息体长度)的字段，通常设计思路为消息头的第一个字段使用int32来表示消息的总长度；
      4. 更复杂的应用层协议。
   4. LineBasedFrameDecoder解决TCP粘包问题（换行）

      1. LineBasedFrameDecoder的工作原理是它依次遍历 ByteBuf 中的可读字节，判断看是否有"n"或者"\r\n"，如果有，就以此位置为结束位置，从可读索引到结束位置区间的字节就组成了一行。它是以换行符为结束标志的解码器，支持携带结束符或者不携带结束符两种解码方式，同时支持配置单行的最大长度。如果连续读取到最大长度后仍然没有发现换行符，就会抛出异常，同时忽略掉之前读到的异常码流。
      2. StringDecoder的功能非常简单，就是将接收到的对象转换成字符串，然后继续调用后面的Handler。LineBasedFrameDecoder+StringDecoder组合就是按行切换的文本解码器，它被设计用来支持TCP的粘包和拆包。
   5. 分隔符和定长解码器的应用

      1. DelimiterBasedFrameDecoder自动完成以分隔符做结束标志的解码

         1. `ByteBuf delimiter = Unpooled.copiedBuffer("$_".getBytes());`

            **把**  **​`$_`​** ​ **这个字符串，先翻译成机器能懂的“二进制”，然后打包成 Netty 专用的“数据包”格式。**

            为了让你彻底明白，我们由内向外把这行代码拆成**三个步骤**来看：

            ### 第一步：`"$_".getBytes()` —— 翻译

            - **动作**​：把人类能看懂的文字 `$_`​，转换成机器能看懂的​**二进制字节数组**。
            - **为什么**：计算机网络传输底层不认“字符串”，只认 0 和 1（字节）。
            - **结果**：

              - 字符 `$`​ 在计算机里对应的数字是 ​**36**。
              - 字符 `_`​ 在计算机里对应的数字是 ​**95**。
              - 所以这一步其实得到是一个数组：`[36, 95]`。

            ### 第二步：`Unpooled.copiedBuffer(...)` —— 打包

            - **动作**​：把上面那个简陋的数组 `[36, 95]`​，**包装**进 Netty 专用的容器里。
            - **为什么**​：Netty 的组件（比如后面那个解码器）非常高级，它不接受普通的 Java 数组，它只接受一种叫 `ByteBuf` 的对象。
            - **类比**：

              - `[36, 95]`​ 就像是散装的​**两颗鸡蛋**。
              - Netty 的流水线就像是一个​**自动化传送带**。
              - 你不能把散装鸡蛋直接扔传送带上（会碎/不好处理），你需要用一个**专门的托盘**把鸡蛋装好。
              - `Unpooled.copiedBuffer` 就是这个“拿托盘装鸡蛋”的动作。

            ### 第三步：`ByteBuf delimiter = ...` —— 贴标签

            - **动作**​：给这个装好数据的“托盘”起个名字叫 `delimiter`（分隔符）。
            - **用途**​：以后你在代码里把 `delimiter` 给谁，谁就知道：“哦！原来这就是那个暗号！”

            ---

            ### 总结：为什么要写得这么麻烦？

            *为什么不直接写* *​`new DelimiterBasedFrameDecoder("$_")`​* ​ *？*

            因为 Netty 是一个**底层**网络框架，它为了极致的性能，要求所有数据必须是**二进制（ByteBuf）**  格式。它不希望在高速运行的时候，还要帮你做“字符串转二进制”这种耗时的翻译工作。

            所以，这行代码的意思就是： **“我现在先把‘暗号’翻译好、打包好，做成一个标准的二进制模板，一会儿直接交给解码器去比对。”**
         2. `ch.pipeline().addLast(new DelimiterBasedFrameDecoder(1024, delimiter));`

             **“往流水线（Pipeline）里装一个‘全自动剪刀’。它的工作规则是：看到暗号（**​ **​`$_`​** ​ **）就剪一刀，但如果剪出来的这段话超过 1024 字节还没看到暗号，就直接报错。”**

            我们把它拆开成三个部分来看：

            ### 1. `new DelimiterBasedFrameDecoder(...)` —— 这是什么？

            这是一个 Netty 提供的**现成的**工具类。它的名字很长，但意思很简单：

            - **Delimiter Based**​: 基于分隔符（也就是基于你刚才定义的 `$_`）。
            - **Frame Decoder**: 帧解码器（意思是负责把“一坨”连在一起的数据，拆分成“一帧一帧”独立的消息）。

            你可以把它想象成一个**专门负责拆快递**的工人。

            ### 2. 参数 `delimiter` —— 怎么拆？

            这就是你刚才辛苦定义的 `$_`（ByteBuf）。

            - 你把这个参数传进去，就是告诉这个工人： **“你要盯着传送带上的数据流，一旦看到**  **​`$_`​** ​ **这个符号，就把它前面那段数据剪下来，打包成一个完整的包裹发给后面的人。”**
            - **注意**​：默认情况下，它剪下来之后，会把 `$_`​ 这个“包装皮”扔掉。后面的人收到的是纯净的内容（比如 `Hello`​），而不带 `$_`。

            ### 3. 参数 `1024` —— 安全阀（重要！）

            这个数字非常关键，它是​**最大长度限制 (Max Frame Length)** 。

            **为什么要加这个限制？** 想象一下这个场景： 有一个捣乱的客户端，发给你一篇文章，但是**故意不发** `$_` 这个结束符，而且还一直发个不停。

            - **如果没有这个限制**​：你的服务器会傻傻地一直缓存这些数据，等着 `$_` 出现。结果数据越来越多，直接把你服务器的内存撑爆（OOM），程序崩溃。
            - **有了 1024**​：程序会数着字节数。如果缓存的数据到了 1024 个字节，**依然没有看到** `$_`​，Netty 就会判定“这不正常”，直接抛出异常（`TooLongFrameException`），并关闭连接。这是一种自我保护机制。
         3. `ch.pipeline().addLast(new StringDecoder());`把刚才剪切下来的二进制数据（ByteBuf）直接转换成我们可以读懂的字符串（String）。
         4. `ch.pipeline().addLast(new EchoServerHandler());`这是自己写的业务逻辑（虽然图里没显示具体代码，通常是打印出来或者回复客户端）。此时它收到的对象已经是被切割好、并转成字符串的干净数据了。
         5. 注意：

            - **客户端发送时，必须加**  **​`$_`​** ​ **！**
            - **那行代码不会帮你“自动加”** 。那行代码（`DelimiterBasedFrameDecoder`​）是**用来“读”的，不是用来“写”的**。
         6. `ctx.writeAndFlush(Unpooled.copiedBuffer(msg.getBytes()));`把这句话打包好，立刻、马上发给对方！

            ### 第一步：备货 —— `msg.getBytes()`

            - **动作**：把字符串（String）转换成字节数组（byte[]）。
            - **意思**​：比如 `msg`​ 是 "Hello"，这一步把它变成了机器能读懂的数字序列 `[72, 101, 108, 108, 111]`。
            - **为什么要这么做？**  网络传输就像运送货物，不认“文字”，只认“集装箱（字节）”。

            ### 第二步：装箱 —— `Unpooled.copiedBuffer(...)`

            - **动作**​：把上面的“字节数组”装进 Netty 专用的容器 `ByteBuf` 里。
            - **意思**：Netty 的运输管道很挑剔，它不收散装的字节。你必须用它指定的“标准箱子”（ByteBuf）把数据装好。
            - **Unpooled 是啥？**  意思是“现做一个新箱子，不用去旧箱子堆（池化）里找”。简单理解就是“拿个新包装盒打包”。

            ### 第三步：发货 —— `ctx.writeAndFlush(...)`

            这是最关键的一步，它其实包含了两个动作：**写（Write）**  + ​**刷（Flush）** 。

            #### 1. `write` (写/暂存)

            - **动作**​：把箱子放到**发货区的暂存台**上。
            - **注意**​：此时数据**并没有**发出去！它只是存到了网卡的缓存里，或者 Netty 内部的一个队列里。
            - **类比**：你写好了信，扔进了楼下的邮筒里，但邮递员还没来取。

            #### 2. `flush` (刷/冲走)

            - **动作**：用力推一把，把暂存台上的所有箱子，真正推入网线，发向互联网。
            - **类比**：你给邮局打电话：“快来人！把邮筒里的信立刻取走送出去！”

            #### 3. 为什么合在一起叫 `writeAndFlush`？

            - 因为大部分时候，我们希望写完消息对方能立刻收到，不想等。所以 Netty 提供了这个“二合一”的方法：**先放到暂存区，然后立刻发车。**
      2. FixedLengthFrameDecoder自动完成对定长信息的解码

         这行代码 `new FixedLengthFrameDecoder(20)`​ 是全图的主角，意思是：**不管你发什么内容，我只数 20 个字节。凑够 20 个，我就切一刀。**

         为了让你理解透彻，我们还是用“发快递”来做比喻，但这次规则变了：

         1. 核心逻辑：`FixedLengthFrameDecoder(20)`

            - **以前（分隔符模式）** ​：像是写信，不管写多长，最后画个句号（`$_`）就算结束。
            - **现在（定长模式）** ​：像是​**填格子**。

              - 我在服务器门口放了一排格子，正好 ​**20 个**。
              - 你发过来的数据，我就一个一个往格子里填。
              - **填满 20 个格子**，我就把这一排打包拿走去处理，然后马上换一排新的空格子继续填。
         2. 会发生什么奇葩情况？

            这种模式特别死板，所以会有这两种经典现象：

            #### 情况 A：你发多了（粘包处理）

            - **动作**​：你一次性发了 **25 个字节** 过来。
            - **服务器处理**：

              1. 先切下前 **20** 个字节，拿去处理（打印/回复）。
              2. 剩下的 **5** 个字节，留在缓存里，**等待**下一波数据来凑单。

            #### 情况 B：你发少了（拆包/半包处理）

            - **动作**​：你只发了 ​**5 个字节**（比如 "Hello"）。
            - **服务器处理**：

              - 它会​**死等**！
              - 因为它只收到了 5 个，距离 20 还差 15 个。
              - 此时你的 `EchoServerHandler` 根本收不到任何消息，服务器看起来像“卡死”了一样。
              - 直到你再发至少 15 个字节过来，凑齐了 20 个，它才会瞬间激活。
         3. 代码流程图解

            ```plaintext
            客户端发送流：  [12345] .... (停顿) .... [67890123456789012345]

            服务端处理流：
            1. 收到 [12345] -> 长度5，不够20 -> 【缓存等待】
            2. 收到后面一大串 -> 加上之前的5，凑够20了吗？
            3. 凑够了！ -> 切出前20个 -> 交给 StringDecoder -> 交给 EchoServerHandler
            4. 剩下多余的数据 -> 继续缓存，等下一波凑够20...
            ```
         4. 什么时候用这种模式？

            你可能会问：“这也太傻了吧，要是发不满 20 个字咋办？”

            这种模式通常用于​**非常工整的场景**，比如：

            - **硬件通信**：传感器每次只发固定的 20 个字节指令。
            - **定长协议**：比如以前的老式银行接口，规定“前10位是账号，中间10位是金额...”，总长度永远固定。

            **总结：** 这张图的代码就是告诉你： **“我不管你发的是什么字，也不管你有没有换行，我只数数。每数到 20 个字节，我就当做一句话处理。”**
3. 文件描述符是用户进程用来指代内核中打开文件的  **“句柄” (Handle)**  或  **“索引”**

   1. 核心概念：它只是一个“数组下标”

      想象一下，操作系统内核（Kernel）手里维护着一个巨大的 ​**数组**，用来记录当前所有打开的文件、网络连接、硬件设备等。

      - **内核视角**：内核在这个数组里存放了真正的“文件对象”（包含文件路径、读写位置、权限等详细信息）。
      - **你的程序视角**：因为操作系统不信任你的程序，它不会把真正的“文件对象”内存地址给你（怕你瞎改弄坏系统）。
      - **解决方案**​：内核只给了你这个对象在数组中的 ​**下标（Index）** 。

      **这个下标（整数），就是文件描述符。**

      - 当你调用 `open()`​ 打开一个文件时，内核把文件加载好，放在数组的第 `3`​ 号位置，然后返回数字 `3` 给你。
      - 当你调用 `write(3, "hello")`​ 时，你拿着数字 `3`​ 给内核，内核去数组第 `3` 个位置找到对应的文件，然后写入数据。
   2. 为什么 Socket 也有文件描述符？

      你提供的第二张图里写道：“Linux 内核将所有外部设备都看做是一个文件来操作”。

      这意味着：

      - **文本文件** 是文件。
      - **键盘、显示器** 是文件。
      - **网卡、网络连接 (Socket)**  也是文件。

      所以在 Linux 看来，​**Socket 就是一个“可以通过网络读写数据的文件”** ​。 当你创建一个 Socket 时，内核同样会返回一个 **Socket FD（Socket 描述符）**  给你的程序。你后续所有的 `read()`​ / `write()` 操作，都是对着这个整数 ID 进行的。
   3. Java 程序员看不见 FD 的原因

      你在写 Java 时很少听到“文件描述符”，是因为 Java 的面向对象封装把它藏起来了。

      - **在 C 语言里**​：程序员直接操作 `int fd`。
      - **在 Java 里**​：`Socket`​ 类或者 `FileInputStream`​ 类把这个整数 ID 包装在了对象内部。 Java 甚至有一个专门的类叫 `java.io.FileDescriptor`​，如果你去翻 `FileInputStream` 的源码，你会发现它里面就藏着这个对象。
   4. 总结：FD 到底是什么？

      1. **物理上**：它是一个非负整数（0, 1, 2, 3...）。
      2. **逻辑上**​：它是用户进程用来指代内核中打开文件的  **“句柄” (Handle)**  或 ​ **“索引”** 。
      3. **通俗比喻**：

         - **内核**是像是一个​**大澡堂子**，所有的储物柜（文件/Socket）都归它管。
         - **文件描述符**就是你进门时领到的​**手牌号（例如：3号）** 。
         - 你想拿衣服（读数据）或存衣服（写数据），不需要知道柜子具体在哪个角落，只需要把\*\*手牌号（FD）\*\*给服务员（内核），服务员就能帮你操作。

      **补充一个小知识：** 每个进程启动时，默认都会给你三个“手牌”：

      - **0**: 标准输入 (System.in)
      - **1**: 标准输出 (System.out)
      - **2**​: 标准错误 (System.err) 所以如果你自己打开新文件，FD 通常是从 **3** 开始的。
4. Java 序列化（Serialization） 就是把内存里的Java 对象，转换成一串二进制字节（Byte Stream）的过程。反过来，把字节变回对象，就叫反序列化（Deserialization）。

   - 形象的比喻：宜家家具

     - **内存里的对象（Object）** ​：就像是你**组装好**的柜子。它占地方，结构复杂，很难直接塞进快递箱寄给别人，也很难直接存进硬盘里。
     - **序列化**​：就像把柜子**拆卸**成一块块板材，打包装进一个扁平的纸箱里（变成字节流）。

       - **好处**：体积小、标准形状，可以通过网线发送（网络传输），也可以直接丢仓库里堆着（保存到硬盘）。
     - **反序列化**​：收到包裹后，根据说明书，把板材重新**组装**成原来的柜子。
   - 为什么要序列化？

     主要有两个场景：

     1. **持久化（保存到硬盘）** ： 比如你玩游戏存档。你的人物等级、装备都在内存里，关机就没了。序列化就是把这些数据变成文件存到硬盘上，下次开机读取文件（反序列化），人物状态就恢复了。
     2. **网络传输（发给别人）** ​： 在你刚才的代码里，`Socket`​ 只能传字节。如果你想把一个复杂的 `User` 对象直接传给服务器，你必须先把它“打碎”成字节流（序列化），传过去后，服务器再把它“拼回”成对象（反序列化）。
   - 代码里怎么做？

     Java 提供了一套非常简单的机制。

     **第一步：盖章（实现接口）** 你的类必须实现 `java.io.Serializable`​ 接口。这是一个​**空接口**（没有任何方法），它只是一个“标签”，告诉 Java 虚拟机：“这个类的对象允许被拆卸打包”。

     ```java
     import java.io.Serializable;

     // 必须加上这个接口，否则会报错
     public class User implements Serializable {
         private String name;
         private int age;
         // ... get/set ...
     }
     ```

     **第二步：使用专用流**这就回到了你刚才问的 `InputStream/OutputStream`。针对对象，Java 有专门的包装流：

     - **​`ObjectOutputStream`​**: 负责序列化（写出去）。
     - **​`ObjectInputStream`​**: 负责反序列化（读回来）。

     **代码示例：**

     ```java
     // --- 序列化（打包） ---
     User user = new User("Gemini", 18);
     ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("user.dat"));
     out.writeObject(user); // 这一行就把对象变成了文件里的乱码（字节）
     out.close();

     // --- 反序列化（解包） ---
     ObjectInputStream in = new ObjectInputStream(new FileInputStream("user.dat"));
     User savedUser = (User) in.readObject(); // 这一行把字节变回了 Java 对象
     System.out.println(savedUser.getName()); // 输出 Gemini
     in.close();
     ```
   - 三个重要的面试/考试考点

     如果你在学这个，这三个概念一定要知道：

     1. **​`serialVersionUID`​**​  **(版本号)** ：

        - 这就像​**产品的型号**​。如果你把对象存盘了（版本 1.0），然后你修改了代码（比如给 User 加了个 `address` 字段，变成版本 2.0）。
        - 这时候再去读取旧文件，Java 会发现版本号对不上，直接报错。
        - *建议：*  手动指定一个固定的 ID，这样即使改了代码也能尽量兼容旧数据。
     2. **​`transient`​**​ **关键字 (透明的/瞬态的)** ：

        - 如果你不想某个字段被序列化（比如用户的​**密码**​，或者银行卡号，为了安全不想存盘），就在字段前加 `transient`。
        - `private transient String password;`
        - 序列化时，这个字段会被忽略（值变成 null）。
     3. **​`static`​**​ **变量不会被序列化**：

        - 静态变量属于​**类**​，不属于​**对象**。序列化存的是对象的状态，所以静态变量不会被打包进去。
5. 私有协议栈开发

   1. Netty协议栈功能设计：Nety协议栈用于内部各模块之间的通信，它基于TCP/IP协议栈，是一个类HTTP协议的应用层协议栈，相比于传统的标准协议栈，它更加轻巧、灵活和实用

      1. 在分布式组网环境下，每个Netty节点（Netty进程）之间建立长连接，使用Netty协议进行通信。Netty节点并没有服务端和客户端的区分，谁首先发起连接，谁就作为客户端，另一方自然就成为服务端。一个Netty节点既可以作为客户端连接另外的Netty节点，也可以作为Netty服务端被其他Netty节点连接
      2. Netty协议栈通信具体步骤：

         1. Netty协议栈客户端发送握手请求消息，携带节点ID等有效身份认证信息；
         2. Netty协议栈服务端对握手请求消息进行合法性校验，包括节点ID有效性校验、节点重复登录校验和IP地址合法性校验，校验通过后，返回登录成功的握手应答消息；
         3. 链路建立成功之后，客户端发送业务消息；
         4. 链路成功之后，服务端发送心跳消息；
         5. 链路建立成功之后，客户端发送心跳消息；
         6. 链路建立成功之后，服务端发送业务消息
         7. 服务端退出时，服务端关闭连接，客户端感知对方关闭连接后，被动关闭客户端连接
      3. 消息定义：

         1. 消息头：

            1. crcCode：Netty消息的校验码
            2. length：消息长度，整个消息包括消息头和消息体
            3. sessionID：集群节点内全局唯一，由会话ID生成器生产
            4. type：

               1. 0：业务请求消息
               2. 1：业务响应消息
               3. 2：业务ONE WAY消息（既是请求又是响应消息）
               4. 3：握手请求消息
               5. 4：握手应答消息
               6. 5：心跳请求消息
               7. 6：心跳应答消息
            5. priority：消息优先级
            6. attachment：可选字段，用于扩展消息头
         2. 消息体
      4. 链路的关闭：由于采用长连接通信，在正常的业务运行期间，双方通过心跳和业务消息维持链路，任何一方都不需要主动关闭连接。但是，在以下情况下，客户端和服务端需要关闭连接。

         1. 当对方宕机或者重启时，会主动关闭链路，另一方读取到操作系统的通知信号，得知对方REST链路，需要关闭连接，释放自身的句柄等资源。由于采用TCP全双工通信，通信双方都需要关闭连接，释放资源；
         2. 消息读写过程中，发生了I/O异常，需要主动关闭连接；
         3. 心跳消息读写过程中发生了I/O异常，需要主动关闭连接；
         4. 心跳超时，需要主动关闭连接；
         5. 发生编码异常等不可恢复错误时，需要主动关闭连接。
      5. 可靠性设计

         1. 心跳机制：当连续周期T没有读写消息时，客户端主动发送ping心跳消息给服务端，如果在下一个周期T到来时客户端依然没有收到对方的pong心跳应答消息或者读取到服务端发送的其他业务消息，则心跳失败计数器+1，收到了则清零，连续N次没有接收到pong或业务消息则关闭链路，间隔interval时间后发起重连操作。服务端空闲时间达到T以后心跳失败计数器+1，收到一次则清零，连续N次未收到则关闭链路
         2. 重连机制：如果链路中断，等待INTERVAL时间后，由客户端发起重连操作，如果重连失败，间隔周期INTERVAL后再次发起重连，直到重连成功。  
            **为了保证服务端能够有充足的时间释放句柄资源，在首次断连时客户端需要等待INTERVAL时间之后再发起重连，而不是失败后就立即重连。**   
            为了保证句柄资源能够及时释放，无论什么场景下的重连失败，客户端都必须保证自身的资源被及时释放，包括但不限于SocketChannel、Socket等。  
            重连失败后，需要打印异常堆栈信息，方便后续的问题定位。
         3. 重复登录保护：不允许客户端重复登录，防止句柄资源被耗尽
         4. 消息缓存重发：无论客户端还是服务端，当发生链路中断之后，在链路恢复之前，缓存在消息队列中待发送的消息不能丢失，等链路恢复之后，重新发送这些消息，保证链路中断期间消息不丢失。考虑到内存溢出的风险，建议消息缓存队列设置上限，当达到上限之后，应该拒绝继续向该队列添加新的消息
   2. **Server 端 Pipeline：**

      1. `NettyMessageDecoder` (处理半包，解析二进制为对象)
      2. `NettyMessageEncoder` (把对象转回二进制)
      3. `LoginAuthRespHandler` (专门拦截握手请求，处理完就透传)
      4. `HeartBeatRespHandler` (专门拦截心跳，Pong回去)
      5. `BizHandler` (最后才是处理真正的业务逻辑)
6. ChannelFuture是异步IO操作的结果占位符，未来某个时间点获取到操作结果

   1. 通俗类比：快递单号（或者取餐小票）

      假设你要寄一个包裹给朋友（发送数据）：

      1. **动作：**  你把包裹交给快递员（调用 `channel.writeAndFlush(msg)`）。
      2. **现象：**  快递员拿了包裹​**转头就走**，并没有当场把包裹送到朋友手里（方法立刻返回，不阻塞）。
      3. **问题：**  你怎么知道朋友收到了没？如果你想在朋友收到后发个短信通知他，该怎么办？
      4. **解决：**  快递员给了你一张​**快递单号**​。这张单号，就是 ​**​`ChannelFuture`​**。

      **​`ChannelFuture`​**​ **的作用就是：** 你手里攥着这张单号，随时可以查：“送到了吗？”（查询状态），或者你在单号上备注：“等送到了，请给我打个电话”（注册监听器）。
   2. 核心定义

      在 Netty 中，几乎所有的 I/O 操作（Bind, Connect, Write, Close 等）都是**异步**的。

      - 当你调用这些方法时，它们会​**立刻返回**​，并送给你一个 `ChannelFuture` 对象。
      - 此时，底层的 I/O 操作可能还没开始，也可能正在进行中，反正肯定没完成。
      - `ChannelFuture`​ 保存了这次操作的状态：​**成功**​、​**失败**​、还是​**被取消**。
   3. 实战：怎么用这个“快递单号”？

      这也是面试和实战中的重点。你有两种方式来处理结果：

      #### 方式一：死等（Sync）—— 适合初始化阶段

      就像你把包裹给快递员，然后你就站在门口死死盯着他，直到他送到为止。

      ```java
      // 建立连接
      ChannelFuture future = bootstrap.connect("127.0.0.1", 8080);

      // 阻塞当前线程，直到连接真正建立成功
      // 如果不加这行，下一行代码执行时，连接可能还没连上，导致报错
      future.sync(); 

      System.out.println("连接终于成功了！");
      ```

      - **适用场景：**  程序启动时（比如 Server 启动监听端口，Client 发起连接）。
      - **缺点：**  如果在高并发的业务逻辑里用 `sync()`，会把线程卡死，导致性能急剧下降。

      #### 方式二：注册监听器（Listener）—— 适合高并发业务（推荐）

      就像你在快递单上备注：“送到后发短信告诉我，我先去忙别的了。”这是 Netty 的精髓。

      ```java
      // 发送消息，并获得一个 Future
      ChannelFuture future = ctx.writeAndFlush("Hello Netty");

      // 给这个 Future 添加一个监听器（回调函数）
      future.addListener(new ChannelFutureListener() {
          @Override
          public void operationComplete(ChannelFuture f) {
              if (f.isSuccess()) {
                  System.out.println("消息发送成功！");
              } else {
                  System.out.println("发送失败，原因：" + f.cause());
                  // 可以在这里做异常处理，比如记录日志、重发等
              }
          }
      });

      // 代码立刻继续往下走，不会卡在这里
      System.out.println("发送指令已下达...");
      ```

      - **适用场景：**  几乎所有运行时的 IO 操作。
      - **优点：**  ​**非阻塞**，吞吐量极高。

      ---
   4. 一个经典坑（一定要注意）

      很多初学者写 Netty 关闭连接时会犯这个错：

      ```java
      // 错误写法
      ctx.channel().close(); 
      System.out.println("连接已关闭"); // 这句话可能在连接真正关闭前就打印了
      ```

      ```java
      // 正确写法
      ChannelFuture future = ctx.channel().close();
      future.addListener(new ChannelFutureListener() {
          @Override
          public void operationComplete(ChannelFuture f) {
              System.out.println("现在才是真正的关闭完成了");
          }
      });
      ```
   5. 总结

      - **ChannelFuture 是什么？**  是异步 IO 操作的​**结果占位符**（一张操作凭证）。
      - **为什么需要它？**  因为 Netty 的 IO 方法是立即返回的，我们需要一种机制在未来某个时间点获取操作结果。
      - **怎么用？**

        - **Startup 时：**  用 `sync()` 阻塞等待初始化完成。
        - **Runtime 时：**  用 `addListener()` 异步回调，性能最高。
7. 服务端创建

   1. 握手认证 Handler (`LoginAuthRespHandler`​)：`channelRead` 方法

      **Step 1: 消息类型过滤**

      - 判断 `msg.getHeader().getType()`​ 是否等于 `LOGIN_REQ` (握手请求)。
      - **关键点**​：如果**不是**握手请求，必须执行 `ctx.fireChannelRead(msg)` 把消息传给下一个 Handler，否则后续业务永远收不到数据。

      **Step 2: 重复登录校验**

      - 获取发送方地址：`ctx.channel().remoteAddress().toString()`
      - 查询 `nodeCheck` 缓存。
      - **判定**：

        - 若已存在：视为重复登录，拒绝。
        - 若不存在：进入下一步。

      **Step 3: 白名单校验 (安全层)**

      - 遍历允许的 IP 列表（WhiteList）。
      - **判定**：

        - IP 在白名单内：握手成功 (`buildResponse((byte)0)`​)，并将 IP 放入 `nodeCheck`。
        - IP 不在白名单：握手失败 (`buildResponse((byte)-1)`)。

      **Step 4: 响应发送**

      - 调用 `ctx.writeAndFlush(loginResp)`。
      - **非常重要**：如果是握手失败，发送完响应后，必须主动关闭连接！

      ### 2. 异常断连清理 (`exceptionCaught` 方法)

      - **触发时机**：客户端暴力断开或网络异常。
      - **动作**：

        1. `nodeCheck.remove(clientIP)`​: **必须**从缓存中移除该 IP。
        2. `ctx.close()`: 释放句柄。
        3. `ctx.fireExceptionCaught(cause)`: 传递异常。
      - *笔记批注：如果不移除 IP，该用户掉线后将永远无法再次登录（会被判定为重复登录）。*
   2. 心跳应答 Handler (`HeartBeatRespHandler`​)：`channelRead` 方法

      **Step 1: 拦截心跳**

      - 判断 `msg.getHeader().getType()`​ 是否等于 `HEARTBEAT_REQ` (心跳请求)。
      - **同样**​：如果不是心跳，必须 `ctx.fireChannelRead(msg)` 透传。

      **Step 2: 构造应答 (Pong)**

      - **服务端不需要判断超时**​：超时的判断交给了 `IdleStateHandler`（如果你配了的话）。这里只负责“有问必答”。
      - 创建一个 `HEARTBEAT_RESP` 类型的消息。
      - `ctx.writeAndFlush(heartBeatResp)`。

      **Step 3: 资源释放 (重要)**

      - 心跳消息是系统指令，不需要传递给业务层。
      - 所以在回完 Pong 之后，**不需要**再调用 `fireChannelRead`。
      - **内存防漏**​：如果不透传，且消息里包含 `ByteBuf`​，理论上需要 `ReferenceCountUtil.release(msg)` (虽然本书示例代码用的 POJO 对象不需要释放，但实战中如果用 ByteBuf 必须释放)。
   3. 服务端启动类 (`NettyServer`)：ChannelPipeline 顺序

      1. **​`NettyMessageDecoder`​**​: (入站) 二进制 -\> Java 对象 (解决粘包/拆包)。
      2. **​`NettyMessageEncoder`​**​: (出站) Java 对象 -\> 二进制。
      3. **​`ReadTimeoutHandler`​**​: (入站) **读超时控制** (比如 50秒没读取到数据，自动断开)。

         - *注意：这实际上就是服务端的心跳超时检测机制。*
      4. **​`LoginAuthRespHandler`​**: (入站) 拦截握手。
      5. **​`HeartBeatRespHandler`​**: (入站) 拦截心跳。
      6. **​`BizHandler`​**: (入站) 真正的业务逻辑处理。
8. 客户端创建

   1. 主动握手 Handler (`LoginAuthReqHandler`)

      1. 触发时机 (`channelActive` 方法)

         **这是与服务端最大的区别**​。服务端是在读到数据时处理，客户端是在**连接建立完成的那一刻**主动出击。

         - **逻辑**：

           1. Netty 回调 `channelActive()`，表示 TCP 三次握手成功。
           2. 立即构造 `LOGIN_REQ` 消息。
           3. `ctx.writeAndFlush(msg)`。
      2. 处理响应 (`channelRead` 方法)

         - **逻辑**：

           1. 收到消息，判断 `Type`​ 是否为 `LOGIN_RESP`。
           2. **判定**：

              - **成功 (Body=0)** ​: 握手通过，`ctx.fireChannelRead(msg)` 透传给心跳模块（启动心跳）。
              - **失败 (Body=-1)** ​: 握手被拒，`ctx.close()`。
   2. 定时心跳 Handler (`HeartBeatReqHandler`​)：使用了 Java 的 `ScheduledExecutorService`​，**如何在 Netty 里做定时任务？**

      1. 启动心跳 (`channelRead` 方法)

         - **触发**​：当收到 `LoginAuthReqHandler` 传过来的“握手成功”消息时。
         - **动作**​：初始化一个定时任务 (`ScheduledFuture`)。

           - **任务内容**​：每隔 5 秒（举例）构造一个 `HEARTBEAT_REQ`​ 消息，调用 `ctx.writeAndFlush()`。
           - 注意 *：这里创建了一个内部类* *​`HeartBeatTask`​*​ *来专门干这个事。*
      2. 接收 Pong (`channelRead` 方法)

         - **逻辑**：

           - 收到 `HEARTBEAT_RESP` (Pong)。
           - 打印一句日志：“Client receive server heart beat message: ---\>”。
           - **丢弃消息**：不需要往下传了，知道服务端活着就行。
      3. 停止心跳 (`exceptionCaught` 方法)

         - **关键点**​：如果连接断了，必须​**取消定时任务**！
         - **代码逻辑**：

           ```java
           if (heartBeat != null) {
               heartBeat.cancel(true); // 停掉定时器，否则会一直报错说连接不可用
               heartBeat = null;
           }
           ctx.fireExceptionCaught(cause); // 往后抛，触发重连
           ```
   3. 断线重连机制：Connect() 函数:

      1. 尝试 bootstrap.connect(port, host).sync()
      2. 等待连接关闭: future.channel().closeFuture().sync()
      3. [连接断开后执行这里]:  
         -> 检查是否需要重连? (UserFlag = true)  
         -> 释放资源 (group.shutdownGracefully 这一步在重连时不能做，要复用 Group)  
         -> 休息 5 秒 (避免疯狂重连把 CPU 打满)  
         -> 递归调用 Connect() 或者 重新执行循环
9. Netty的线程模型

   1. Reactor 模型的三种形态

      1. 单线程 Reactor (Single Thread)

         - **配置**​：`EventLoopGroup group = new NioEventLoopGroup(1);` (Boss 和 Worker 合体)
         - **逻辑**：

           - 1 个线程同时负责：Accept (连接) + Read/Write (IO) + Decode/Encode (计算) + Business (业务)。
         - **缺点**：一个业务卡死，全站假死。不适合计算密集型。
         - **适用**：Redis (早期版本)。
      2. 多线程 Reactor (Multithreaded)

         - **配置**​：`bossGroup`​ (1个线程), `workerGroup` (N个线程)。
         - **逻辑**：

           - **Acceptor 线程**：只负责接待（Accept），把连接扔给 Worker。
           - **Worker 线程池**：负责读写 IO 和 业务处理。
         - **优点**：充分利用多核 CPU。
         - **缺点**：Acceptor 是单点的，如果是百万级瞬间并发，门口可能会堵。
      3. 主从多线程 Reactor (Main-Sub Multithreaded) —— **Netty 的默认推荐**

         - **配置**​：`bossGroup`​ (N个线程), `workerGroup` (M个线程)。
         - **逻辑**：

           - **MainReactor (Boss)** ​：不再是一个线程，而是一个线程​**池**。专门负责绑定端口、接收连接。
           - **SubReactor (Worker)** ：负责 IO 读写。
         - **适用**：服务端需要监听多个端口，或者极高并发场景（如 Nginx）。
   2. NioEventLoop 的工作原理：死循环

      1. **​`NioEventLoop`​**​   **=**   **​`Thread`​**​  **(线程) +**  **​`Selector`​**​  **(多路复用器) +**  **​`TaskQueue`​**​  **(任务队列)**
      2. 生命周期：

         1. **Select：** 轮询注册在 Selector 上的 Channel，看谁有 IO 事件（读/写/连）。
         2. **ProcessSelectedKeys (处理 IO)：** 如果发现有 IO 事件，根据事件类型调用 unsafe 方法（底层读写）。
         3. **RunAllTasks (处理非 IO 任务)：** 执行 `TaskQueue`​ 里的任务（比如用户触发的 `write`，或者定时心跳）。

            - *时间控制*：Netty 会计算时间，保证处理 IO 和处理任务的时间比例（默认 50%:50%），防止某一方饿死。
   3. 串行化设计：一个 `Channel`​ 从出生到死亡，**只会被绑定到同一个** **​`EventLoop`​**​ **线程上**。在这个 Channel 上的所有 Handler（解码、业务、编码），都是由**同一个线程**按顺序执行的。

      1. 为什么这样设计最快？

         - **传统做法**​：每个 Handler 可能在不同线程，需要加锁 (`synchronized`) 保护共享数据。
         - **Netty 做法**​：因为是同一个线程跑到底，​**根本不需要加锁**！
         - **收益**：

           1. **无锁竞争**：省去了大量的 Context Switch (上下文切换) 和锁开销。
           2. **CPU 亲和性 (Affinity)** ：数据都在同一个 CPU 缓存里，命中率极高。
10. Netty架构分析

    1. 逻辑架构的三层模型

       1. 反应堆层 (Reactor Communication Layer) 

          - **职责**：负责网络通信的底层细节。
          - **核心组件**：

            - `EventLoopGroup` (线程池)
            - `Selector` (多路复用器)
            - `Unsafe`​ (封装了 JDK 底层的 NIO 操作，如 `read`​, `write`​, `connect`)
          - **架构意义**：屏蔽了底层 NIO 的复杂性（Epoll bug、复杂的 SelectionKey 管理），向上层提供简单的事件驱动能力。
       2. 职责链层 (Pipeline Layer) 

          - **职责**：负责事件的流转和处理。这是用户最常打交道的一层。
          - **核心组件**：

            - `ChannelPipeline` (双向链表)
            - `ChannelHandler` (业务逻辑容器)
            - `ChannelHandlerContext` (上下文桥梁)
          - **架构意义**​：实现了**AOP (面向切面)**  的拦截机制。

            - 可以随意插拔 Handler（如：加个 SSL Handler 就有了加密，加个 Log Handler 就有了日志），而不用修改核心代码。
            - **关键特性**：动态性。Handler 甚至可以在运行时增删（比如握手成功后，把握手 Handler 移除）。
       3. 业务逻辑层 (Service Integration Layer) 

          - **职责**：开发者的“主战场”。
          - **核心组件**：

            - `Bootstrap`​ / `ServerBootstrap` (启动引导)
            - 用户的自定义业务 Handler。
          - **架构意义**：只需要关心“收到数据后干什么”，不需要关心“数据怎么从网卡读出来的”。
    2. 关键架构组件

       1. Netty 没有直接用 JDK 的 `ByteBuffer`，而是自己造了一套。

          - **架构优势**：

            - **读写指针分离**​：不需要像 JDK 那样频繁调用 `flip()`，极大降低了编程心智负担。
            - **引用计数 (Reference Counting)** ：结合对象池使用，精准控制内存释放。
       2. 异步抽象：`Channel`​ 与 `Unsafe`

          - **Channel**：是 Netty 对网络操作的最高层抽象。
          - **Unsafe**​：​**注意，这个不是 JDK 的 sun.misc.Unsafe**。

            - 这是 Netty 内部的一个接口（通常是 `AbstractChannel` 的内部类），它是真正干脏活累活的地方（读写 Socket）。
            - 注意：用户代码永远不要直接去调用 Unsafe 的方法。
    3. Netty 为什么性能高？

       1. IO 模型：非阻塞 IO (NIO)

          - 利用 JDK 的 `Selector` 实现多路复用。
          - 一个线程可以管理成千上万个连接（海量并发的基础）。
       2. 线程模型：主从 Reactor (无锁化)

          - 复习第 18 章结论：串行化设计。
          - 单个 Channel 的所有 IO 操作和业务处理都在同一个线程内完成，​**避免了锁竞争和上下文切换**。
       3. 内存管理：内存池 (Pooling)

          - **痛点**：在堆外内存 (Direct Memory) 分配大对象非常昂贵。
          - **解法**：Netty 实现了一个类似 jemalloc 的内存池。
          - **效果**：对象复用，减少内存分配和回收的开销 (GC 压力剧减)。
       4. 数据拷贝：零拷贝 (Zero Copy)

          > *这里的零拷贝是指 Netty层面的，不仅仅是 OS 层面的。*
          >

          - **Slice (切片)** ：把一个大 Buffer 逻辑上切成两个，不发生数据复制。
          - **Composite (组合)** ：把头部的 Buffer 和 Body 的 Buffer 逻辑上拼在一起，不发生内存复制。
          - **FileRegion**​：直接调用 OS 的 `sendfile` 技术，文件直接从硬盘传给网卡，不经过用户态内存。
       5. 序列化：高效的二进制协议

          - 支持 Protobuf 等高效序列化框架，比 Java 原生序列化小 10 倍，快 5 倍。
       6. 锁机制：对 JDK 锁的优化

          - Netty 底层大量使用了 `volatile`​、`CAS`​ 操作和 `JCTools`​ (高性能队列)，尽量避免使用重量级的 `synchronized`。
       7. 通信细节：高性能设计

          - **Volatile**: 保证变量可见性。
          - **算法优化**: 比如 `FastThreadLocal`​，比 JDK 的 `ThreadLocal` 更快。
    4. 可靠性架构 

       - **链路有效性检测**：心跳机制 (IdleStateHandler) + 读写超时机制。
       - **流量整形 (Traffic Shaping)** ：`GlobalTrafficShapingHandler`。可以控制全局或者单连接的上传/下载速度，防止流量洪峰把内存撑爆（OOM）。
       - **优雅停机 (Graceful Shutdown)** ：不是直接 Kill 线程，而是先不再接收新请求，处理完积压任务，释放资源，最后退出。
    5. 总结：

       - **网络层 (NIO/Epoll)** : 收到字节流。
       - **零拷贝层 (Direct ByteBuf)** : 封装数据，不复制。
       - **线程层 (EventLoop)** : 指派固定的线程接管。
       - **Pipeline 层**:

         - Decoder (字节 -\> 对象)
         - Handler (业务逻辑)
         - Encoder (对象 -\> 字节)
       - **输出**: 写入 Socket，完成交互。
11. java多线程编程在netty中的应用

    1. Java 内存模型 (JMM) 在 Netty 中的体现

       > *核心：并发编程的三大特性（原子性、可见性、有序性）。Netty 极其依赖“可见性”。*
       >

       1. volatile 的作用

          - **JDK 语义**：保证变量修改后，其他线程立马可见；禁止指令重排序。
          - **Netty 应用**：

            - Netty 中大量的状态标志（如 `state`​, `wip`​）都使用了 `volatile` 修饰。
            - 为什么不用 `synchronized`​？因为`volatile` 是轻量级的，不会引起线程上下文切换。在读多写少的场景下（比如判断连接是否关闭），性能远高于锁。
       2. CAS (Compare And Swap)

          - **JDK 语义**​：`AtomicInteger` 等原子类，利用 CPU 原语实现无锁并发。
          - **Netty 应用**：

            - 计数器（如流量统计）、引用计数（`ReferenceCount`）大量使用 CAS。
            - **优势**：避免了线程阻塞和唤醒的开销。
    2. Netty 对 JDK 线程类的改进

       1. 线程本地变量：`FastThreadLocal`​ vs `ThreadLocal`

          - **JDK** **​`ThreadLocal`​**​ **的问题**：

            - 内部使用的是 `ThreadLocalMap`​，本质是一个**哈希表** (采用线性探测法解决冲突)。
            - 当 ThreadLocal 变量很多时，Hash 冲突概率高，查找性能下降。
          - **Netty** **​`FastThreadLocal`​**​ **的优化**： 

            - **核心原理**​：不玩 Hash 了，直接用​**数组下标 (Index)** 。
            - 每个 `FastThreadLocal` 在创建时获得一个唯一的 ID（只是一个递增的 int 索引）。
            - 读写数据时，直接通过 `array[index]`​ 访问，时间复杂度永远是 ​**O(1)** 。
            - **前提**​：必须配合 Netty 自己的 `FastThreadLocalThread` 使用。
       2. 任务队列：`MpscQueue` (无锁队列)

          在 NioEventLoop 中，任务队列的性能至关重要。Netty 引入了 JCTools 库。

          - **JDK** **​`LinkedBlockingQueue`​**：

            - 使用锁（`ReentrantLock`）来保证线程安全。锁竞争在大并发下是性能杀手。
          - **Netty** **​`MpscArrayQueue`​**：

            - **全称**​：**M**ulti-**P**roducer **S**ingle-**C**onsumer (多生产者，单消费者)。
            - **场景完美匹配**：外部线程（多生产者）往 EventLoop 丢任务，EventLoop 线程（单消费者）取任务。
            - **优化**：完全无锁（Lock-free），利用 CAS 和填充缓存行（Padding，避免伪共享）技术，性能极其彪悍。
       3. 定时器：`HashedWheelTimer` (时间轮)

          - **JDK** **​`Timer`​**​  **/**  **​`ScheduledThreadPool`​**​ **的痛点**：

            - 内部用的是 `PriorityQueue` (最小堆)。
            - 插入和删除任务的时间复杂度是 ​**O(log N)** 。
            - 当你有 100 万个连接需要做心跳超时检测时，这个 log N 就会变得很慢。
          - **Netty** **​`HashedWheelTimer`​**​  **(时间轮)** ：

            - **原理**：像一个钟表盘，把一圈分成 512 个格子（Bucket）。指针每滴答一次走一格。
            - **操作**：

              - 任务放进去：算出它该在哪个格子上，直接挂个链表。复杂度 ​**O(1)** 。
              - 任务触发：指针走到这格，把链表里的任务全拿出来执行。
            - **适用场景**​：​**海量**​、​**短耗时**​、​**精度要求不高**（比如几百毫秒误差没关系）的定时任务（专门治心跳检测）。
    3. 线程池与 Executor 框架：*Netty 扩展了 JDK 的 Executor。*

       1. EventExecutorGroup

          - 它是 Netty 对 JDK `ScheduledExecutorService` 的扩展。
          - 提供了 `next()` 方法：从线程池里选一个线程出来（实现了负载均衡算法，通常是轮询或者 2 的幂次优化选择）。
       2. 优雅停机 (Graceful Shutdown)：**静默期 (Quiet Period)** 。

          - 当调用 `shutdownGracefully()` 时，Netty 不会立马自杀。它会先进入“静默期”（比如 2 秒）。
          - 如果在这 2 秒内又有新任务进来，它会重新激活，把活干完再试着退出。这是为了保证业务逻辑的完整性。
12. 高性能之道

    1. 异步非阻塞通信 (Asynchronous & Non-blocking)：*这是解决“吞吐量”问题的关键。*

       1. 传统 BIO 的死穴

          - **同步阻塞**：客户端发一个请求，服务端的线程就卡在那里死等（Block），直到数据读完、处理完、写回完。
          - **后果**：线程是昂贵资源，并发一高，线程数不够用，系统直接崩溃（OOM 或 拒绝服务）。
       2. Netty 的解法

          - **NIO (Non-blocking IO)** ​：利用 JDK 的 `Selector`，一个线程轮询成千上万个连接。
          - **异步 Future 机制**：

            - 所有的 IO 操作（Connect, Write, Close）都立即返回一个 `ChannelFuture`。
            - 业务逻辑不需要死等 IO 完成，可以通过 `Listener` 回调机制继续干别的事。
          - **收益**：用极少的线程（CPU 核数 \* 2）支撑海量连接。
    2. 零拷贝 (Zero Copy) ：*Netty 的零拷贝和 OS 的零拷贝概念略有不同，Netty 做了三个层次的优化。*

       1. 物理层：FileRegion (OS 级别)

          - **原理**​：封装了 Linux 的 `sendfile` 系统调用。
          - **场景**：文件传输（比如写一个静态文件服务器）。
          - **流程**​：硬盘 -\> 内核缓冲区 -\> 网卡。​**完全不经过用户态内存 (JVM)** ，数据拷贝次数为 0 (或 1 次 DMA)。
       2. 内存层：Direct Memory (堆外内存)

          - **原理**​：使用 `DirectByteBuf`。
          - **场景**：常规 Socket 读写。
          - **对比**：

            - **HeapByteBuf (堆内)** ​：Socket -\> OS 内核 -\> JVM 堆内 (多一次拷贝)。
            - **DirectByteBuf (堆外)** ​：Socket -\> OS 内核 / JVM 共享空间。​**少了一次从内核到 JVM 堆的拷贝**。
       3. 逻辑层：CompositeByteBuf / Slice (对象操作)

          - **原理**：逻辑上的拼接或切分。
          - **场景**：协议包拼装（Header + Body）。
          - **做法**​：不用 `System.arraycopy` 真的去复制字节，而是移动指针（索引），让两个 ByteBuf 在逻辑上看起来像一个。
    3. 内存池 (Memory Pooling)：*解决“GC 停顿”问题的关键。*

       1. 痛点

          - 在高并发下，频繁创建和销毁缓冲区（ByteBuf）会制造大量的内存碎片和垃圾对象。
          - JVM 的 GC（垃圾回收）会因为对象太多而频繁触发 Stop-The-World，导致服务卡顿。
       2. Netty 的解法：PooledByteBufAllocator

          - **借鉴**​：参考了 `jemalloc` (C++ 的内存分配器) 的算法。
          - **机制**：

            - 预先申请一大块内存（Arena）。
            - 谁要用，就切给谁；用完了，还回来擦擦干净继续用。
          - **收益**：**对象复用**，极大地减轻了 GC 的压力。
    4. 高效的 Reactor 线程模型：*这里强调“无锁”带来的性能提升。*

       1. 串行化设计 (Thread Confinement)

          - **核心**​：Socket 的读写、编解码、Handler 逻辑，全部绑定在**同一个线程**里执行。
          - **收益**：

            - **无锁化**​：不需要 `synchronized`，避免锁竞争。
            - **CPU 亲和性**：减少上下文切换 (Context Switch)，让 CPU 缓存命中率达到极致。
    5. 高性能序列化 (Serialization)：*解决“网络带宽”瓶颈。*

       1. Java 序列化的“三宗罪”

          - **无法跨语言**：Java 序列化出来的只有 Java 认。
          - **码流太大**：一个简单的 Integer 序列化后可能几百字节，浪费带宽。
          - **性能太差**：CPU 消耗高。
       2. Netty 的支持

          - 完美支持 ​**Protobuf**​, ​**Thrift**​, **Marshalling** 等二进制协议。
          - **笔记数据**：Protobuf 的码流大小通常只有 Java 序列化的 **1/5** 到 **1/10**，解析速度快 **N 倍**。
    6. 并发优化的细节 (Micro-Optimizations)

       - **Volatile**: 大量使用 volatile 保证状态可见性，替代锁。
       - **CAS**: 使用 J.U.C 的原子类进行计数和并发控制。
       - **各种 Fast 结构**: `FastThreadLocal`​, `MpscQueue`。
13. Netty可靠性设计

    1. 链路有效性检测 (Link Validity)

       > *问题：TCP 连接是虚拟的。如果网线被拔掉，或者中间路由器挂了，双方是不知道的（僵死连接）。*
       >

       1. 为什么 TCP Keep-Alive 不够用？

          - **默认太慢**：TCP 默认的心跳通常是 2 小时，对于实时应用来说，黄花菜都凉了。
          - **层级不同**：TCP 心跳只能检测连接层，不能检测应用层（比如进程死锁了，连接还在，但不能处理业务）。
       2. Netty 的解法：心跳机制 (Heartbeat)

          - **核心组件**​：**​`IdleStateHandler`​** (空闲状态检测器)。
          - **三种状态**：

            - `ReaderIdle`​: 读空闲（好久没收到客户端数据了）。-\> ​**最常用，判定掉线**。
            - `WriterIdle`​: 写空闲（好久没给客户端发数据了）。-\> 通常用来触发发送 Ping。
            - `AllIdle`: 读或写都空闲。
          - **笔记重点**：

            - 一旦检测到空闲，它会触发 `UserEventTriggered` 事件。
            - 你需要在后续的 Handler 里捕获这个事件，并执行 `ctx.close()`。
    2. 流量整形 (Traffic Shaping)

       > *问题：如果客户端是个疯子，一秒钟发给你 1GB 数据，或者你的服务器网速很慢，内存会被积压的请求撑爆 (OOM)。*
       >

       1. 核心原理

          - **类似于水库大坝**：通过控制闸门，把波动的流量（洪峰）变成平滑的流量。
          - **机制**：

            - 监控每秒的读写字节数。
            - 如果超过阈值，就让 IO 线程 **Sleep (休眠)**  一会儿。
            - 等待期间，不再从 TCP 缓冲区读数据，利用 TCP 的滑动窗口机制迫使发送方降速。
       2. Netty 组件

          - **​`GlobalTrafficShapingHandler`​**：全局流量整形（限制所有连接的总带宽）。
          - **​`ChannelTrafficShapingHandler`​**：单链路流量整形（限制单个用户的带宽）。
          - **使用场景**：文件上传下载服务、开放平台接口限流。
    3. 优雅停机 (Graceful Shutdown)

       > *问题：直接* *​`kill -9`​*​ *或者系统重启，会导致内存中未处理完的数据丢失，甚至导致文件损坏。*
       >

       1. 什么是优雅停机？

          并不是立马断电，而是经过一个​**缓冲期**：

          1. **停止接收**：不再接受新的连接请求。
          2. **处理积压**：把缓冲区里剩下的数据发完，把队列里的任务跑完。
          3. **释放资源**：关闭 Socket，释放内存，关闭线程池。
          4. **真正退出**。
       2. Netty 的实现

          - **API**​: `EventLoopGroup.shutdownGracefully()`
          - **两个关键参数**：

            - `quietPeriod` (静默期)：比如设为 2s。如果在这 2s 内没有新任务，就准备退出；如果有新任务，就再干活。
            - `timeout` (强制超时)：比如设为 15s。不管做没做完，15s 后必须强制关机（防止线程死锁导致永远关不掉）。
          - **实战笔记**：通常配合 JDK 的 `Runtime.getRuntime().addShutdownHook` 使用。
    4. 安全防护 (Security)：*可靠性也包含安全性。*

       1. SSL/TLS 加密

          - **组件**​：`SslHandler`​ (基于 JDK `SSLEngine`)。
          - **位置**​：必须放在 Pipeline 的**第一个**位置！
          - **作用**：数据加密传输，防窃听，防篡改。
       2. IP 过滤 (防火墙)

          - **组件**​：`RuleBasedIpFilter`。
          - **作用**：黑名单（屏蔽攻击 IP）、白名单（只允许内网访问）。
    5. 异常处理 (Exception Handling)：*这是代码健壮性的底线。*

       1. 这里的“坑”

          - Netty 的 IO 异常（如连接重置）如果没被捕获，可能会导致 `System.err` 打印堆栈，虽然不崩溃，但日志很难看。
          - **ByteBuf 泄露**​：如果异常发生前申请了 ByteBuf，异常发生后跳过了 `release()` 代码，就会导致内存泄漏。
       2. 最佳实践

          - 每个 Pipeline 的**最后一个 Handler** 应该是 `TailHandler`​（通常由 `exceptionCaught` 兜底）。
          - **逻辑**：记录错误日志 -\> 释放相关的资源 (ByteBuf) -\> 关闭连接 (`ctx.close()`)。
    6. 总结：

       - **顶层 (业务层)** ​：**优雅停机** (保证数据不丢)
       - **中间层 (传输层)** ​：**流量整形** (防 OOM)、**SSL 加密** (防篡改)
       - **底层 (连接层)** ​：**心跳检测** (防僵死)、**IP 过滤** (防攻击)、**异常兜底**

‍
