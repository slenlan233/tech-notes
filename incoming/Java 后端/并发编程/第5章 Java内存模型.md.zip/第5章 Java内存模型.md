- **5.1 JMM (Java Memory Model)**

  - 它定义了主存（所有线程共享，**慢**）、工作内存（线程私有，存储了共享变量的副本，**快**）抽象概念，底层对应着 CPU 寄存器、缓存、硬件内存、CPU 指令优化等。

    ### 1. 什么是主存 (Main Memory)？

    在JMM中，**主存**是一个抽象概念，它对应于我们常说的物理内存（RAM）。

    - **所有线程共享：**  它是所有线程都可以访问的区域。
    - **存储内容：**  存储了Java中所有的​**实例字段、静态字段和数组元素**。

      - *注意：*  局部变量、方法参数是线程私有的，它们存储在线程的栈帧（Stack Frame）中，不属于主存（也不属于工作内存的讨论范畴，因为它们不被共享）。

    ### 2. 什么是工作内存 (Working Memory)？

    **工作内存**也是一个抽象概念，它对应于CPU的高速缓存和寄存器。

    - **线程私有：**  每个线程都有自己独立的工作内存。
    - **存储内容：**  存储了该线程需要读/写的​**共享变量的副本（Copy）** 。
    - **操作隔离：**  线程对共享变量的所有操作（读取、赋值等）​**都必须在自己的工作内存中进行**，而不能直接读写主存。
  - JMM 体现在以下几个方面：原子性、可见性、有序性

    - **原子性** - 保证指令不会受到线程上下文切换的影响
    - **可见性** - 保证指令不会受 CPU 缓存的影响
    - **有序性** - 保证指令不会受 CPU 指令并行优化的影响
- **5.2 可见性**

  - 问题：

    - 当线程A在**自己的工作内存**中修改了变量 `x`​ 的值后，它可能​**尚未将这个新值刷回到主存**。
    - 此时，线程B去读取 `x`​，它会从**主存**中加载旧的值（或者它工作内存中已缓存的更旧的值）。
    - 结果就是：**线程A的修改对线程B不可见。**
  - **解决方法：**

    - **​`volatile`​**​  **(轻量级同步)（不像**​**​`synchronized`​**​是互斥的） **：** 用 `volatile`​ 修饰一个变量时，JMM会保证**可见性**和**禁止重排序**：

      `volatile static boolean run = true;`​

      1. **保证可见性：**

         - **写操作：**  当一个线程修改了 `volatile`​ 变量的值（在它的工作内存中），JMM会**立即**强制它将这个新值刷回到主存。
         - **读操作：**  当一个线程读取 `volatile`​ 变量时，JMM会**立即**强制它（的工作内存）从主存中重新加载最新的值，而不是使用自己工作内存中的旧副本。
      2. **禁止指令重排序：**  确保 `volatile` 变量相关的代码不会被编译器或CPU随意打乱执行顺序。
      3. **注意：** 只能解决看到最新值，不能解决指令交错（`i++`​，`i--`），不保证原子性，仅用在一个写线程多个读线程

         - 写屏障仅仅是保证之后的读能够读到最新的结果，但不能保证读跑到它前面去
         - 而有序性的保证也只是保证了本线程内相关代码不被重排序
    - **​`synchronized`​** ​ **(重量级同步)** ：提供了更强的保证（原子性 + 可见性）

      1. **原子性：**  确保同一时间只有一个线程能执行 `synchronized` 保护的代码块（即“持有锁”）。
      2. **保证可见性（通过锁的释放和获取）：**

         - **释放锁时 (Unlock)：**  当一个线程退出 `synchronized`​ 块时，JMM会强制它将**所有**在块内修改过的（包括非`volatile`的）共享变量的值，都刷回到主存。
         - **获取锁时 (Lock)：**  当一个线程进入 `synchronized` 块时，JMM会强制它清空自己的工作内存，使其必须从主存中重新加载所有需要用到的共享变量。
      3. `synchronized`​也会指令重排，但被`synchronized`​包着的代码是单线程运行的，其他线程拿不到，等其他线程能拿到的时候，指令重排完也还是完整的新对象，不是默认是`0`​或`null`​只分配了内存空间的对象，所以没问题（前提是共享变量都交给`synchronized`管理）
- **5.3 有序性**

  - 指令重排序：重新调整指令的顺序提高效率，但是重排指令不能影响结果![2cc8903d-2a52-404b-bff2-835683c324c0](assets/2cc8903d-2a52-404b-bff2-835683c324c0-20251111174635-m4vyc6t.png)多线程会影响安全，如一个实例还没被调用构造方法却已经把引用赋值了
- **​`5.4 volatile`​**​**原理**

  - **如何保证可见性：** 读、写屏障

    - **写屏障** (sfence) 保证在该屏障之前的，对共享变量的改动，都同步到主存当中

      ```java
      public void actor2(I_Result r) {
          count = 1;
          num = 2;
          // 下面这行代码是一个 volatile 写操作，它本身就起到了“写屏障”的作用，
          // 确保在此之前的指令如（count = 1;num = 2;）不会被重排到它后面。
          // 但是count = 1;num = 2;的顺序不保证谁先谁后，因为它们都是普通的写操作
          // 只关心在 ready = true 被执行时，它前面的所有操作（count=1 和 num=2）都必须已经完成了
          // 此外，这个 volatile 写操作会强制将 ready = true（以及它之前被修改的 count, num）的值
          // 从CPU高速缓存中立即刷回到主存，使其对其他线程可见。
          ready = true;  
      }
      ```

      `volatile`​​<span data-type="text" style="font-size: 13px; color: var(--b3-font-color5);"> 写操作（即 </span>`ready = true;`​​<span data-type="text" style="font-size: 13px; color: var(--b3-font-color5);"> 这一行） </span>*本身*<span data-type="text" style="font-size: 13px; color: var(--b3-font-color5);">就包含了（或充当了）写屏障的功能，并不是说“在 </span>`ready = true;`​​<span data-type="text" style="font-size: 13px; color: var(--b3-font-color5);"> 执行完之后，再执行一个单独的写屏障指令”。</span>
    - **读屏障** (lfence) 保证在该屏障之后，对共享变量的读取，加载的是主存中最新数据

      ```java
      public void actor1(I_Result r) {
          // 读屏障
          // ready 是 volatile 读取值带读屏障，下面的 ready 和 num 都是从主存读的最新值
          if (ready) {
              r.r1 = num + num;
          } else {
              r.r1 = 1;
          }
      }
      ```
  - **如何保证有序性：** 读、写屏障

    - **写屏障**会确保指令重排序时，不会将写屏障之前的代码排在写屏障之后
    - **读屏障**会确保指令重排序时，不会将读屏障之后的代码排在读屏障之前

      ```java

      public void actor1(I_Result r) {
          if(ready) {             // (C) volatile 读屏障
              int a = num + num;  // (D1)
              int b = 5;          // (D2)
              r.r1 = a + b;       // (D3)
          } 
          // ...
      }
      ```

      - 读屏障 (C) 只保证 (D1), (D2), (D3) 都会在 (C) **之后**执行。
      - 但是 JIT 编译器**完全可能**把 (D1) 和 (D2) 互换顺序，因为它们之间没有依赖关系（而且 `b=5`​ 和 `num` 的读取也没关系）。
  - **double-checked locking 问题**

    ```java
    public final class Singleton {
        private Singleton() {}
        private static Singleton INSTANCE = null;
        
        public static Singleton getInstance() {
            if (INSTANCE == null) {
                synchronized (Singleton.class) {
                    if (INSTANCE == null) {
                        INSTANCE = new Singleton();
                    }
                }
            }
            return INSTANCE;
        }
    }

    ```

    - 当我们（在DCL单例模式的上下文中）讨论 `INSTANCE = new Singleton();`​ 这行代码时，它在底层（从JVM和CPU的角度看）主要包含**三个逻辑步骤**：

      1. **分配内存空间 (Allocation)**

         - JVM在堆（Heap）上为 `Singleton` 对象分配一块内存。
         - 此时，对象的所有字段都被赋予“零值”（例如 `null`​, `0`​, `false`）。
         - （对应字节码中的`new`）
      2. **调用构造方法 (Initialization)**

         - 执行 `Singleton`​ 的构造函数 `<init>`。
         - 对象的字段被初始化为你所指定的值。
         - （对应字节码中的`dup`​ 和 `invokespecial`）
      3. **引用赋值 (Assignment)**

         - 将这块内存的地址（即对象的引用）赋值给 `INSTANCE` 静态变量。
         - （对应字节码中的 `putstatic`）
    - 问题的根源：重排序

      在单线程中，这三步的顺序（1 -\> 2 -\> 3）是固定的，不会有问题。

      但在多线程中，没有 `volatile`​ 关键字的保护，JIT编译器和CPU可能会为了优化而将顺序重排为 ​**1 ->**  **3 ->**  **2**：

      - **分配内存**
      - **引用赋值** （`INSTANCE`​ 此时指向一块**未初始化**的内存，但 `INSTANCE != null`）
      - **调用构造方法**

      如果在这（1 -\> 3）之后，（2）执行之前，另一个线程B进来了，它会看到 `INSTANCE != null`​，然后返回一个**尚未构造完成**的对象，从而导致灾难性的后果。
    - 对于一个**简单的、没有**​**​`final`​**​**字段、也没有父类构造逻辑**的类，它的“零值”状态（第一步）和“默认无参构造函数执行后”的状态（第二步）在**字段值上**​***看起来***是完全一样的（都是 `null`​, `0`​, `false`​）。然而，**在JVM看来，这是两个根本不同、且后者至关重要的阶段。** ​`volatile`​ 防止的（1 -\> 3 -\> 2）重排所带来的危险，**并不仅仅是字段值不对**，而是它破坏了Java语言最根本对象构建保证。

      1. 即使是默认的无参构造函数，编译器也会在其中**隐式地**添加一行 `super();`​ 来调用父类（在这个例子中是 `Object`​）的构造函数。如果线程B在还未调用`super（）`​的情况下就拿到了已经赋值的引用，它拿到的这个对象，是一个**连其父类（**​**​`Object`​**​ **）的构造函数都还没来得及执行**的“半成品”。在JVM层面，这是一个**状态极不稳定**的非法对象。对它进行任何操作（哪怕是 `toString()`）都可能导致JVM崩溃或不可预知的错误。
      2. `final`​ 字段的保证被破坏：Java语言**保证** `final`​ 字段一旦在构造函数中被赋值，它就**永远不会改变**，并且对所有线程可见。但如果发生 1 -\> 3 -\> 2 重排，现场B读到的值是0，而线程A在之后才执行构造函数将这个`final`修饰的字段赋值
      3. 对象处于“未定义”的非法状态：Java语言规范定义了“对象创建完成”的明确时刻：**那就是当它的构造函数执行完毕并返回时。** 一个在构造函数**返回之前**就被其他线程“窃取”的引用，是一个处于“未定义”或“部分构造”状态的非法对象。
    - 解决方案：`private static `​**​`volatile`​**​` Singleton INSTANCE = null;`

      `volatile`​​<span data-type="text" style="font-size: 13px; color: var(--b3-font-color5);"> 关键字会</span>**阻止**<span data-type="text" style="font-size: 13px; color: var(--b3-font-color5);">这种 1 -&gt; 3 -&gt; 2 的重排序，确保只有在</span>**步骤2（初始化）** <span data-type="text" style="font-size: 13px; color: var(--b3-font-color5);">完成后，</span>**步骤3（引用赋值）** <span data-type="text" style="font-size: 13px; color: var(--b3-font-color5);"> 才能被执行，保证线程B拿到的是完整的对象</span>

---

‍
