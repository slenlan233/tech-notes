- **3.1 创建和运行线程**

  - **方法一：直接使用 Thread**

    - ```Java
      Thread t1 = new Thread("first") {  //匿名内部类，继承一个类
                  @Override
                  public void run() { // 重写了Thread类的run方法
                      log.debug("running");
                  }
              };
              t1.start();
      ```

      1. t1 是一个**变量名，** 用来“称呼”这个新创建的线程对象的名字，引用的实际是一个继承 Thread 类的一个匿名子类的实例。后面想让这个线程启动，就要用这个变量名来调用它的方法，比如 `t1.start()`。

      2. first 是一个字符串，是这个线程的名字
  - **方法二：使用 Runnable 配合 Thread（将任务“Runnable”和执行者“Thread”分开）**

    - Thread 类实现了 Runnable 接口，Runnable 接口里面只有一个run方法，谁实现了它就必须得有一个run方法能被线程去调用，Thread 类里面有一个成员变量`private Runnable target`，专门存传进来的实现了runnable接口的匿名内部类的实例，里面还有一个 run 方法，当传了一个实现 Runnable 接口的类的实例的时候，Thread.run 其实运行的是实现 Runnable 接口的类的实例的run方法

      - ```Java
                Runnable r = new Runnable() { //匿名内部类，实现一个接口
                    @Override
                    public void run() {
                        log.debug("hello world");
                    }
                };
                Thread t = new Thread(r,"t2");
                t.start();
        ```

    - Java 8 以后可以使用 lambda 精简代码

      - ```Java
        Thread t = new Thread(()->{
                    log.debug("hello");
                },"t2");
                t.start();
            }
        ```
  - **方法三：FutureTask 配合 Thread**

    - ```java
                                     // 创建了一个实现了 Callable 接口的匿名内部类的实例。       
       FutureTask<Integer> task = new FutureTask<>(new Callable<Integer>() {
              @Override
                  public Integer call() throws Exception {
                  log.debug("running");
                  Thread.sleep(2000);
                  return 1;
              }
              });
              Thread t = new Thread(task,"t1");
              t.start();
              log.debug("{}",task.get());
      ```

      1. 核心矛盾：Thread 不收 Callable

         - 你想让线程执行一个能**返回结果**的任务（`Callable`，这里是返回 1）。
         - 但是，`new Thread(Runnable target)`​ 的构造函数只接收 `Runnable`。
         - **矛盾**​：`Callable`​ 不是 `Runnable`，线程不认它。
      2. 中间人：FutureTask

         **​`FutureTask`​**​ **就是那个适配器（Adapter）。**

         - **对内（构造函数）** ​：它接收 `Callable`，把它包在肚子里。
         - **对外（接口）** ​：它实现了 `RunnableFuture`​ 接口（这个接口继承了 `Runnable`​ 和 `Future`）。
      3. 所以：**在 Thread 眼里**：`FutureTask`​ 是一个 `Runnable`​，可以传给 `Thread`​ 去跑。**在主线程眼里**：`FutureTask`​ 是一个 `Future`​，可以用 `.get()` 去拿结果。
- **3.2 线程交替执行，谁先谁后不由我们控制**
- **3.3 查看进程线程的方法**

  - Windows

    - 任务管理器可以查看进程和线程数，也可以用来杀死进程
    - tasklist 查看进程
    - taskkill 杀死进程
  - Java

    - jps 命令查看所有Java进程
    - jstack <PID> 查看某个 Java 进程（PID）的所有线程状态
- **3.4 原理之线程运行**

  - 栈与栈帧

    - JVM为每一个线程分配一个它自己私有的虚拟机栈
    - 在虚拟机栈里，每调用一次方法，就创建一个栈帧。每个栈由多个栈帧组成，对应着每次方法调用时所占用的内存。每个线程只能有一个活动栈帧，对应着当前正在执行的那个方法
  - 线程上下文切换（Thread Context Switch）

    - 因为以下一些原因导致 CPU 不再执行当前的线程，转而执行另一个线程的代码：

      - 线程的 CPU 时间片用完

        垃圾回收

        有更高优先级的线程需要运行

        线程自己调用了 sleep、yield、wait、join、park、synchronized、lock 等方法
    - 当 Context Switch 发生时，需要由操作系统保存当前线程的状态，并恢复另一个线程的状态。Java 中对应的概念就是程序计数器（Program Counter Register），它的作用是记住下一条 JVM 指令的执行地址（执行到哪条指令），是线程私有的。

      - 状态包括程序计数器、虚拟机栈中每个栈帧的信息，如局部变量、操作数栈、返回地址等
      - Context Switch 频繁发生会影响性能
- **3.5 常见方法**

  - start() 和 run()

    - start() ：让线程进入就绪状态，注意里面的代码不一定立刻运行（CPU时间片还没分给它），所以就算 t1 比 t2 先start，也得由系统调度器分配谁先运行（`start()`​ 的调用顺序**不等于**线程的执行顺序。调度器有自己的算法（比如优先级、时间片轮转等），哪个就绪线程先获得 CPU 是不确定的。）。每个线程对象的 start 方法只能调用一次，否则会出现 IllegalThreadStateException

      1. t.start() 时，不是直接运行 run 方法，而是告诉Java虚拟机“我准备好了，请帮我启动这个 t 对象里描述的线程”，start() 方法会立即防御，当前的线程（如 main 线程）会继续往下执行
      2. JVM 收到了启动请求，但 JVM 也只是运行在操作系统的软件。没有权利直接创建系统级的线程，所以必须去请求操作系统（通过Java本地接口）来完成，等于向 OS 提交了一份申请“您好，windows/Linux内核，请帮我创建一个真正的、系统级的线程”
      3. 操作系统内核收到了 JVM 的请求。OS 先在内核空间中创建了一个真正的“内核线程”（这才是“真正并行执行的线程”，我们叫它“OS-Thread”）；然后OS为这个“OS-Thread”分配它自己的资源，比如私有的线程栈（用来存局部变量和方法调用）和寄存器；最后，这个“OS-Thread”已经是一个**可以被OS独立调度的“实体”** 了。（在现代Java中，这通常是一个1:1的模型：一个Java Thread对象对应一个OS内核线程)
      4. 现在，OS已经创建好了这个“工人”(OS-Thread)，但这个“工人”还不知道自己该干什么活。

         1. 这个新创建的“OS-Thread”的“出厂设置”就是：启动后，回调(call back)到JVM内部。
         2. 它会找到与它关联的那个Java Thread对象(t)。
         3. 然后，这个新的“OS-Thread”会开始执行 t 对象的 run() 方法。
    - run() ：新线程启动后会调用的方法。如果在构造 Thread 对象时传递了 Runnable 参数，则线程启动后会调用 Runnable 中的 run 方法，否则默认不执行任何操作。但也可以创建 Thread 的子类对象来覆盖 run 方法

      <span data-type="text" style="color: var(--b3-font-color5);">如果直接写t.run()，那就是直接调用 t 作为线程对象的 run 方法，而这时此线程对象还未交给系统弄成真正并行执行的线程，run 方法里的代码会运行在当前线程（如 main 线程），main线程会被阻塞直至run方法执行完毕</span>
  - join() 和 join(long n)

    -  join() ：等待线程运行结束

      `t1.join();`在哪个线程运行，就哪个线程等待 t1 线程运行结束
    -  join(long n) ：等待线程运行结束，最多等待 n 毫秒，等不到就从 join 的下一行代码执行
  - getID()：获取线程长整型的唯一 id
  - getName() ：获取线程名
  - setName(String) ：修改线程名
  - getPriority() ：获取线程优先级
  - setPriority(int) ：修改线程优先级，但它仅仅是一个提示，调度器可以忽略它。Java中规定线程优先级是1~10 的整数，较大的优先级能提高该线程被 CPU 调度的机率，但不保证。如果 cpu 比较忙，那么优先级高的线程可能会获得更多的时间片，但 cpu 闲时，优先级几乎没作用
  - getState() ：获取线程状态
  - isInterrupted() ：判断是否被打断，不会清除打断标记
  - isAlive() ：线程是否存活（还没有运行完毕）
  - interrupt() ：请求打断线程，而不是强制它停止

    `t1.interrupt();`​​​<span data-type="text" style="color: var(--b3-font-color5); font-size: 13px;">打断阻塞状态（sleep、wait、join）的线程会抛出异常并把打断标记置为 false，打断正常状态的线程由被打断的线程根据打断标记自行决定怎么做（</span>`boolean interrupted = Thread.currentThread().isInterrupted();`​​​<span data-type="text" style="color: var(--b3-font-color5); font-size: 13px;">）</span>

    1. **打断一个正在** **​`park()`​** ​ **的线程：**  线程会​**被唤醒**​（`park`​ 方法返回），但它的​**中断状态不会被清除**​（仍然是 `true`）。
    2. **一个已经是中断状态的线程去调用** **​`park()`​** ​：`park`​ 方法会​**立即返回**，根本不会阻塞，就像“失效”了一样。
  - interrupted() ：static 的，判断是否被打断，会清除打断标记
  - currentThread() ：static 的，获取当前正在执行的线程
  - sleep(long n) 和 yield()

    - sleep(long n) ：static 的，让当前执行的线程休眠 n 毫秒，休眠时间让出cpu时间片给其他线程

      - 1. 调用 sleep 会让当前线程从 *Running* 进入 *Timed Waiting* 状态

           `Thread.sleep(2000);`​​​<span data-type="text" style="font-size: 13px; color: var(--b3-font-color5);">写在哪个线程就让哪个线程休眠</span>
        2. 其它线程可以使用 interrupt 方法打断正在睡眠的线程，这时 sleep 方法会抛出 InterruptedException，需要捕获异常
        3. 睡眠结束后的线程未必会立刻得到 cpu 使用权来执行，需要竞争
        4. 建议用 TimeUnit 的 sleep 代替 Thread 的 sleep 来获得更好的可读性

           `TimeUnit.SECONDS.sleep(1);`​
    - yield() ：static 的，提示线程调度器让出当前线程对CPU的使用（谦让）

      - 1. 调用 yield 会让当前线程从 *Running* 进入 *Runnable* 就绪状态，然后调度执行其它同优先级线程，下次这个线程得到时间片了会从 yield 的下一行代码开始执行。如果这时没有同优先级线程，那么不能保证让当前线程暂停的效果，可能会出现想让没让出去的现象
        2. 具体的实现依赖于操作系统的任务调度器
- **3.6 不推荐的方法**

  - ‍
- **3.7 主线程与守护线程**

  - 默认情况下，Java进程需要等待所有线程都运行结束，才会结束。
  - 有一种特殊的线程叫做守护线程，只要其它非守护线程运行结束了，即使守护线程的代码没有执行完，也会强制结束。

    - 垃圾回收器线程就是一种守护线程
    - Tomcat 中的 Acceptor 和 Poller 线程都是守护线程，所以 Tomcat 接收到 shutdown 命令后，不会等待它们处理完当前请求

    `t.setDaemon(true);`​
- **3.8 线程状态——五种（操作系统层面）**

  - ![f50d7309-b21d-45aa-a0e2-4781fa3b3e52](assets/f50d7309-b21d-45aa-a0e2-4781fa3b3e52-20251108171126-dr3esn5.png)

    - **初始状态**  
      仅是在语言层面创建了线程对象，还未与操作系统线程关联
    - **可运行状态（就绪状态）**   
      指该线程已经被创建（与操作系统线程关联），可以由 CPU 调度执行，但是目前还没获得cpu 时间片
    - **运行状态**  
      指获取了 CPU 时间片运行中的状态

      - 当 CPU 时间片用完，会从【运行状态】转换至【可运行状态】，会导致线程的上下文切换
    - **阻塞状态**

      - 如果调用了阻塞 API，如 BIO 读写文件，这时该线程实际不会用到 CPU，会导致线程上下文切换，进入【阻塞状态】
      - 等 BIO 操作完毕，会由操作系统唤醒阻塞的线程，转换至【可运行状态】
      - 与【可运行状态】的区别是，对【阻塞状态】的线程来说只要它们一直不唤醒，调度器就一直不会考虑调度它们
    - **终止状态**  
      表示线程已经执行完毕，生命周期已经结束，不会再转换为其它状态
- **3.9 线程状态——六种（Java API层面）**

  - ![62328b73-a7ae-42cd-ac3e-3a5919b5d13d](assets/62328b73-a7ae-42cd-ac3e-3a5919b5d13d-20251109150420-ar5yfhr.png)

    - **NEW**  
      线程刚被创建，但是还没有调用 `start()` 方法
    - **RUNNABLE**  
      当调用了 `start()`​ 方法之后。注意，Java API 层面的 RUNNABLE 状态涵盖了**操作系统**层面的【可运行状态】、【运行状态】和【阻塞状态】（由于 BIO 导致的线程阻塞，在 Java 里无法区分，仍然认为是可运行）
    - **BLOCKED（锁阻塞）, WAITING（join）, TIMED_WAITING（有时限的等待，sleep、wait）**   
      都是 Java API 层面对【阻塞状态】的细分，后面会在状态转换一节详述
    - **TERMINATED**  
      当线程代码运行结束

‍
