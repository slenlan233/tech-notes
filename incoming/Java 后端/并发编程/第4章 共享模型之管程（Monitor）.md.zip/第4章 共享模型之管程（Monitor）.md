# 第4章 共享模型之管程（Monitor）

- **4.1 共享带来的问题**

  - 一条Java `i++`​指令分为四条字节码指令，与`i--`的四条字节码指令交错运行

    ![3303c36c-ea43-4053-b5ed-68b43100fb4a](assets/3303c36c-ea43-4053-b5ed-68b43100fb4a-20251109180452-9c16jks.png)

    - 问题出在多个线程访问共享资源

      - 多个线程读共享资源其实没有问题
      - 多个线程**读写共享资源**时发生指令交错，就会出现问题
  - **临界区**：一段代码块内存在对**共享资源**的多线程读写操作
  - **竞态条件**：多个线程在临界区内执行，由于代码的**执行序列不同**而导致结果无法预测

- **4.2** **​`synchronized`​**​**解决方案（对象锁、互斥锁）**

  - **4.2.1 基本**

    - 用对象锁保证了临界区内代码的原子性（即使指令交错运行了，别的线程也开不了锁）
    - 要加必须多个线程一起加锁，不然等于没锁，因为没加锁的线程不会尝试获取锁而变成 block 状态（锁本身就是一种资源，没有得到除了 cpu 之外的资源就不会是可运行状态）
    - ```java
         static int counter = 0;
         static final Object lock = new Object();
              for (int i = 0; i < 5000; i++) {
                  synchronized (lock) { // 多个线程锁的是同一个对象
                      counter--; // 临界区代码
                  }}
      ```
  - **4.2.2** **​`synchronized`​**​**面向对象改进**

    - ```java
      class Test {
              public void test(){
                  synchronized(this){
                      // 临界区代码
                  }
      ```
  - **4.2.3** **​`synchronized`​**​**加在方法上**

    - 加在成员方法上等同于4.2.2，锁住当前实例对象

      - ```java
        class Test {
                public synchronized void test(){
                       // 临界区代码
                    }
                }
        ```
    - 加在静态方法上，锁的是类对象

      - ```java
        class Test {
                public synchronized static void test(){
                     // 临界区代码
                    }
                }

        // 等同于

        class Test {
                public void test(){
                    synchronized(Test.class){ 
                        // 临界区代码
                    }
        // JDK8 以后类对象存在本地内存的元空间， JDK7及之前存在堆中的永久代
        // Test.class 文件是静态的蓝图，Test.class对象代表了 Test 这个类，包含了 Test 类的所有信息，反射靠的就是这个对象
        ```
  - **4.2.4 变量的线程安全**

    - **成员变量和静态变量是否线程安全？**

      - 如果它们没有共享，则线程安全
      - 如果它们被共享了，根据它们的状态是否能够改变，又分两种情况：

        - 如果只有读操作，则线程安全
        - 如果有读写操作，则这段代码是临界区，需要考虑线程安全
    - **局部变量（在方法内部定义的变量（包括方法的参数））是否线程安全？**

      - 局部变量是线程安全的
      - 但局部变量引用的对象则未必：

        - 如果该对象没有逃离方法的作用范围，它是线程安全的
        - 如果该对象逃离方法的作用范围，需要考虑线程安全
      - 常见的线程安全类

        - String（因为是不可变类，修改靠复制，不改原来的字符串对象）、Integer（不可变类）、StringBuffer、Random、Vector、Hashtable、java.util.concurrent 包下的类
        - 这里说它们是线程安全的是指，多个线程调用它们同一个实例的某个方法时，是线程安全的。也可以理解为：

          - 它们的每个方法是原子的

            - ```java
              Hashtable table = new Hashtable();

              new Thread(() -> {
                  table.put("key", "value1");
              }).start();

              new Thread(() -> {
                  table.put("key", "value2");
              }).start();
              ```
          - 但注意它们多个方法的组合不是原子的，如线程1和2分别table.get和table.put，会导致竞态条件，即使每个方法本身是线程安全的。
  - **4.2.5 三种锁的概念**

    - **Java 对象头（以32位虚拟机为例）**

      - ![6a05ab2b-950d-47a4-a604-9c16ef9eff26](assets/6a05ab2b-950d-47a4-a604-9c16ef9eff26-20251109230424-1fesbfx.png)

        其中 Mark Word 结构为：
      - ![image](assets/image-20251109231158-bjt5d3o.png)
    - **Monitor（重量级锁）**

      - ![image](assets/image-20251109231345-k47p1v9.png)

        - **Monitor (监视器):**  `synchronized`​ 锁定的 `obj` 对象会关联一个 Monitor。

          <span data-type="text" style="color: var(--b3-font-color5); font-size: 13px;">Monitor 是系统提供的， obj 是 Java 中的</span>
        - **Owner (持有者):**  只有一个<span data-type="text" style="color: var(--b3-font-color8);">线程</span>能成为 `Owner`，它代表当前持有锁的线程。
        - **EntryList (入口列表):**  其它尝试获取锁（执行 `synchronized(obj)`​）但失败的线程，会在这里排队竞争 CPU 时间片。它们的状态会变为 **​`BLOCKED`​** (阻塞)。

          <span data-type="text" style="font-size: 13px; color: var(--b3-font-color5);">非公平的，不一定先进来排队的就先获得 CPU 时间片，得看系统调度</span>
        - **WaitSet (等待集合):**  已经持有锁的线程（即 `Owner`​），如果它调用了 `obj.wait()`​ 方法，它会释放锁，并进入 `WaitSet`​。它的状态会变为 **​`WAITING`​** (等待)。
        - **MarkWord (标记词):**  `obj`​ 对象头（Object Header）里的 `MarkWord`​ 存储了该对象的锁状态，在重量级锁状态下，它会存储一个指向这个 `Monitor` 的指针，同时最后两位置为 10。
      - 进入同一个对象才能关联同一个 Monitor，不加**​`synchronized`​**的对象不会关联Monitor
    - **轻量级锁**

      - 轻量级锁的使用场景：如果一个对象虽然有多线程访问，但多线程访问的时间是错开的（也就是没有竞争），那么可以使用轻量级锁来优化
      - 轻量级锁对使用者是透明的，即语法仍然是**​`synchronized`​**
      - 轻量级锁的创建过程：

        - 1. 线程在**自己的虚拟机栈的栈帧**中创建锁记录（Lock Record），每个线程的栈帧都会包含一个锁记录的结构，内部可以存储被锁定对象的 Mark Word，作为这个创建过程的一部分，JVM会立即将这个 `Lock Record`​ 中的 `Object Reference`​ 字段设置（即写入）为指向目标锁对象 `obj` 的指针

             1. `Lock Record`​​​​​​<span data-type="text" style="font-size: 13px;"> -&gt; </span>`Object`​​​​​​<span data-type="text" style="font-size: 13px;"> 的指针：线程用它来</span>**管理自己的解锁**
             2. `Object`​​​​​​<span data-type="text" style="font-size: 13px;"> -&gt; </span>`Lock Record`​​​​​​<span data-type="text" style="font-size: 13px;"> 的指针：告诉其他线程当前被哪个线程占有</span>

                - **触发“锁膨胀”：** <span data-type="text" style="font-size: 13px;"> </span>`Thread-1`​​​​​​<span data-type="text" style="font-size: 13px;"> 的 CAS 失败，这个</span>**失败信号**<span data-type="text" style="font-size: 13px;">就是“竞争”的证明，它会触发 JVM 把锁升级成重量级锁（</span>`Monitor`​​​​​​<span data-type="text" style="font-size: 13px;">）。</span>
                - **实现“锁重入”：** <span data-type="text" style="font-size: 13px;"> 如果 </span>`Thread-0`​​​​​​<span data-type="text" style="font-size: 13px;"> 再次进入 </span>`synchronized`​​​​​​<span data-type="text" style="font-size: 13px;"> 块（锁重入），它也会去 CAS。它也会</span>**失败**<span data-type="text" style="font-size: 13px;">，但 JVM 接着会检查：“虽然失败了，但 </span>`MarkWord`​​​​​​<span data-type="text" style="font-size: 13px;"> 里这个指针是不是指向</span>**我自己**<span data-type="text" style="font-size: 13px;">的 </span>`Lock Record`​​​​​​<span data-type="text" style="font-size: 13px;">？” JVM 发现“是”，就知道这是合法的“重入”，而不是“竞争”。</span>

                   ![886b0bce-8a3e-46b5-aa66-788d529c9909](assets/886b0bce-8a3e-46b5-aa66-788d529c9909-20251110045347-lf17g4j.png)
        - 2. JVM 紧接着就需要使用这个 Object Reference 指针去访问 obj 对象的 Mark Word，**先检查对象的 Mark Word**，如果对象是“无锁”状态（`...01`），尝试用 cas 替换 Object 的 Mark Word，将 Mark Word 的值存入锁记录

             ![b42132b1-8333-4acb-a42a-e173645ddfe7](assets/b42132b1-8333-4acb-a42a-e173645ddfe7-20251110045541-len4bo4.png)
        - 3. 如果 cas 交换成功，对象头中存了锁记录地址和状态 00，则代表该线程给对象加轻量级锁成功，此时如图所示![d087c033-c69a-4420-967c-92d32731c67b](assets/d087c033-c69a-4420-967c-92d32731c67b-20251110051529-qpi0drz.png)
          4. 如果对象是“轻量级锁定”状态（`...00`）： 线程不会立即CAS，而是会先检查 Mark Word 里的指针：

             - 如果这个指针指向**其它线程**的栈帧，JVM才知道“锁被别人占了”，这**才是竞争**，此时才会触发锁膨胀。
             - 如果这个指针指向自己线程栈的某个锁记录，JVM就知道“这是自己人”，即锁重入。那么再添加一条 Lock Record 作为重入的计数![510b7628-19ba-4040-9c2b-e757ead77f26](assets/510b7628-19ba-4040-9c2b-e757ead77f26-20251110051918-zrtk3f4.png)
          5. 当退出 **​`synchronized`​**​ 代码块（解锁时），如果有取值为 null 的锁记录，表示有重入，这时重置锁记录，表示重入计数减一![8be1c137-45ec-4f9d-a0c7-7fce20fbf8c0](assets/8be1c137-45ec-4f9d-a0c7-7fce20fbf8c0-20251110052150-mac9bxi.png)
          6. 当退出 **​`synchronized`​** 代码块（解锁时），锁记录的值不为 null，这时使用 cas 将 Mark Word 的值恢复给对象

             - 成功，则解锁成功
             - 失败，说明轻量级锁进行了锁膨胀或已经升级为重量级锁，进入重量级锁的解锁流程
    - **锁膨胀：**

      - 有竞争，轻量级锁升级为重量级锁
      - 锁膨胀过程：

        1. obj 的 mark word 已经是 00 了，指向 Thread-0 的 Lock Record， Thread-1 此时进入锁膨胀流程
        2. JVM 意识到“有竞争”，轻量级锁不够用了，在**堆**中创建一个完整的 **​`Monitor`​**​ **对象**
        3. JVM 找到持有锁的Thread-0，**从Thread-0 的** **​`Lock Record`​**​ **中，取出那个“原始 MarkWord”** 。**把这个“原始 MarkWord”复制并存储到新创建的** **​`Monitor`​**​ **对象的内部**（比如 `_header` 字段）。
        4. JVM **修改** **​`obj`​**​ **的** **​`MarkWord`​**​，使其**指向这个新的** **​`Monitor`​**​ **对象**，并将锁标志位设为 `10`（重量级锁）。
        5. Thread-1 被放入这个 `Monitor`​ 的 `EntryList`​ 中，变为 `BLOCKED`​。![63aca96b-1f37-4cf4-b3f0-184d4120b0b7](assets/63aca96b-1f37-4cf4-b3f0-184d4120b0b7-20251110195736-belyxc3.png)
        6. 当 Thread-0 退出同步块解锁时，使用 cas 将 Mark Word 的值恢复给对象头，失败。这时会进入重量级解锁流程，即按照 Monitor 地址找到 Monitor 对象，设置 Owner为null，唤醒 EntryList中 BLOCKED 线程
    - **自旋优化**

      - 重量级锁竞争的时候，还可以使用自旋来进行优化，如果当前线程先不进入Monitor的 Entry List，一直尝试获取 Monitor 锁，如果自旋成功（即这时候持锁线程已经退出了同步块，释放了锁），这时当前线程就可以避免阻塞。

        <span data-type="text" style="color: var(--b3-font-color5); font-size: 13px;">在Java6之后自旋锁是自适应的，比如对象刚刚的一次自旋操作成功过，那么认为这次自旋成功的可能性会高，就多自施几次；反之，就少自旋甚至不自旋，总之，比较智能。
        自旋会占用 CPU 时间，单核 CPU 自旋就是浪费，多核CPU 自旋才能发挥优势</span>
    - **偏向锁**

      <span data-type="text" style="color: var(--b3-font-color5); font-size: 13px;">偏向锁在现代Java中已被移除</span>

      - 偏向锁的状态

        - ![b86694c3-bfe8-440b-89f4-fda23d7d2bd3](assets/b86694c3-bfe8-440b-89f4-fda23d7d2bd3-20251110201120-9e0g7xu.png)
        - 对象头格式（64位）![image](assets/image-20251110202028-jqpaxia.png)

          一个对象创建时：

          - 如果开启了偏向锁（默认开启），那么对象创建后，markword 值为 `0x05`​ 即最后 3 位为 `101`，这时它的 thread、epoch、age 都为 0
          - 偏向锁默认是延迟的，不会在程序启动时立即生效，如果想避免延迟，可以加 VM 参数 `-XX:BiasedLockingStartupDelay=0` 来禁用延迟

            <span data-type="text" style="font-size: 13px; color: var(--b3-font-color5);">在JVM启动的头几秒内“暂停”了偏向锁这个功能，是JVM基于“程序刚启动时，线程竞争比较激烈，不适合用偏向锁”的假设，而做的一个优化。</span>

            - **对于新对象：** <span data-type="text" style="font-size: 13px;"> 此时新创建的对象，其Mark Word会是**“可偏向（匿名偏向）”**状态（</span>`101`​​​​​​<span data-type="text" style="font-size: 13px;">），正如您的第1点所说。</span>
            - **对于【在延迟期创建的】旧对象：** <span data-type="text" style="font-size: 13px;"> 它们被创建时是“无锁”状态（</span>`001`​​​​​​<span data-type="text" style="font-size: 13px;">）。</span>
            - <span data-type="text" style="font-size: 13px;">如果在延迟时间结束后（比如第5秒），一个线程</span>**第一次**<span data-type="text" style="font-size: 13px;">尝试去锁那个**在第1秒被创建的、状态为</span>`001`​​​​​​<span data-type="text" style="font-size: 13px;">**的对象时，JVM会检查到：</span>

              - (a) 全局偏向锁开关​**已打开**。
              - <span data-type="text" style="font-size: 13px;">(b) 这个对象的状态是</span>`001`​​​​​​<span data-type="text" style="font-size: 13px;">（无锁）。</span>
              - <span data-type="text" style="font-size: 13px;">(c) 这是它的</span>**第一次**<span data-type="text" style="font-size: 13px;">加锁。</span>

              <span data-type="text" style="font-size: 13px;">JVM</span>**仍然会尝试**<span data-type="text" style="font-size: 13px;">将这个对象从“无锁”(</span>`001`​​​​​​<span data-type="text" style="font-size: 13px;">)状态</span>**直接变为“偏向锁”** <span data-type="text" style="font-size: 13px;">(</span>`101`​​​​​​<span data-type="text" style="font-size: 13px;">，并记录当前线程ID)。</span>
          - 如果没有开启偏向锁，那么对象创建后，markword 值为 `0x01`​ 即最后 3 位为 `001`，这时它的 hashcode、age 都为 0，第一次用到 hashcode 时才会赋值
        - **偏向锁工作原理：**

          1. **初次加锁：**

             - 一个对象（比如 `Dog d`​）刚被创建时，它的 `MarkWord`​（对象头）最后 3 bit 是 `101`​ (可偏向状态)，`ThreadID` 为空。
             - 线程 A 第一次执行 `synchronized(d)`。
             - JVM 发现 `d`​ 可偏向且 `ThreadID`​ 为空，于是通过 **CAS** 操作，把**线程 A 的 ID** 写入 `d`​ 的 `MarkWord`。
             - 此时，`d`​  **“偏向”**  了线程 A。
          2. **后续加锁（“快路径”）：**

             - 线程 A **再次**执行 `synchronized(d)`（包括锁重入）。
             - 线程 A 检查 `d`​ 的 `MarkWord`​，发现 `ThreadID`​ ​**就是自己**。
             - **JVM 此时什么也不用做！**  既没有 CAS，也没有 `Lock Record`​，也没有 `Monitor`。
             - 这个检查​**几乎没有开销**，这就是偏向锁“快”的根源。

          - **解锁：** 当线程 A 退出 `synchronized`​ 块时，它也​**什么都不用做**​。`MarkWord`​ 保持不变，`d`​ 对象​**依然偏向着线程 A**，等待 A 下次再来。
      - **偏向锁的撤销**

         **“撤销”就是当“偏向”出错时，纠正这个错误的过程。**

        - **触发时机：** 当​**另一个线程**​（比如线程 B）**也来尝试获取**这个锁（`synchronized(d)`）时。
        - **撤销过程（非常昂贵）：**

          1. 线程 B 检查 `d`​ 的 `MarkWord`​，发现 `ThreadID`​ 是线程 A 的，​**不是自己的**。
          2. 线程 B 知道偏向错了，它不能继续。它必须​**触发一次“安全点” (Safepoint)** 。
          3. **触发安全点意味着 JVM 会暂停所有应用线程！** （Stop-The-World, STW）。
          4. JVM 在这个暂停期间，找到 `d` 对象，并检查那个“被偏向的”线程 A 的状态：

          - **情况一 (最常见)：线程 A 已经退出了** **​`synchronized`​**​ **块。**

            - **动作：**  锁是自由的。JVM **撤销**偏向，将 `d`​ 的 `MarkWord`​ 恢复为“​**可偏向**​”状态（`...101`​，`ThreadID` 为空）。
            - **后续：**  安全点结束，所有线程恢复。线程 B 重新尝试加锁，发现 `d`​ 可偏向，于是通过 CAS 把它偏向​**自己**。
          - **情况二：线程 A 仍然在** **​`synchronized`​**​ **块内部。**

            - **动作：**  证明​**真的产生了竞争**​。偏向锁优化失败，必须​**锁升级**。
            - JVM 将锁**膨胀**为​**轻量级锁**​（就是你之前发的 `Lock Record` 图）。
            - `d`​ 的 `MarkWord`​ 被改成指向线程 A 栈上的 `Lock Record`​（状态位 `00`）。
            - **后续：**  安全点结束。线程 B 重新尝试加锁，发现锁是 `00`（轻量级锁），于是开始“自旋”等待。

        **关键点：**  偏向锁的“快”，代价是它的“撤销”​**非常非常慢**，因为它需要暂停一切 (Safepoint)。
      - **偏向锁的批量重偏向**

         **“批量重定向”是为了解决“一个类（Class）的对象，先后被不同线程访问”的优化。**

        - **场景：**  想象一个线程 A 创建了一个 `ArrayList<Dog>`​，并循环锁了里面所有的 `Dog`​。然后线程 A 结束，线程 B 开始循环锁这个 `ArrayList<Dog>`​ 里的所有 `Dog`。
        - **问题：**  按照上面的“撤销”逻辑，线程 B **每**访问一个 `Dog`​，就会触发一次昂贵的**安全点 (Safepoint)**  和​**撤销**​。如果 `ArrayList`​ 里有 1000 个 `Dog`，就会触发 1000 次 STW，程序会卡死。
        - **解决方案 (批量重定向)：**

          1. JVM **按“类” (**​**​`Dog.class`​**​ **)**  来**统计**撤销次数。
          2. 当 `Dog.class` 的撤销次数达到一个阈值（比如 20 次）时，JVM 认为“这个类的锁模式变了”。
          3. JVM 触发一次安全点。它**不会**再一个个地撤销，而是会执行“批量重定向”：

             - 它会找到所有​**活着的、偏向线程 A 的** **​`Dog`​**​ **对象**。
             - 它会**批量**将这些 `Dog`​ 对象的 `MarkWord`​ **重置**为“​**可偏向**​”状态（`...101`​，`ThreadID` 为空）。
             - （​*在更底层的实现中，它会通过修改* *​`MarkWord`​*​ *里的* *​`epoch`​*​ *（纪元）来实现这一点，但效果等同于“批量重置”。* ）
          4. **结果：**  安全点结束后，线程 B 继续循环，它遇到的所有 `Dog`​ 对象都已经是“可偏向”状态了。线程 B 只需要一次 CAS 就可以将它们偏向自己，​**再也不会触发安全点了**。
      - **偏向锁的批量撤销**

         **“批量撤销”是“批量重定向”之后的最终放弃。**

        - **场景：**  JVM 刚刚为 `Dog.class`​ 做了一次“批量重定向”。结果没过多久，线程 C 又来了，又开始循环锁这些 `Dog`​，导致 `Dog.class`​ 的撤销次数再次达到一个**更高的**阈值（比如 40 次）。
        - **JVM 的决定：**  JVM 彻底放弃了。它认为 `Dog.class`​ 这种对象​**根本就不适合使用偏向锁**（比如它们总是被用在生产者-消费者队列里）。
        - **解决方案 (批量撤销)：**

          1. JVM 再次触发安全点。
          2. 它​**修改** **​`Dog.class`​**​ **在 JVM 内部的元数据**​，**永久关闭** `Dog.class` 的偏向锁功能。
          3. **结果：**

             - 从今往后，所有**新创建**的 `Dog`​ 对象（`new Dog()`​），其 `MarkWord`​ ​**一出生就是“无锁”态**​（`...001`，不可偏向）。
             - 任何线程（A, B, C）再来锁 `Dog`​ 对象时，都会**跳过偏向锁**，**直接**进入**轻量级锁**（`Lock Record`）阶段。
    - **wait 和 notify**

      - ![437a919b-3595-4013-8261-b10e56638c35](assets/437a919b-3595-4013-8261-b10e56638c35-20251110224703-pzmj8ps.png)

        - Owner 线程发现条件不满足，调用 wait 方法，即可进入 WaitSet 变为 WAITING 状态
        - BLOCKED 和 WAITING 的线程都处于阻塞状态，不占用 CPU 时间片
        - BLOCKED 线程会在 Owner 线程释放锁时唤醒
        - WAITING 线程会在 Owner 线程调用 notify 或 notifyAll 时唤醒，但唤醒后并不意味着立刻获得锁，仍需进入 EntryList 重新竞争
      - API 介绍

        - **​`obj.wait()`​**  - 将当前线程挂起，并释放其持有的对象锁（monitor），使该线程进入该对象的 Wait Set 中，直到被其他线程唤醒
        - **​`obj.wait(long timeout)`​** ​ - 让进入 object 监视器的线程到 waitSet 等待，最多等待指定的毫秒数，如果在超时时间内被 `notify()`​/`notifyAll()` 唤醒，线程会提前返回，如果超时时间到达仍未收到通知，线程会自动唤醒并重新竞争锁
        - **​`obj.notify()`​** ​ - **随机**唤醒一个正在该对象 Wait Set 中等待的线程。被唤醒的线程进入 EntryList，在 EntryList 中，该线程与其他所有尝试获取该对象锁的线程平等竞争，只有成功获得对象锁后，线程才能从 `wait()` 方法返回，继续执行后续代码
        - **​`obj.notifyAll()`​**  - 唤醒所有正在该对象 Wait Set 中等待的线程。这些线程被唤醒后需要竞争对象锁，获得锁的线程才能继续执行。
        - 它们都是线程之间进行协作的手段，都属于 Object 对象的方法。**必须成为该对象 monitor 的 Owner，才能调用这几个方法。**
        - ```java
          public class TimedWaitExample {
              private final Object lock = new Object();// 加 final 保证引用不会换，不然锁住的有可能就不是一个对象了
              
              public static void main(String[] args) {
                  new Thread(() -> {
                      synchronized(lock) {
                          try {
                              lock.wait(); // 等待通知
                          } catch (InterruptedException e) {}
                          System.out.println("被唤醒了");
                      }
                  }).start();
                  
                  Thread.sleep(1000); // 主线程睡眠1秒
                  
                  synchronized(lock) {
                      lock.notify(); // 唤醒一个等待线程
                  }
              }
          }
          ```
      - **​`sleep(long n)`​** ​ **和** **​`wait(long n)`​** ​ **的区别：**

        1. `sleep`​ 是 Thread 类的静态方法，而 `wait` 是 Object 的实例方法
        2. `sleep`​ 不需要强制和 `synchronized`​ 配合使用，但 `wait`​ 必须在 `synchronized` 代码块内使用
        3. `sleep`​ 在睡眠期间**不会释放**对象锁，而 `wait`​ 在等待期间**会释放**对象锁
        4. **共同点**：它们都是 TIME_WAITING，都是有时限的等待
- **Park 和 Unpark**

  - ```java
    // 暂停当前线程：检查 _counter，如果是 0，就睡觉；如果是 1，就把它设为 0，然后直接返回（不睡觉）
    LockSupport.park();

    // 恢复某个线程的运行：把 _counter 设为 1（并唤醒线程，如果它在睡的话）
    LockSupport.unpark(暂停线程对象);
    ```
    - `park`​写在要暂停的线程，`unpark`​写在其他线程，`LockSupport.unpark(t1);`
    - `Unpark`​可以在 `park`前就调用
    - 是 RUNNABLE 和 WAITING 状态的来回转换

      - `park`​ 机制有它自己**独立于** **​`synchronized`​**​ **的实现**（`_counter`​, `_mutex`​, `_cond`）。
      - 它等待的不是 `synchronized`​ 监视器锁，而是那个 `_counter` 许可。
      - 当线程调用 `parkNanos(n)`​ 并且发现没有许可 (`_counter == 0`​) 时，它会​**直接从** **​`RUNNABLE`​**​ **切换到** **​`TIMED_WAITING`​**。
      - 它**不会**进入 `EntryList`​，状态也​**不是** **​`BLOCKED`​**。
  - 特点：与 Object 的 wait & notify 相比：

    - **锁要求不同**  
      wait, notify 和 notifyAll 必须配合 Object Monitor 一起使用，而 park & unpark 不必
    - **精确性不同**  
      park & unpark 是以线程为单位来【阻塞】和【唤醒】线程，而 notify 只能随机唤醒一个等待线程，notifyAll 是唤醒所有等待线程，就不那么【精确】
    - **时序灵活性不同**  
      park & unpark 可以先 unpark，而 wait & notify 不能先 notify
  - **Park 和 Unpark 原理**

    - ![2b1fdbe4-33ab-422a-a120-24e44826cfbe](assets/2b1fdbe4-33ab-422a-a120-24e44826cfbe-20251111015713-8kgxseq.png)每个线程（`Thread-0`​）都有一个关联的 `Parker-0`​ 对象，这个对象内部最关键的变量就是 `_counter`

      - `_mutex`​：是一把​**锁**​，用来保护 `_counter` 变量，确保同一时间只有一个线程能修改它。
      - `_cond`​：是一个​**等待队列/休息室**​，线程可以在这里面“睡觉”（`wait`​），并等待其他人来“唤醒”（`signal`）。

      - `_counter`​ **就是“许可”** ，值**只能是 0 或 1**。（多 Unpark 也不会超过1）
    - **Park 和 Unpark** 两种执行流程

      #### 流程一：先 `unpark`​ (1) -\> 后 `park` (2)

      这就是“信号不会丢失”的情况：

      1. **​`Unsafe.unpark(Thread_0)`​** ​ **：**  “送烟”线程先执行了 `unpark`​。这个动作**将**  **​`_counter`​**​ **的值设置为 1**。
      2. **​`Unsafe.park`​**​ **：**  随后，“小南”线程（`Thread-0`​）执行 `park`，想要“睡觉”。
      3. **​`park`​**​ **的内部检查：**  `park`​ 方法首先会检查 `_counter` 的值。
      4. **消费许可：**  `park`​ 发现 `_counter`​ **已经是 1** 了！它会“哦，我有一个许可，那我不用睡了。”

         - 于是它​**立即将**  **​`_counter`​**​ **消费掉（设置回 0）** 。
         - 然后 `park`​ 方法​**立即返回**​（`Thread-0` 根本不会被阻塞）。

      > **这就是** **​`unpark`​**​ **可以先于** **​`park`​**​ **执行的原理。**  `_counter = 1`​ 就像一个“通行证”，让后来的 `park` 调用直接通过。
      >

      ---

      #### 流程二：先 `park`​ (2) -\> 后 `unpark` (1)

      这是更常见的“先等待，后唤醒”的情况：

      1. **​`Unsafe.park`​**​ **：**  “小南”线程（`Thread-0`​）先执行 `park`。
      2. **​`park`​**​ **的内部检查：**  `park`​ 发现 `_counter`​ **是 0**（默认值，没有许可）。
      3. **进入阻塞：**  `park`​ 方法会让 `Thread-0`​ ​**进入阻塞状态**​（`Thread-0`​ 挂起，不再消耗 CPU）。（这在图中是通过 `_mutex`​ 和 `_cond`​ 实现的，`_cond` 是一个条件变量，线程会在它上面等待）。
      4. ... (线程在 `park`​ 处“卡住”了，等待别人 `unpark`)...
      5. **​`Unsafe.unpark(Thread_0)`​** ​ **：**  “送烟”线程执行 `unpark`。

         - `unpark`​ ​**将**  **​`_counter`​**​ **设置为 1**。
         - 同时，`unpark`​ ​**会发出一个信号**​（`signal _cond`​），去唤醒那个正在 `_cond`​ 上等待的 `Thread-0`。
      6. **线程被唤醒：**  `Thread-0`​ 被唤醒，从 `park` 方法中恢复执行。
      7. **消费许可：**  线程醒来后的第一件事，就是​**将**  **​`_counter`​**​ **设置回 0**（消费这个唤醒它的许可）。
      8. `park`​ 方法返回，`Thread-0` 继续执行后续代码。

         完整的 `park`​ / `unpark`​ 流程（带 `_mutex`​ 和 `_cond`）

         #### 场景：先 `park`​（睡觉），后 `unpark`（唤醒）

         **1. "小南" (Thread-0) 调用** **​`park()`​** ​ **：**

         1. `park`​ 方法首先尝试获取 `_mutex` 锁。（成功）
         2. 它检查 `_counter`，发现是 0。
         3. 它决定睡觉。于是它调用 `_cond.wait()`。
         4.  **【关键】**  `_cond.wait()`​ ​**立即释放**  **​`_mutex`​**​ **锁**​，同时 `Thread-0`​ 线程挂起，进入 `_cond` 的等待队列中睡觉。

         **2. "送烟" 线程调用** **​`unpark(Thread-0)`​** ​ **：**

         1. `unpark`​ 方法首先尝试获取 `_mutex` 锁。（成功，因为 "小南" 已经释放了它）
         2. 它将 `_counter` 设置为 1。
         3. 它调用 `_cond.signal()`​（或 `_cond.broadcast()`​），​**向**  **​`_cond`​**​ **等待队列发信号**：“嘿，里面睡觉的人，醒醒！”
         4. `unpark`​ 方法释放 `_mutex` 锁。

         **3. "小南" (Thread-0) 被唤醒：**

         1. "小南" 收到了 `signal`​ 信号，他​**准备从**  **​`_cond.wait()`​** ​ **中返回**。
         2.  **【关键】**  他​**不会立即返回**​！他必须​**重新尝试获取**  **​`_mutex`​**​ **锁**。
         3. 一旦 "送烟" 线程释放了锁，"小南" 就能成功获取锁。
         4. "小南" 成功拿到锁后，`_cond.wait()` 才算正式返回。
         5. `park`​ 方法继续执行，它把 `_counter` 消费掉（设回 0）。
         6. `park`​ 方法释放 `_mutex` 锁。
         7. `park` 方法执行完毕，"小南" 线程继续执行后续代码。
  - **线程状态转换**

    - ![62328b73-a7ae-42cd-ac3e-3a5919b5d13d](assets/62328b73-a7ae-42cd-ac3e-3a5919b5d13d-20251109150420-ar5yfhr.png)

      - **情况 2：RUNNABLE ↔ WAITING**

        t 线程用 `synchronized(obj)` 获取对象锁后：

        - 调用 `obj.wait()`​ 方法时，t 线程从 **RUNNABLE → WAITING**
        - 调用 `obj.notify()`​, `obj.notifyAll()`​, `t.interrupt()` 时：

          - 竞争锁成功，t 线程从 **WAITING → BLOCKED→**  **RUNNABLE**

            <span data-type="text" style="font-size: 13px; color: var(--b3-font-color5);">一个线程被 </span>`notify()`​​<span data-type="text" style="font-size: 13px; color: var(--b3-font-color5);"> 选中后，它</span>**不会**<span data-type="text" style="font-size: 13px; color: var(--b3-font-color5);">立即变为 </span>`RUNNABLE`​​<span data-type="text" style="font-size: 13px; color: var(--b3-font-color5);">状态，因为它</span>**必须**<span data-type="text" style="font-size: 13px; color: var(--b3-font-color5);">重新去竞争它当初 </span>`wait()`​​<span data-type="text" style="font-size: 13px; color: var(--b3-font-color5);"> 时释放的那个锁，必须得先进 EntryList 变成 BLOCKED 状态</span>
          - 竞争锁失败，t 线程从 **WAITING → BLOCKED**

            `room.notifyAll()`​​<span data-type="text" style="color: var(--b3-font-color5); font-size: 13px;">时，JVM 会把 </span>`WaitSet`​​<span data-type="text" style="color: var(--b3-font-color5); font-size: 13px;"> 中所有线程（包括“小南”）</span>**立即移动到**<span data-type="text" style="color: var(--b3-font-color5); font-size: 13px;"> </span>**​`EntryList`​**​<span data-type="text" style="color: var(--b3-font-color5); font-size: 13px;">，</span>**就在这一瞬间**<span data-type="text" style="color: var(--b3-font-color5); font-size: 13px;">，“小南”的线程状态从 </span>`WAITING`​​<span data-type="text" style="color: var(--b3-font-color5); font-size: 13px;"> </span>**变为**<span data-type="text" style="color: var(--b3-font-color5); font-size: 13px;"> </span>**​`BLOCKED`​**​<span data-type="text" style="color: var(--b3-font-color5); font-size: 13px;">。</span>**为什么是**<span data-type="text" style="color: var(--b3-font-color5); font-size: 13px;"> </span>**​`BLOCKED`​**​ **？** <span data-type="text" style="color: var(--b3-font-color5); font-size: 13px;"> 因为 </span>`EntryList`​​<span data-type="text" style="color: var(--b3-font-color5); font-size: 13px;"> 里的所有线程都在等待获取 </span>`room`​​<span data-type="text" style="color: var(--b3-font-color5); font-size: 13px;"> 锁。</span>**锁在哪里？** <span data-type="text" style="color: var(--b3-font-color5); font-size: 13px;"> 锁还在“送烟”线程手里（它还没执行到 </span>`synchronized`​​<span data-type="text" style="color: var(--b3-font-color5); font-size: 13px;"> 的 </span>`}`​​<span data-type="text" style="color: var(--b3-font-color5); font-size: 13px;">）。</span>
          - 详细流程

            - **​`WAITING`​**​ **状态 (在** **​`WaitSet`​**​ **中)**

              - 一个线程（比如“小南”）调用了 `room.wait()`。
              - 它会​**释放** **​`room`​**​ **锁**​，并进入 `room`​ 对象的 `WaitSet` (等待集)。
              - 此时，“小南”的线程状态是 `WAITING`​。它在等待一个 `notify`​ 或 `notifyAll` 信号。
            - **​`notifyAll()`​** ​ **被调用 (从** **​`WaitSet`​**​ **移动到** **​`EntryList`​**​ **)**

              - “送烟”线程（它​**正持有** **​`room`​**​ **锁**​）调用了 `room.notifyAll()`。
              - JVM 会把 `WaitSet`​ 中所有线程（包括“小南”）**立即移动到** **​`EntryList`​** (入口集)。
              - **就在这一瞬间**​，“小南”的线程状态从 `WAITING`​ ​**变为** **​`BLOCKED`​**。
            - **​`BLOCKED`​**​ **状态 (在** **​`EntryList`​**​ **中)**

              - **为什么是** **​`BLOCKED`​**​ **？**  因为 `EntryList`​ 里的所有线程都在等待获取 `room` 锁。
              - **锁在哪里？**  锁还在“送烟”线程手里（它还没执行到 `synchronized`​ 的 `}`）。
              - 所以，“小南”和其他被唤醒的线程因为​**拿不到锁**​，100% 处于 `BLOCKED`（阻塞）状态。
            - **锁被释放 (从** **​`BLOCKED`​**​ **到** **​`RUNNABLE`​**​ **)**

              - “送烟”线程执行完毕，到达 `}`​，​**释放** **​`room`​**​ **锁**。
              - JVM 从 `EntryList` 中挑选一个线程（可能是“小南”，也可能是其他被唤醒或刚到来的线程）来获取锁。
              - 假设“小南”被选中了。
              - “小南”​**成功获取** **​`room`​**​ **锁**。
              - “小南”的线程状态从 `BLOCKED`​ ​**变为** **​`RUNNABLE`​**。
              - 它从 `room.wait()`​ 调用的地方“醒来”，继续执行 `while` 循环的条件检查。
      - **情况 3：RUNNABLE ↔ WAITING**

        - `t.join()`

          - 当前线程调用 `t.join()`​ 方法时，**当前线程**从 RUNNABLE → WAITING
          - 注意是当前线程在 t 线程对象的监视器上等待
          - t 线程运行结束，或调用了当前线程的 `interrupt()` 时，当前线程从 WAITING → RUNNABLE
        - `LockSupport.park()`

          - 当前线程调用 `LockSupport.park()` 方法会让当前线程从 RUNNABLE → WAITING
          - 调用 `LockSupport.unpark(目标线程)`​ 或调用了线程的 `interrupt()`，会让目标线程从 WAITING → RUNNABLE
      - **情况 5：RUNNABLE ↔ TIMED_WAITING**

        - `obj.wait(long n)`
        - `t.join(long n)`

          - 当前线程调用 `t.join(long n)` 方法时，当前线程从 RUNNABLE → TIMED_WAITING

            - 注意是当前线程在 t 线程对象的监视器上等待
          - 当前线程等待时间超过了 n 毫秒，或 t 线程运行结束，或调用了当前线程的 `interrupt()` 时，当前线程从 TIMED_WAITING → RUNNABLE
        - `Thread.sleep(long n)`

          - 当前线程调用 `Thread.sleep(long n)`，当前线程从 RUNNABLE → TIMED_WAITING
          - 当前线程等待时间超过了 n 毫秒，当前线程从 TIMED_WAITING → RUNNABLE
        - `LockSupport.parkNanos(long nanos)`​ 或 `LockSupport.parkUntil(long millis)`
- **​`ReentrantLock`​**

  - 相对于 `synchronized`，它具备如下特点：

    - 可中断（A 线程拥有锁，B 线程可中断）
    - 可以设置超时时间（规定时间内获取不到锁就放弃争抢锁了，执行其他逻辑）
    - 可以设置为公平锁（先到先得）（但默认也是不公平的）
    - 支持多个条件变量（多个 WaitSet）
  - 与 `synchronized` 一样，都支持可重入

    - 可重入是指<span data-type="text" style="color: var(--b3-font-color8);">同一个线程</span>如果首次获得了这把锁，那么因为它是这把锁的拥有者，因此有权利再次获取这把锁。
    - 如果是不可重入锁，那么第二次获得锁时，自己也会被锁挡住。
  - 基本语法

    ```java
    static ReentrantLock lock = new ReentrantLock();
    // 获取锁
    lock.lock();
    try {
        // 临界区
    } finally {
        // 释放锁
        lock.unlock();
    }
    ```
  - **可打断（**​**​`lockInterruptibly() 和 interrupt()`​** ​ **）**

    ```java
    static ReentrantLock lock = new ReentrantLock();

    Thread t1 = new Thread(() -> {
                try {
                    // 如果没有竞争，那么此方法就会获取 lock 对象锁
                    // 如果有竞争就进入阻塞队列，可被其他线程用 interrupt 方法打断
                    lock.lockInterruptibly();
                    System.out.println(counter);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    log.debug("没有获得到锁，返回");
                    return;
                }
            });

            lock.lock();
            Thread.sleep(1000);
            t1.start();
            log.debug("打断t1");
            t1.interrupt();
    ```
  - **锁超时（**​**​`lock.tryLock(1, TimeUnit.SECONDS)`​** ​ **）**

    ```java
       Thread t1 = new Thread(() -> {
                log.debug("尝试获得锁");
                try {
                    if (!lock.tryLock(1, TimeUnit.SECONDS)) { // 只等这么久
                        log.debug("获取不到锁");
                        return;
                    }
                } catch (InterruptedException e) { // 如果 t1 线程在等待的 1 秒钟内，被其他线程调用了 t1.interrupt()，它会立即抛出 InterruptedException 异常
                    e.printStackTrace();
                    return;
                }

                try {
                    log.debug("获得到锁");
                } finally {
                    lock.unlock();
                }
            }, "t1");
    ```
    - **第 1 次尝试（主动）：**  在 `tryLock`​ 被调用的那一刻（第 0 秒），它会**立即、主动地**尝试获取一次锁。

      - 如果锁是空闲的，它就拿到了，`tryLock`​ 返回 `true`。

      **进入等待（被动）：**  如果第 1 次尝试失败了（锁被占用了），它**不会**在 1 秒后 *再* 尝试一次。

      - 相反，它会**立即**把自己放入这个锁的等待队列，并**挂起**（进入 `TIMED_WAITING`​ 状态，不是自旋不是消耗 CPU 在 `while`​ 循环里“一直尝试”），开始**被动地**等待。

      **等待的结果：**

      - **被授予锁：**  在这 1 秒的等待时间内，如果持有锁的线程调用了 `unlock()`​，`unlock`​ 会唤醒它，把锁**授予**给它。`tryLock`​ 于是返回 `true`。
      - **超时：**  如果 1 秒钟到了，它还没被授予锁，它就会被“闹钟”唤醒，放弃等待，`tryLock`​ 返回 `false`。
    - **​`lock.tryLock()`​** ​（无参）的行为是：**立即尝试获取锁一次；不等待**，获取成功返回 `true`​，失败返回 `false`​；**非阻塞**，无论能否获取锁都会立即返回
    - **​`lock()`​** ：必须获取锁，愿意无限期等待
  - **公平锁（先到先得，但一般没有必要，会降低并发度）**

    - `ReentrantLock lock = new ReentrantLock(false);`
    - `ReentrantLock` 默认是不公平的
  - **条件变量（**​**​`Condition condition1 = lock.newCondition(); await`​**​ **和** **​`signal`​**​ **）**

    `synchronized` 中也有条件变量，就是讲原理时那个 waitSet 休息室，当条件不满足时进入 waitSet 等待。

    `ReentrantLock`​ 的条件变量比 `synchronized` 强大之处在于，它是支持多个条件变量的，这就好比：

    - `synchronized` 是那些不满足条件的线程都在一间休息室等消息
    - 而 `ReentrantLock` 支持多间休息室，有专门等烟的休息室、专门等早餐的休息室、唤醒时也是按休息室来唤醒

    **使用流程：**

    - `await` 前需要获得锁
    - `await` 执行后，会释放锁，进入 conditionObject 等待
    - `await` 的线程被唤醒（或打断、或超时）去重新竞争 lock 锁
    - 竞争 lock 锁成功后，从 `await` 后继续执行

      ```java
      static ReentrantLock room = new ReentrantLock();

      public static void main(String[] args) {
          // 创建新的条件变量（休息室）
          Condition condition1 = room.newCondition();
          Condition condition2 = room.newCondition();
          
          room.lock();
          try {
              // 进入休息室等待
              condition1.await();
          } catch (InterruptedException e) {
              e.printStackTrace();
          } finally {
              room.unlock();
          }
          
          condition1.signal();
          condition1.signalAll();
      }
      ```
