1. Map 就是专门用来存放“键值对”的，在`Map<String, Object>`​ 中：`String`​就是 Key ，`Object`就是 Value

   1. 无论怎么写，判断标准只有一个：**​`put(A, B)`​** ​ **方法的第一个参数** **​`A`​**​ **就是索引。**

      - **普通 Map (**​**​`Map`​**​ **)** ​：索引（Key）可以是​**万物**​。你可以用一个 `Apple`​ 对象去查它对应的 `Price`。
      - **泛型 Map (**​**​`Map<String, ...>`​** ​ **)** ：索引（Key）被强制规定**只能是 String**。如果你试图传一个整数进去当索引，编译器直接报错，不让你运行。
   2. |**特性**|**数组 (Array) / List**|**Map (映射)**||||
      | --| --------------------| ---------------------------------------| --| --| --|
      |**索引类型**|只能是**整数**(0, 1, 2...)|可以是**任意对象**(String, Integer, 自定义对象等)||||
      |**你的例子**|`list.get(0)`|`map.get("userName")`||||
      |**索引的角色**|下标 (Index)|**键 (Key)** -\>**这就是你的**​**​`String`​**||||
      |**存储的内容**|元素 (Element)|**值 (Value)** -\>**这就是你的**​**​`Object`​**||||
2. Comparable接口：compareTo(Object o)，一旦写死，所有地方都按这个排，在**类内部**定义。Comparator比较器：compare(Object o1, Object o2)，想要什么规则就写什么规则，在**类外部**定义

   1. **情况一：用 Comparable (默认按学号排)**

      我们要修改 `Student` 类本身，让它实现接口。

      ```java
      // 1. 让类自己实现 Comparable 接口
      public class Student implements Comparable<Student> {
          String name;
          int id;
          int score;

          public Student(String name, int id, int score) { ... }

          // 2. 重写 compareTo 方法 (这是"出厂设置")
          @Override
          public int compareTo(Student other) {
              // 按照 ID 从小到大排序
              return this.id - other.id; 
          }
      }

      // 使用时：
      List<Student> list = new ArrayList<>();
      list.add(new Student("Mike", 1002, 80));
      list.add(new Student("Jane", 1001, 95));

      // 不需要传参数，因为 Student 自己知道怎么比 (按ID)
      Collections.sort(list);
      ```
   2. **情况二：用 Comparator (临时按分数排)**

      这时候我们**不需要（甚至不能）修改** `Student` 类里面的代码。我们在外部定义一个规则。

      ```java
      // 这是一个普通的 Student 类，没有实现 Comparable
      public class Student {
          String name;
          int id;
          int score;
          // ... 构造函数等
      }

      // 使用时：
      List<Student> list = new ArrayList<>();
      list.add(new Student("Mike", 1002, 80));
      list.add(new Student("Jane", 1001, 95));

      // 1. 创建一个外部的"裁判" (比较器)
      Comparator<Student> scoreComparator = new Comparator<Student>() {
          @Override
          public int compare(Student s1, Student s2) {
              // 按照 分数 从小到大排序
              return s1.score - s2.score;
          }
      };

      // 2. 排序时，把"裁判"传进去
      Collections.sort(list, scoreComparator);
      ```
   3. 为什么要有两种？（关键点）

      你可能会问：*既然 Comparable 挺好用，为什么要发明 Comparator？*

      1. **如果你无法修改源码**​： 比如你想给 Java 自带的 `String`​ 类按照“字符串长度”排序，而不是默认的字典顺序。你不能去修改 JDK 里的 `String`​ 源码，所以你只能写一个外部的 `Comparator`。
      2. **多种排序需求**： 一个类只能实现一次 `Comparable`​（只能有一个 `compareTo`​ 方法）。但如果不止一种排序方式呢？（比如淘宝商品，既要能按**价格**排序，又要能按**销量**排序）。这时候就需要写多个不同的 `Comparator`​ 来灵活切换。这也就是你文中提到的**策略模式**（Strategy Pattern）。
3. ![image](assets/image-20251126041542-3pquocs.png)

   唯一的一个“小瑕疵” (可以忽略)

   图里把 `1`​ 和 `127` 画在了“常量池”这个框里。

   - **学术上的严谨说法**：`Integer`​ 的缓存（IntegerCache）其实是一个**静态数组**，这个数组对象本身是存放在堆（Heap）里的，而不是严格意义上的“运行时常量池”（Method Area）。
   - **图的意图**：作者把它们画在“常量池”框里，是为了表达“这些是共享的、预先存在的常量数据”这一概念。

   1. 字符串部分 (String)：像这种String s1 \= "china";没有new关键字的都是先在常量池里找，没找到的话就创建放进常量池里，找到的话直接获取常量池里的对象地址。有new的也是先在常量池里找，找到的话不管常量池里的，直接在堆上创建新对象，没找到的话就先在常量池里创建一个模具对象，然后再在堆上创建新对象，然后把模具对象的value复制给堆上的新对象，但是这时的s是指向堆上的对象而不是常量池里的，此时常量池里的没有任何引用它的变量，直到如果下次有不带new关键字的才指向它

      - **​`s1`​**​ **,**  **​`s2`​**  **$\to$** **常量池里的 "china"**

        - **代码**​：`String s1 = "china"; String s2 = "china";`
        - **解析**：**正确**。这是字面量赋值，它们都指向字符串常量池中的同一个对象。
        - **第一步：执行** **​`String s1 = "china";`​** 

          当 JVM 执行这行代码时，它会做两个动作：

          1. **查池（Check Pool）** ​：JVM 会先跑去**字符串常量池**里看一眼：“喂，这里面有没有一个内容是 `"china"` 的 String 对象啊？”

             - *假设这是程序第一次出现 "china"这个词。*
             - **结果**：没找到。
          2. **创建并入池（Create & Intern）** ：

             - JVM 会在堆内存（或者常量池具体实现区域）里**创建**一个新的 String 对象，内容是 `"china"`。
             - 然后把这个对象的​**引用**（地址）登记在常量池里。
          3. **赋值**​：把这个对象的地址给到栈里的变量 `s1`。

          **此时状态**：池子里有了 `"china"`​，`s1` 指向它。
        - **第二步：执行** **​`String s2 = "china";`​** 

          当 JVM 执行这行代码时，同样的逻辑再来一遍：

          1. **查池（Check Pool）** ​：JVM 又跑去**字符串常量池**里看一眼：“喂，这里面有没有一个内容是 `"china"` 的 String 对象啊？”
          2. **命中（Hit）** ：

             - **结果**​：找到了！发现刚才（也就是 `s1`​ 执行时）已经有人创建过 `"china"` 了。
             - **动作**​：JVM **不会**再创建新对象了。它直接把刚才那个已经存在的对象的地址拿过来。
          3. **赋值**​：把这个**老对象的地址**给到栈里的变量 `s2`。
      - **​`ss1`​**​ **,**  **​`ss2`​**  **$\to$** **堆里的两个不同 "china"**

        - **代码**​：`String ss1 = new String("china"); String ss2 = new String("china");`
        - **解析**：**正确**。因为用了 `new`，强制在堆里开辟新空间，所以是两个独立的格子，地址不同。
        - 如果你写 `String s3 = new String("china");`

          - **查池**​：池子里有 `"china"` 吗？有（假设 s1 已经建过了）。
          - **强制创建**​：因为你用了 `new`​，管理员被迫**再买一个一模一样的篮球**放在仓库的另一个角落，只给你一个人用。
          - **结果**​：`s1`​ 和 `s3` 虽然都是篮球，但不是同一个球（地址不同）。
      - 为什么 `new String("china")` 也要先去常量池找？

        这**不是**因为 `new`​ 关键字本身的规定，而是因为你代码里写了 `"china"`​ 这个​**字面量（Literal）** 。

        - **代码解析：**  `String s = new String("china");`
        - **执行过程：**

          1. **参数解析阶段：**  编译器和JVM在执行这行代码时，首先要处理括号里的参数 `"china"`。
          2. **字面量处理：**  在Java中，凡是双引号括起来的字符串字面量，JVM都会确保它在**字符串常量池**中存在。

             - 如果池里没有：创建一个对象（你说的“模具对象”），放入池中。
             - 如果池里有：直接拿来用。
          3. **构造对象阶段：**  处理完参数后，执行 `new`​ 关键字。`new` 的指令是强制在堆（Heap）上开辟一块新内存，创建一个新的 String 对象。
          4. **初始化：**  这个堆上的新对象，会拿刚才（步骤2）在常量池里准备好的那个 String 对象作为数据来源进行初始化。

        **所以，去常量池找，是因为代码里出现了**  **​`"china"`​** ​ **这个字面量，而不是因为** **​`new`​**​ **。** 如果是 `String s = new String(new char[]{'c','h','i','n','a'});`，那么常量池里就不会产生 "china" 对象。
   2. 基本类型部分 (int)：但是int类型的，int a\=1；这个1是直接放进虚拟机栈里的局部变量表，变量表里只有1这个值，它的对应变量名是靠Class 文件里有一张映射表LocalVariableTable（局部变量表属性），记录了 Slot 1 \<\=\=\> Name "a" 的对应关系，物理上存储在硬盘上的  **​`.class`​**​ **文件** 中，属于 `fun`​ 方法的属性表里，当类被加载到 JVM 后，它存放在**方法区**的 InstanceKlass 元数据里。同时局部变量表里也不存储显式的槽位号（因为槽位是数组下标，隐含的），是javac编译器在编译就算好这个a的值就在槽位1上的，不是动态的。但如果是实例变量，就会在类加载阶段计算对象的内存布局，同样也没有实例变量名b，jvm会根据字段符号引用将常量池中的符号引用替换为**内存偏移量**，如对象头是16字节的话，b的偏移量可能就是16，然后jvm就会在这个对象的起始地址加上内存偏移量，把这里改成3

      - **​`i=1`​**​ **,**  **​`j=1`​**​  **(直接在栈格子里)**

        - **代码**​：`int i = 1; int j = 1;`
        - **解析**：**正确**。这正是我们要区分的重点！基本数据类型不指向别处，值就存在栈帧的局部变量表里。图里把值写在方框里，表示**值存储**。
      - LocalVariableTable（局部变量表属性）是多余的，是因为编译之后就没有这种变量名，而是用相对地址代替了

        VM 跑代码的时候，只认 `istore_1`​（存入第1个槽位）。它根本不在乎第1个槽位叫 `b`​ 还是叫 `x`。

        - **如果不开启调试信息（**​**​`javac -g:none`​**​ **）** ​：`.class`​ 文件里甚至**根本没有**这张映射表。程序依然能完美运行，只是你打断点调试的时候，原本叫 `b`​ 的变量会被显示成 `var1`，因为调试器不知道它叫什么。
        - **如果你开启调试信息（默认情况）** ：这张表才会存在

          你在 IDE 里打了个断点。IDE 暂停了程序，去问 JVM：“喂，现在 1 号柜子里是啥？” JVM 说：“是 4。” IDE 此时很懵：“4 是啥？这变量叫啥名啊？我总不能给用户显示 `var1 = 4` 吧？”

          这时候，IDE 就会去查那张​**备忘录（LocalVariableTable）** ：

          > 记录：Slot 1 \<\=\=\> 源代码里的 "b"
          >

          于是 IDE 恍然大悟，在屏幕上给你显示：`b = 4`。
   3. 包装类型部分 (Integer) ：对于integer类型，比如integer it1\=127，那么就先判断等于号后面的数字是不是在这个在 [-128, 127] 之间（if语句），是的话直接指向这个Integer 的缓存（其实是静态数组放在堆里。当 Integer 类被 JVM 加载时（还没开始跑你的业务代码呢），它内部的一个静态内部类 IntegerCache 就已经一次性创建了一个数组（缓存池），里面装满了-128-127的所有integer对象）里对应的对象地址，如果不在的话，比如integer it2\=128，integer it3\=128，这时就要在堆里创建integer对象了，并且每个对象不一样，所以得用equals不能用\=\=，因为\=\=判断的是对象地址

      - **​`i1`​**​ **,**  **​`j1`​**  **$\to$** **常量池里的 1**

        - **代码**​：`Integer i1 = 1; Integer j1 = 1;`
        - **解析**​：​**逻辑正确**。因为 1 在 [-128, 127] 之间，触发自动装箱缓存，指向同一个对象。
      - **​`it1`​**​ **,**  **​`it2`​**  **$\to$** **常量池里的 127**

        - **代码**​：`Integer it1 = 127; Integer it2 = 127;`
        - **解析**​：​**逻辑正确**。127 刚好是缓存的上限，依然共享同一个对象。
      - **​`it11`​**​ **,**  **​`it12`​**  **$\to$** **堆里两个不同的 128**

        - **代码**​：`Integer it11 = 128; Integer it12 = 128;`
        - **解析**​：​**正确**​。128 超出了缓存范围，JVM 必须在堆里 `new` 两个新对象，所以箭头分叉了，指向不同的地址。
      - “是的话直接指向这个Integer 的缓存”这里是指integer数组里对应的某个格子的地址吗，还是integer数组起始地址？其实是**指向的是【被缓存在数组里的那个 Integer 对象本身】的地址**

        让我们画个图来理解：

        1. **缓存池结构：**​`IntegerCache`​ 内部维护了一个数组：`static final Integer cache[];`​假设这个数组在内存地址 `0x1000`。

           - `cache[0]`​ (对应数值 -128) -\> 存放着一个引用，指向地址 `0x5001`（这是一个 Integer 对象）。
           - ...
           - `cache[255]`​ (对应数值 127) -\> 存放着一个引用，指向地址 `0x5256`（这也是一个 Integer 对象）。
        2. **当你执行** **​`Integer it1 = 127;`​** ​ **时：**

           - JVM 调用 `Integer.valueOf(127)`。
           - 代码判断 127 在范围内。
           - 代码返回 `IntegerCache.cache[255]`。
           - **重点来了：**  `cache[255]`​ 里面存的是什么？存的是地址 `0x5256`。
           - 所以，变量 `it1`​ 得到的值就是 `0x5256`。

        **总结：**

        - **it1 指向的是：**  堆中那个代表 127 的 **Integer 对象** 的内存地址（即 `0x5256`）。
        - **数组的作用：**  只是一个容器（引用持有者），用来防止这 256 个对象被垃圾回收（GC），并方便快速查找。`it1` 并不指向数组，而是直接指向了数组里保管的那个“货物”（对象）。
4. 静态代码块：用 `static { ... }` 包裹的代码

   - **什么时候执行？**

     - **只执行一次！**  在**类第一次被加载**的时候执行。
     - 就好比工厂开工前的“剪彩仪式”，不管后面生产多少个产品，剪彩只有一次。
   - **有什么用？**

     - 用来做“全局初始化”。
     - 比如：加载数据库驱动、加载配置文件、定义一些全局通用的复杂的静态变量。
   - **代码长相：**

     ```java
     class Demo {
         static int x;

         // 这就是静态代码块
         static {
             System.out.println("我是静态代码块，我只跑一次！");
             x = 100; // 给静态变量赋初始值
         }
     }
     ```
5. 构造代码块：直接用 `{ ... }`​ 包裹的代码（没有 `static`，也没有方法名）。

   - **什么时候执行？**

     - **每次 new 对象都会执行！**
     - 而且它比构造函数（Constructor）​**先执行**。
     - 就好比每次生产一个新产品，在贴上最终标签（构造函数）之前，先进行的一道“通用预处理工序”。
   - **有什么用？**

     - **提取公因式**。
     - 如果你有 3 个构造函数，它们开头都必须执行一段相同的代码（比如“记录一条日志”或者“初始化某个列表”），你不想在 3 个构造函数里复制粘贴 3 遍，就可以把这段代码抽出来放在构造代码块里。
   - **代码长相：**

     ```java
     class Demo {
         // 这就是构造代码块
         {
             System.out.println("我是构造代码块，每次 new 我都出来！");
         }

         public Demo() {
             System.out.println("我是构造函数 A");
         }

         public Demo(int a) {
             System.out.println("我是构造函数 B");
         }
     }
     ```
   - 为什么会有“构造代码块”这种怪东西？

     其实在实际开发中，**静态代码块**用得很多，但**构造代码块**用得比较少。

     因为大多数时候，我们习惯直接把公共代码写在一个私有的 `init()`​ 方法里，然后在构造函数里调用它，或者使用 `this(...)` 让构造函数互相调用。

     但是，构造代码块有一个独门绝技：**它可以初始化“匿名内部类”！** 因为匿名内部类没有名字，所以写不出构造函数，这时候如果想初始化某些东西，就只能靠构造代码块了。
   - 执行顺序代码演示：

     - ```java
       class Father {
           // 静态部分
           static { System.out.println("1. Father 静态代码块"); }
           
           // 普通部分
           { System.out.println("3. Father 构造/普通代码块"); }
           
           // 构造函数
           public Father() {
               System.out.println("4. Father 构造函数");
           }
       }

       class Son extends Father {
           // 静态部分
           static { System.out.println("2. Son 静态代码块"); }
           
           // 普通部分
           { System.out.println("5. Son 构造/普通代码块"); }
           
           // 构造函数
           public Son() {
               // 这里隐含了一句 super();
               System.out.println("6. Son 构造函数");
           }
       }

       public class Test {
           public static void main(String[] args) {
               System.out.println("--- 准备 new Son() ---");
               new Son();
               System.out.println("--- 再次 new Son() ---");
               new Son();
           }
       }
       ```

       ```plaintext
       --- 准备 new Son() ---            <-- 1. 先打印这句话
       1. Father 静态代码块              <-- 2. 遇到 new Son()，开始加载类，先父类
       2. Son 静态代码块                 <-- 3. 后子类
       3. Father 构造/普通代码块         <-- 4. 类加载完了，开始实例化对象，先父类
       4. Father 构造函数
       5. Son 构造/普通代码块            <-- 5. 后子类
       6. Son 构造函数
       ```
6. 反射和注解：

   1. 如果硬编码写死 `getDeclaredMethod("sayHello", String.class)`​，那这跟直接调用 `obj.sayHello("...")` 确实没啥本质区别（程序员还得知道这个类有什么方法），甚至性能更差、代码更难读。但其实，反射真正的威力并不是用在你“知道”的时候，而是在你“完全不知道”的时候。

      1. 场景一：低级玩法（你说的“脱裤子放屁”）

         这是初学者最容易产生的误解场景：

         ```java
         // 你已经知道 User 类有个 setName 方法
         User user = new User();

         // 普通调用
         user.setName("ZhangSan"); 

         // 反射调用
         Method method = User.class.getDeclaredMethod("setName", String.class);
         method.invoke(user, "ZhangSan");
         ```

         **评价**：在业务代码里这样写，确实是没事找事。这时候反射没有任何优势，纯粹是增加开销和复杂度。
      2. 场景二：中级玩法（框架的核心——配置驱动）

         现在的 Java 框架（Spring, MyBatis）之所以强大，是因为它们​**不需要知道你写了什么类**，但它们依然能管理你的类。

         **例子：Spring 的 XML 配置或注解**

         假设你写了一个 `UserService`，Spring 的开发者根本不认识你，也没见过你的代码。但是你在 XML 里写了：

         ```xml
         <bean id="myService" class="com.example.UserService">
             <property name="timeout" value="1000"/>
         </bean>
         ```

         **Spring 启动时的逻辑（伪代码）：**

         1. **读取字符串**​：Spring 读取 XML，拿到了字符串 `"com.example.UserService"`。
         2. **加载类**​：`Class clazz = Class.forName("com.example.UserService");`​ —— **Spring 根本不知道这个类是啥，是运行时才加载的。**
         3. **发现属性**​：Spring 解析 XML 里的 `name="timeout"`。
         4. **推断方法名**​：根据 JavaBean 规范，属性叫 `timeout`​，那 Setter 方法一定叫 `setTimeout`。
         5. **反射调用**：

            ```java
            // 这里的 "setTimeout" 是拼接出来的字符串，不是程序员硬编码的
            Method method = clazz.getMethod("setTimeout", int.class); 
            method.invoke(instance, 1000);
            ```

         **结论**​：在这个场景下，Spring 的程序员**不需要知道**你有 `setTimeout`​ 方法，它是通过**规则（约定）+ 字符串拼接**算出来的。这就实现了“代码写代码”。
      3. 场景三：高级玩法（真正的动态——遍历与探测）

         这是 IDE（比如 IDEA）和测试框架（JUnit）的玩法。

         假设你写了一个 JUnit 测试类，里面有 10 个测试方法，都加了 `@Test` 注解。JUnit 怎么知道要运行哪些方法？

         JUnit **不需要知道**方法名，它用的是 `getMethods()` 遍历：

         ```java
         Class<?> clazz = YourTestClass.class;

         // 1. 拿到所有声明的方法（我根本不知道方法名叫啥）
         Method[] methods = clazz.getDeclaredMethods();

         // 2. 遍历检查
         for (Method method : methods) {
             // 3. 看看有没有 @Test 注解
             if (method.isAnnotationPresent(Test.class)) {
                 // 4. 有就运行它！
                 method.invoke(instance);
             }
         }
         ```

         **结论**​： 在这个场景里，​**程序员（JUnit 开发者）完全不需要知道方法名**。

         - 你写 `testLogin()`​，它就跑 `testLogin()`。
         - 你写 `testPay()`​，它就跑 `testPay()`。
         - 它是**盲盒式**的操作：打开盒子 -\> 看看有什么 -\> 有什么跑什么。
   2. Spring XML 配置使用的完整示例：

      1. 为了让你看清楚全貌，我们需要创建三个文件：

         1. **​`UserService.java`​**：我们的业务类（Bean）。
         2. **​`beans.xml`​**：Spring 的配置文件（负责描述怎么创建对象）。
         3. **​`SpringApp.java`​**：启动类（负责启动 Spring 容器并使用对象）。
      2. 第一步：准备业务类 (UserService.java)

         注意：这里必须要有 `setTimeout`​ 方法，因为 XML 里的 `<property>` 标签全靠这个 Setter 方法来注入值。

         ```java
         package com.example;

         public class UserService {
             
             // 属性
             private int timeout;

             // 1. 无参构造函数 (Spring 默认用这个来 new 对象)
             public UserService() {
                 System.out.println(">> 步骤1: UserService 被实例化了 (构造函数调用)");
             }

             // 2. Setter 方法 (Spring 看到 <property name="timeout"> 就会调这个)
             public void setTimeout(int timeout) {
                 System.out.println(">> 步骤2: setTimeout 被调用，值是: " + timeout);
                 this.timeout = timeout;
             }

             // 3. 业务方法
             public void doWork() {
                 System.out.println(">> 步骤3: 正在工作中，超时时间设置仅为: " + timeout + "ms");
             }
         }
         ```
      3. 第二步：编写配置文件 (beans.xml)

         通常放在项目的 `src/main/resources` 目录下。

         ```xml
         <?xml version="1.0" encoding="UTF-8"?>
         <beans xmlns="http://www.springframework.org/schema/beans"
                xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                xsi:schemaLocation="http://www.springframework.org/schema/beans
                http://www.springframework.org/schema/beans/spring-beans.xsd">

             <bean id="myService" class="com.example.UserService">
                 <property name="timeout" value="1000"/>
             </bean>

         </beans>
         ```
      4. 第三步：编写启动类 (SpringApp.java)

         这是程序的入口，我们启动 Spring 容器，然后把配好的 Bean 拿出来用。

         ```java
         package com.example;

         import org.springframework.context.ApplicationContext;
         import org.springframework.context.support.ClassPathXmlApplicationContext;

         public class SpringApp {
             public static void main(String[] args) {
                 
                 System.out.println("--- 容器启动开始 ---");
                 
                 // 1. 启动 Spring 容器，加载 beans.xml
                 // 这一步执行时，Spring 就会利用反射去 new 对象并 set 值
                 ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
                 
                 System.out.println("--- 容器启动完成 ---");

                 // 2. 向容器我们要的对象 (通过 id 获取)
                 // 此时拿到的对象，timeout 已经被自动赋值为 1000 了
                 UserService service = (UserService) context.getBean("myService");

                 // 3. 使用对象
                 service.doWork();
             }
         }
         ```

         ---

         ### 运行结果

         当你运行 `SpringApp.java`​ 的 `main` 方法时，控制台会输出：

         ```Plaintext
         --- 容器启动开始 ---
         >> 步骤1: UserService 被实例化了 (构造函数调用)
         >> 步骤2: setTimeout 被调用，值是: 1000
         --- 容器启动完成 ---
         >> 步骤3: 正在工作中，超时时间设置仅为: 1000ms
         ```
   3. 不用XML变成注解后：

      1. 核心逻辑从  **“在 XML 记事本里写清单”**  变成了  **“在类脑门上贴标签”** 。你需要做三件事来完成这个“变身”：

         1. **扔掉** `beans.xml`。
         2. **给类贴标签**​（`@Component`​, `@Value`）。
         3. **告诉 Spring 去哪里扫描**这些标签。
      2. 第一步：修改业务类 (UserService.java)

         我们不再需要在 XML 里告诉 Spring “这有个类叫 UserService”了，而是直接在类上写 `@Service`

         这也是最爽的一点：**甚至连 set 方法都可以省了**（Spring 可以利用反射直接暴力修改私有属性）

         ```java
         package com.example;

         import org.springframework.beans.factory.annotation.Value;
         import org.springframework.stereotype.Service;

         // 1. @Service("myService"): 
         // 等价于 <bean id="myService" class="...">
         // 告诉 Spring：我是个 Bean，快把我管起来！
         @Service("myService") 
         public class UserService {

             // 2. @Value("1000"):
             // 等价于 <property name="timeout" value="1000"/>
             // 告诉 Spring：把这个变量的值设为 1000
             @Value("1000")
             private int timeout;

             public UserService() {
                 System.out.println(">> 步骤1: UserService 被实例化了");
             }

             // 注意：有了注解，set 方法通常就不需要了！
             // Spring 会直接通过反射修改 private 字段。
             
             public void doWork() {
                 System.out.println(">> 步骤3: 正在工作中，超时时间: " + timeout + "ms");
             }
         }
         ```

         注意：**不能在同一个类上写两个**  **​`@Service`​**​ **，也不能写两个**  **​`@Value`​**​ **。** 在 Spring 中，**注解模式（**​ **​`@Service`​**​ **）默认是“单例”（Singleton）的**。也就是说，Spring 看到这个类头上有个标签，它就会造**唯一的一个**实例放在容器里。无论你哪里要用，给你的都是这同一个对象。需要使用 `@Configuration`​ + `@Bean` 方法（Java 配置类模式）
      3. 第二步：创建配置类 (AppConfig.java)

         既然扔掉了 `beans.xml`​，我们需要找个地方告诉 Spring  **“去哪里扫描这些贴了标签的类”** 。我们用一个 Java 类来代替 XML。

         ```java
         package com.example;

         import org.springframework.context.annotation.ComponentScan;
         import org.springframework.context.annotation.Configuration;

         // 1. @Configuration: 告诉 Spring，我是代替 xml 文件的配置类
         @Configuration

         // 2. @ComponentScan: 
         // 告诉 Spring：去 "com.example" 这个包下挨家挨户地找
         // 只要看到贴了 @Service, @Component 的类，就给我创建出来！
         @ComponentScan("com.example")
         public class AppConfig {
             
             // 这里面啥都不用写，只要有上面的注解就够了
         }
         ```
      4. 第三步：修改启动类 (SpringApp.java)

         启动方式稍微变一下，我们要加载的是 Java 配置类，而不是 xml 文件。

         ```java
         package com.example;

         import org.springframework.context.ApplicationContext;
         import org.springframework.context.annotation.AnnotationConfigApplicationContext;

         public class SpringApp {
             public static void main(String[] args) {

                 System.out.println("--- 容器启动开始 ---");

                 // 区别在这里：
                 // 以前用 ClassPathXmlApplicationContext 加载 xml
                 // 现在用 AnnotationConfigApplicationContext 加载 Java 配置类
                 ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

                 System.out.println("--- 容器启动完成 ---");

                 // 下面这部分完全不用变，因为 ID 还是叫 "myService"
                 UserService service = (UserService) context.getBean("myService");
                 service.doWork();
             }
         }
         ```
      5. 注意：**不能在同一个类上写两个**  **​`@Service`​**​ **，也不能写两个**  **​`@Value`​**​ **。** 在 Spring 中，**注解模式（**​ **​`@Service`​**​ **）默认是“单例”（Singleton）的**。也就是说，Spring 看到这个类头上有个标签，它就会造**唯一的一个**实例放在容器里。无论你哪里要用，给你的都是这同一个对象。需要使用 `@Configuration`​ + `@Bean` 方法（Java 配置类模式）

         1. 第一步：给类“松绑”

            把 `UserService`​ 类头上的 `@Service`​ 和字段上的 `@Value`​ **去掉**。让它变成一个普通的 Java 类，并提供一个 setter 或构造函数让我们传值。

            ```java
            package com.example;

            // 注意：这里没有 @Service 了！也没有 @Value 了！
            // 因为如果写死在这里，就没法灵活变身了。
            public class UserService {

                private int timeout;

                // 提供一个 set 方法，方便我们在配置类里赋值
                public void setTimeout(int timeout) {
                    this.timeout = timeout;
                }

                public void doWork() {
                    System.out.println("我是 UserService，我的超时时间是: " + timeout);
                }
            }
            ```
         2. 第二步：在配置类里“手动生产”多个 Bean

            这时候，`@Configuration`​ 就派上大用场了。我们可以在里面写多个方法，每个方法都返回一个 `UserService`，但是配置不一样。

            ```java
            package com.example;

            import org.springframework.context.annotation.Bean;
            import org.springframework.context.annotation.Configuration;

            @Configuration
            public class AppConfig {

                // 造第一个 Bean：名字叫 "service1"，超时 1000
                @Bean("service1") 
                public UserService createService1() {
                    UserService service = new UserService();
                    service.setTimeout(1000); // 手动赋值
                    return service;
                }

                // 造第二个 Bean：名字叫 "service2"，超时 2000
                @Bean("service2")
                public UserService createService2() {
                    UserService service = new UserService();
                    service.setTimeout(2000); // 手动赋值不同
                    return service;
                }
            }
            ```
         3. 第三步：启动容器后，你就可以根据名字拿不同的对象了。

            ```java
            // 拿到 service1
            UserService s1 = (UserService) context.getBean("service1");
            s1.doWork(); // 输出 1000

            // 拿到 service2
            UserService s2 = (UserService) context.getBean("service2");
            s2.doWork(); // 输出 2000
            ```
   4. 注解（Annotation）\= 标签，这个标签本身没有任何功能，如果不用它就是废话，但是这是给编译器或JVM看的

      > 文中说：“元数据，即描述数据的数据...和业务逻辑无关。”
      >

      **通俗解释：** 代码就像一件“衣服”。 注解就像是衣服上的“吊牌”或“便利贴”。

      - **标签本身没有任何功能**​：你在衣服上贴个“纯棉”的标签，这衣服也不会自己变暖和。同样，你在代码上写个 `@Override`​ 或 `@Test`，如果你不理它，它就只是一行废话。
      - **标签是为了给别人（编译器/JVM）看的**：

        - 编译器看到 `@Override`，会帮你检查父类有没有这个方法。
        - JUnit 看到 `@Test`，就知道这个方法要运行一下。

      这就是文中说的“**和业务逻辑无关，通过反射获得数据**”。
   5. 元注解 \= 标签的说明书

      > 文中列举了 `@Retention`​、`@Target` 等。
      >

      既然注解是“标签”，那“元注解”就是用来**规定这个标签该怎么用**的规则。

      1. `@Retention` (最重要！决定标签活多久)

         这决定了这个标签能保留到什么时候。

         - **SOURCE (源码阶段)** ：

           - **比喻**：像“草稿纸上的批注”。
           - **例子**​：`@Override`​。写代码时给编译器看的，编译成 `.class` 文件后就扔掉了。你反编译代码是看不到的。
         - **CLASS (字节码阶段 - 默认)** ：

           - **比喻**：像“衣服出厂时的内部条码”。
           - **作用**​：编译器把标签印在 `.class` 文件里，但 JVM 运行的时候不加载它。一般普通开发很少用，字节码工具（如 Lombok）用得多。
         - **RUNTIME (运行阶段 - 重点！)** ：

           - **比喻**：像“衣服的洗涤说明吊牌”。
           - **作用**​：**这是我们自定义注解和 Spring 注解最常用的！**  只有设为 RUNTIME，程序跑起来的时候（JVM），我们才能通过反射读到它。
           - **文中原话**：“必须为 runtime，否则反射时不能用。” —— 对！因为反射是运行时干的事，如果标签在编译时就被丢了，反射当然找不到了。
      2. ​`@Target` (决定标签贴哪儿)

         这规定了这个标签只能贴在什么地方。

         - **TYPE**：贴在类/接口脑门上。
         - **FIELD**：贴在属性（变量）上。
         - **METHOD**：贴在方法上。
         - **PARAMETER**：贴在参数上。

         如果不写 `@Target`，这标签就可以满世界乱贴。
   6. 自定义注解实例 \= 自己设计一个标签

      文中提到了定义注解类似定义接口。我给你写个最简单的例子，配合**反射**让它动起来。

      1. 造标签 (MyTag.java)

         ```java
         import java.lang.annotation.*;

         @Retention(RetentionPolicy.RUNTIME) // 关键：运行时还要留着！
         @Target(ElementType.METHOD)         // 关键：只能贴在方法上！
         public @interface MyTag {
             String value() default "默认值"; // 标签里可以写字
         }
         ```
      2. 贴标签 (User.java)

         ```java
         public class User {
             
             @MyTag("我是VIP") // 把标签贴上，并写上字
             public void study() {
                 System.out.println("正在学习...");
             }
         }
         ```
      3. **读标签 (Main.java - 反射登场)这才是注解生效的关键！** 

         ```java
         public class Main {
             public static void main(String[] args) throws Exception {
                 // 1. 拿到 User 类
                 Class<User> clazz = User.class;
                 
                 // 2. 拿到 study 方法
                 Method method = clazz.getMethod("study");
                 
                 // 3. 检查有没有 @MyTag 标签
                 if (method.isAnnotationPresent(MyTag.class)) {
                     // 4. 有的话，把标签撕下来看一眼
                     MyTag tag = method.getAnnotation(MyTag.class);
                     System.out.println("发现标签内容：" + tag.value());
                 }
             }
         }
         ```

         - **如果**  **​`@Retention`​**​ **不是 RUNTIME**​，上面的第 3 步就会返回 `false`，因为运行的时候标签已经没了。
   7. Spring 中的 @Resource（按名字） vs @Autowired（按类型）

      虽然它们功能差不多，但**找人的逻辑**不一样。

      假设你有两个保姆（Bean）：

      1. 保姆A (名字: `nurse1`​, 类型: `Nurse`)
      2. 保姆B (名字: `nurse2`​, 类型: `Nurse`)

      你现在想要一个保姆：`private Nurse myNurse;`

      1. `@Autowired` (Spring 亲生的)

         - **默认逻辑**​：**按类型（byType）**  找。
         - 它会喊：“谁是 `Nurse` 类型的？出来！”
         - **问题**​：这时候 `nurse1`​ 和 `nurse2` 都会举手（因为都是 Nurse 类型），Spring 就懵了，会报错（NoUniqueBeanDefinitionException）。
         - **解决**​：必须配合 `@Qualifier("nurse1")` 才能指定名字。
      2. ​`@Resource` (Java 标准亲生的，Spring 借用)

         - **默认逻辑**​：**先按名字（byName）**  找。
         - 写法：`@Resource(name="nurse1")`
         - 它会喊：“谁的名字叫 `nurse1`？出来！”
         - 这时候只有 `nurse1` 会出来，非常精准。
         - **回退机制**​：如果你不写名字，只写 `@Resource`​，它会先把变量名 `myNurse`​ 当作名字去找。如果找不到名字叫 `myNurse` 的，它才会退一步，像 Autowired 一样按类型找。
7. 动态代理本质就是创建个代理类的实例，这个代理类实现了被代理的接口，然后用反射拿到要被代理的类的方法，不管让代理对象做什么，他都是交给InvocationHandler，在InvocationHandler的invoke方法里，在被代理的方法前后都可以增强

   1. `InvocationHandler`​ 是 JDK 提供的一个**接口**，它里面只有一个方法：`invoke`。
   2. 代码演示：

      1. 第一步：定义接口和真实实现类（被代理人）

         ```java
         // 1. 接口：短信服务
         interface SmsService {
             void send(String message);
         }

         // 2. 真实实现类（比如真正的腾讯云短信发送器）
         class SmsServiceImpl implements SmsService {
             @Override
             public void send(String message) {
                 System.out.println("【真实干活】正在发送短信内容：" + message);
             }
         }
         ```
      2. 第二步：定义 InvocationHandler（幕后大管家）

         ```java
         import java.lang.reflect.InvocationHandler;
         import java.lang.reflect.Method;

         // 3. 自定义逻辑处理器
         class MyLogHandler implements InvocationHandler {
             // 必须要持有真实对象的引用，否则没法让真实对象干活
             private Object target;

             public MyLogHandler(Object target) {
                 this.target = target;
             }

             /**
              * @param proxy  生成的代理对象本身（一般很少用到）
              * @param method 正在被调用的方法（比如 send 方法）
              * @param args   方法的参数（比如 "Hello"）
              */
             @Override
             public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                 // --- A. 前置增强 ---
                 System.out.println(">>> 开启日志记录...");

                 // --- B. 反射调用真实对象的方法 ---
                 // 这行代码等同于：target.send("Hello")
                 Object result = method.invoke(target, args);

                 // --- C. 后置增强 ---
                 System.out.println(">>> 日志记录结束，发送成功！");

                 return result; // 返回方法的执行结果
             }
         }
         ```
      3. 第三步：测试（生成代理并调用）

         ```java
         import java.lang.reflect.Proxy;

         public class Main {
             public static void main(String[] args) {
                 // 1. 创建被代理的真实对象
                 SmsService realService = new SmsServiceImpl();

                 // 2. 创建大管家（Handler），把真实对象给他管理
                 MyLogHandler myHandler = new MyLogHandler(realService);

                 // 3. 【核心】动态生成代理对象
                 // 参数1：类加载器
                 // 参数2：代理要实现的接口数组（SmsService），proxyService实现了SmsService接口
                 // 参数3：办事的大管家（Handler）
                 SmsService proxyService = (SmsService) Proxy.newProxyInstance(
                         realService.getClass().getClassLoader(),
                         realService.getClass().getInterfaces(),
                         myHandler
                 );

                 // 4. 调用代理对象的方法
                 // 注意：这里看着是调用的 proxyService，实际上全被转发给了 myHandler.invoke()
                 proxyService.send("你好，动态代理！");
             }
         }
         ```
      4. 在代码里写的是 `proxyService.send(...)`​，怎么眼睛一闭一睁，就跑到 `MyLogHandler.invoke(...)`​ 里去了？因为 **JDK 在内存里悄悄生成的那个**  **​`$Proxy0`​**​ **类（幽灵类），它的源码里就是这么写的！**

         ```java
         // 这个类是 JDK 自动生成的，你看不到源码，但它真实存在于内存中
         public final class $Proxy0 extends Proxy implements SmsService {

             // 1. 构造函数
             // 你在 newProxyInstance 时传进去的 handler，被传给了父类 Proxy 保存
             public $Proxy0(InvocationHandler h) {
                 super(h); 
             }

             // 2. 实现了接口的 send 方法
             // 当你在外部调用 proxyService.send("你好") 时，实际运行的是这段代码：
             @Override
             public void send(String message) {
                 try {
                     // A. 准备参数：拿到 "send" 这个方法的反射对象 (Method)
                     // (这里简化了写法，实际上是在 static 块里加载好的)
                     Method m = SmsService.class.getMethod("send", String.class);

                     // B. 【这就是你要找的跳转！】
                     // super.h 就是父类 Proxy 里存的那个 InvocationHandler（你的 MyLogHandler）
                     // 它直接调用了 handler 的 invoke 方法！
                     super.h.invoke(this, m, new Object[]{message});

                 } catch (Throwable e) {
                     throw new RuntimeException(e);
                 }
             }
         }
         ```
      5. proxy这个代理类只有一个字段就是invocationhandler

         ```java
         public class Proxy implements java.io.Serializable {
             // 这里的 h，就是那个“大管家”
             protected InvocationHandler h;

             protected Proxy(InvocationHandler h) {
                 this.h = h;
             }
         }
         ```
      6. 因为多态，所以触发的是`$Proxy0`​ 类的 `send` 方法

         1. `SmsService proxyService = (SmsService) Proxy.newProxyInstance(...);`

            **内存里发生了什么？**

            - **左边**​：`SmsService proxyService`​ —— 这是一个​**引用（标签）** 。它贴着“我是短信服务”的牌子。
            - **右边**​：`Proxy.newProxyInstance(...)`​ —— 这在**堆内存（Heap）**  里真真正正产生了一个对象。

              - 这个对象的**真实类型**是：`$Proxy0`。
              - 这个对象**长得**像这样：`new $Proxy0(handler)`。
         2. Java 的运行规则：编译看左边，运行看右边。

            - **编译器**检查：它看左边的接口 `SmsService`​ 里有没有 `send` 方法？有，编译通过。
            - **JVM（虚拟机）运行**时：它不管你左边贴什么标签，它只看​**堆内存里那个对象到底是谁**。

              - 内存里的对象是 `$Proxy0` 类型的实例。

                - 为什么这个对象的真实类型是：\$Proxy0

                  - 根本原因：接口（Interface）不能直接 `new`

                    你传入的是 `SmsService` 接口。

                    - 在 Java 里，接口只是一个“标准”或“合同”，它是抽象的，不能直接 `new SmsService()`。
                    - 要想创建一个对象，必须得有一个​**实实在在的类（Class）** 。
                    - 既然你没有手动写一个 `MyStaticProxy`​ 类，那 JDK 就必须在内存里**现写**一个类。

                    **既然是现写的类，总得有个类名吧？** JDK 的开发者偷懒了（或者为了规范），他们定了一个规则：所有动态生成的代理类，名字都叫 `$Proxy` 加上一个数字序号。
                  - 名字的由来：\$Proxy + N

                    这是 JDK 源码里写死的命名规则：

                    -  **​`$`​** ​：在 Java 内部类或自动生成的类中，通常用 `$`​ 开头或包含 `$`。
                    - **​`Proxy`​**：表明这是一个代理类。
                    - **​`0`​**​：这是一个​**序列号**。

                      - 你生成的第一个代理类叫 `$Proxy0`。
                      - 如果你在同一个程序里，又为另一个接口（比如 `UserService`​）生成了代理，它就会叫 `$Proxy1`。
                      - 再做一个，就叫 `$Proxy2`……以此类推。
              - 所以，它**必须、只能、一定会**去执行 `$Proxy0`​ 类里定义的 `send` 代码。
8. JDK的动态代理机制只能代理实现了接口的类，而不能实现接口的类就不能实现JDK的动态代理，cglib是针对类来实现代理的，他的原理是对指定的目标类生成一个子类，并覆盖其中方法实现增强，但因为采用的是继承，所以不能对final修饰的类进行代理。

   1. 为什么 JDK 动态代理“只能代理实现了接口的类”？

      这是由 Java 的**单继承机制**决定的。

      - **生成的代理类结构：**  当你调用 JDK 动态代理 (`Proxy.newProxyInstance`​) 时，JVM 在运行时动态生成了一个新的 `.class`​ 字节码。这个动态生成的类，在定义上强制继承了 `java.lang.reflect.Proxy` 类。
      - **矛盾点：**  Java 语法规定，一个类只能继承一个父类（单继承）。
      - **结论：**  因为生成的代理类已经继承了 `Proxy`​ 类，它就**无法再继承**你的目标业务类。为了能和目标类“类型兼容”（即能被当做目标类使用），它只能选择​**实现目标类的接口**。
      - **所以：**  如果目标类没有接口，JDK 代理生成的类就无法与目标类建立多态关系，无法完成代理。
   2. CGLIB 是如何“针对类来实现代理”的？

      CGLIB 不使用 JDK 的 `Proxy`​ 类，它底层使用 ​**ASM**（一个字节码操作框架）直接修改字节码。

      - **原理（继承）：**  CGLIB 在运行时，动态生成了一个目标类的​**子类**。

        - 假设你的类叫 `UserService`。
        - CGLIB 会生成一个叫 `UserService$$EnhancerByCGLIB` 的类。
        - 在这个类的定义中：`public class UserService$$EnhancerByCGLIB extends UserService { ... }`。
      - **增强（重写）：**  它是通过**方法重写 (Method Overriding)**  来实现拦截的。它会重写父类（目标类）的所有非 `final` 方法。

      **代码逻辑示意（生成的子类大致长这样）：**

      ```java
      // 目标类
      public class UserService {
          public void login() {
              System.out.println("用户登录");
          }
      }

      // CGLIB 动态生成的代理类（子类）
      public class UserService$$EnhancerByCGLIB extends UserService {
          // 拦截器引用
          private MethodInterceptor callback;

          @Override
          public void login() {
              // 1. 增强逻辑（前置）
              callback.intercept(this, method, args, methodProxy);
              
              // 2. 调用父类（目标类）的方法
              // super.login(); 
          }
      }
      ```
   3. 为什么“不能对 final 修饰的类进行代理”？

      这完全受限于 ​**Java 语言规范**：

      1. **Final 类：**  如果目标类被修饰为 `final`​（例如 `public final class UserService`​），Java 规定该类​**不能有子类**。

         - 既然 CGLIB 的原理是“生成子类”，面对 `final` 类它就无法生成，直接报错或抛出异常。
      2. **Final 方法：**  即使类不是 `final`​，如果某个方法是 `final`​ 的（例如 `public final void login()`​），Java 规定该方法​**不能被重写**。

         - CGLIB 无法重写该方法，也就无法在该方法中插入增强逻辑（拦截代码）。该方法会直接执行原逻辑，代理失效。
9. 接口里只能有常量，不能有普通的成员变量

   1. 在接口里，你虽然可以定义字段，但它们**被强制锁定**了。哪怕你写得很随意，Java 编译器（Javac）会在后台自动给你加上三个修饰符：`public static final`。

      ```java
      public interface MyInterface {
          // 你写的代码：
          int MAX_COUNT = 100;
          
          // 编译器实际上看到的代码（完全等价）：
          public static final int MAX_COUNT = 100;
      }
      ```

      这意味着：

      1. **Public:**  谁都能访问。
      2. **Static:**  它属于接口本身，不属于某个对象（不需要 new 就能用）。
      3. **Final:**  它是​**常量**，一旦赋值，永远不能修改。
   2. 为什么不能有普通变量？

      这是一个非常好的设计哲学问题。

      - **接口的本质是“契约” (Contract)：**  就像一份合同。合同里可以写死一些标准（比如：`圆周率 = 3.14`），这是所有人都承认的死规定（常量）。
      - **类的本质是“状态” (State)：**  比如 `Student` 类，每个学生都有自己的名字、年龄。这些是可以变的，属于具体的对象。

      接口既然不负责创建对象（它连构造函数都没有），它就不应该保存对象的状态。**如果接口能存变量，那它就变得不纯粹了，越来越像一个类。**
10. Java 8 (JDK 1.8) 四个非常核心的变化：一个是**语言层面的语法增强**（接口），一个是**JVM 底层内存模型的重构**（永久代变元空间），一个是lambda表达式，还有一个**Stream API（流）**

    1. 接口的默认方法与静态方法 (Interface Default & Static Methods)

       **核心痛点：** 在 Java 8 之前，接口（Interface）非常“死板”。一旦你发布了一个接口，如果有 100 个类实现了它，你以后就不敢再往接口里加新方法了。因为一旦加了新方法，那 100 个实现类全部都会报错（必须实现该方法），这叫​**破坏了向后兼容性**。

       **Java 8 的解决方案：** 为了支持 Lambda 表达式和 Stream API（比如 `List.stream()`​），Java 官方必须在 `Collection`​ 接口里加新方法。为了不让全世界的 Java 代码报错，他们引入了 **​`default`​**​ **方法**。

       1. Default 方法 (扩展方法)

          - **含义**​：接口里可以写代码实现了！加上 `default` 关键字即可。
          - **好处**：

            1. **平滑升级**：实现类可以“继承”这个默认实现，不需要强制重写。
            2. **代码复用**：通用的逻辑可以直接写在接口里。
          - **冲突规则**（你提到的“子类必须重写”）：

            - 如果一个类实现了两个接口（A 和 B），且 A 和 B 都有一个同名的 `default` 方法，编译器晕了，不知道用哪个。
            - **解决**​：强制要求子类重写该方法，明确指定调用哪个（例如 `A.super.method()`）或者写全新的逻辑。
       2. Static 方法

          - **含义**：接口里可以直接定义静态方法。
          - **作用**​：以前我们需要写一个 `MyInterface`​ 和一个 `MyInterfaceUtils`​ 工具类。现在工具方法可以直接写在接口里了（比如 `Stream.of(...)`），减少了类的数量，代码更聚合。
    2. 移除了永久代，改用元空间 (PermGen Replaced by Metaspace)

       1. 背景：什么是“永久代” (PermGen)？

          在 JDK 7 及之前，HotSpot JVM 的堆内存（Heap）里有一块特殊的区域叫 ​**PermGen**。

          - **存什么？**  类的元数据（Class Metadata）：类名、方法名、字段描述、字节码等。注意：**不是** `new`​ 出来的对象（在堆的 Old/Eden 区），而是​**描述“这个类长什么样”的信息**。
          - **有什么问题？**

            - **大小固定**​：启动时必须指定大小（例如 `-XX:MaxPermSize=256m`）。
            - **容易 OOM**​：现在的框架（Spring, Hibernate, CGLib）会在运行时动态生成大量的类。如果项目很大，PermGen 很容易被塞满，抛出 `java.lang.OutOfMemoryError: PermGen space`。一旦满了，JVM 通常就挂了。
       2. 新特性：元空间 (Metaspace)

          JDK 8 把 PermGen 砍掉了，换成了 ​**Metaspace**。

          - **本质区别**：

            - **PermGen**：在 JVM 的堆内存里（受 JVM 堆大小限制）。
            - **Metaspace**​：在 **本地内存 (Native Memory)**  里（受操作系统物理内存限制）。
          - **为什么这么改？ (对应你文本中的解释)**

            1. **很难 OOM**：因为它是用操作系统的内存。只要你的服务器内存够大（比如 32GB），理论上可以加载无数个类，不会像以前那样因为分配了 256MB 稍微超一点就报错。
            2. **动态调整**​：JVM 会根据需要向操作系统申请内存，多了就还给操作系统（虽然回收比较保守）。不需要你天天盯着 `PermSize` 调参了。
            3. **技术融合**：Oracle 收购了 JRockit JVM，JRockit 本来就没有 PermGen。为了融合 HotSpot 和 JRockit 的代码，去掉 PermGen 是必然的。
       3. **需要注意的“坑” (元空间的垃圾回收)**

          文本中提到：“​*如果不指定 MaxMetaspaceSize，元空间会在运行时动态调整*”。 这听起来很美好，但在生产环境（特别是容器化环境，如 Docker）中是一个隐患：

          - **风险**​：如果你的程序有“类加载泄露”（不停地动态生成类但不卸载），Metaspace 会一直吃内存，直到把​**整个服务器/容器的内存吃光**，导致服务器卡死或被 OS 杀掉（OOM Killer）。
          - **最佳实践**​：虽然 Java 8 允许不设置，但**实际上我们通常还是会设置** `-XX:MaxMetaspaceSize`（比如 256M 或 512M），给它设个上限，防止它无限制膨胀把机器搞挂。
    3. **传统迭代器**：是单线程的。如果你有 100 万个数据要处理，只能一个线程从头跑到尾。**Parallel Stream**：当你调用 `list.parallelStream()`​ 时，JVM 会利用你学过的 **Fork/Join 框架**。它会自动把这 100 万个数据切分成很多小块（Fork），把这些小块丢到通用的线程池（ForkJoinPool）里去并行处理，最后再把结果汇总（Join）。
    4. **Stream API（流）** 是声明式的**数据流水线**，利用**惰性求值**避免无效计算，把stream放在**分治+工作窃取**的Fork/Join线程池上运行实现并行流。

       1. Stream 的本质（流水线与惰性求值）

          1. 核心流程：源 -\> 中间操作 -\> 终止操作

             一个 Stream 的生命周期永远包含这三步：

             1. **Source（创建）** ：从集合、数组中获取流。
             2. **Intermediate Operations（中间操作 - 懒惰的）** ：

                - 比如 `filter`​（过滤）、`map`​（转换）、`sorted`（排序）。
                - **关键点**​：这些操作是​**Lazy（惰性）的。当你调用**  **​`.filter()`​** ​ **时，代码根本没有执行**，它只是把这个操作记录在了一个“操作清单”里。
             3. **Terminal Operation（终止操作 - 触发器）** ：

                - 比如 `forEach`​、`collect`​、`count`。
                - **关键点**：只有当你调用这一步时，水闸才打开，数据才会真正开始流动，按照之前的清单一步步处理。
          2. 为什么要有“惰性求值”？（性能优化）

             想象一下，你有一个 100 万个元素的列表，你想找到**第一个**长度大于 5 的字符串。

             - **没有惰性求值（传统方式）** ：可能先把 100 万个元素都过滤一遍，生成一个新的列表，然后再取第一个。浪费！
             - **有惰性求值（Stream）** ​： Stream 像一个聪明的流水线。它处理第一个元素 -\> 不符合 -\> 丢弃；处理第二个 -\> 符合 -\> ​**立马停止（Short-circuiting）** 。 它不需要处理剩下的 999,998 个元素。这就是 Stream 高效的原因。
       2. Fork/Join 框架（并行流的引擎）

          1. 核心思想：分而治之

             这就好比要把 1000 块砖头搬上楼：

             - **普通线程池**：派一个工人（线程）去搬，或者派 5 个工人每人领 200 块。
             - **Fork/Join**：

               1. **Fork（拆分）** ：工头看任务太大（1000块），切成两个 500。还是太大？再切成 250...直到任务小到一个人能轻松搞定（比如 50 块）。
               2. **Compute（计算/执行）** ：各个线程并行处理这 50 块砖。
               3. **Join（合并）** ：大家干完了，把结果汇总。
          2. 杀手锏：工作窃取算法 (Work-Stealing) —— **这是并发的精髓**

             你肯定知道 `ThreadPoolExecutor` 里的线程如果没事做，就会阻塞在队列上等待。但 Fork/Join 的线程非常“卷”。

             - **双端队列 (Deque)** ​：ForkJoinPool 中的​**每个线程都有自己的任务队列**（双端队列）。
             - **正常工作**：线程从自己队列的头部（Head）拿任务干活。
             - **窃取（Stealing）** ：

               - 假设 **线程 A** 动作很快，把自己队列里的活干完了。
               - 它不会闲着睡觉，而是悄悄跑到 **线程 B** 的队列的​**尾部（Tail）** ，“偷”一个任务过来帮 B 干。
             - **好处**：

               1. **充分利用 CPU**：没有线程在摸鱼。
               2. **减少竞争**：A 偷的是尾部，B 拿的是头部，它俩互不干扰，不需要频繁加锁（Lock-Free 的思想）。
       3. Stream + Fork/Join \= ParallelStream

          当你写下 `list.parallelStream()` 时，Java 实际上做了以下事情：

          1. **默认线程池**​：它默认使用一个全局的 `ForkJoinPool.commonPool()`。这个池子的线程数默认等于你 CPU 的核心数（减 1）。
          2. **自动拆分**​：它利用集合的 `Spliterator`（可拆分迭代器），把你的大 List 拆分成很多小块（Fork）。
          3. **并行执行**：把这些小块扔进 ForkJoinPool 里，利用上面说的“工作窃取”机制疯狂处理。
          4. **结果合并**：最后把处理好的数据拼回去。

          #### 一个必须注意的“坑”

          因为 `parallelStream`​ 默认用的是**全局共享**的 `commonPool`：

          - **场景 A（适合）** ​：你的任务是​**CPU 密集型**（纯计算，比如算哈希值、图像处理）。Fork/Join 会让 CPU 跑满，效率极高。
          - **场景 B（绝对禁止）** ​：你的任务是​**IO 密集型**（比如发 HTTP 请求、查数据库）。

            - **后果**​：如果你的代码里有一个任务卡住了（等 HTTP 响应），它会阻塞这个公共池子里的线程。如果并发高一点，​**整个 JVM 里的所有并行流都会卡死**，因为大家共用这几个线程。
       4. 基础操作：`filter`​（过滤）、`map`​（转换）、`collect`（收集结果）

          这个 Demo 展示 Stream 最常用的“三板斧”：`filter`​（过滤）、`map`​（转换）、`collect`（收集结果）。 你会发现它非常像写 SQL 语句，读起来很顺畅。

          ```java
          import java.util.Arrays;
          import java.util.List;
          import java.util.stream.Collectors;

          public class StreamBasicDemo {
              public static void main(String[] args) {
                  // 1. 模拟数据：一组用户（名字）
                  List<String> names = Arrays.asList("Alice", "Bob", "Charlie", "David", "Edward", "Frank");

                  // 2. 需求：找出名字长度大于3的，转成大写，然后排序，最后收集成一个新的List
                  List<String> result = names.stream()
                          // A. 过滤：只要长度 > 3 的
                          .filter(name -> name.length() > 3)
                          // B. 转换：把名字变大写
                          .map(String::toUpperCase) // 等价于 .map(s -> s.toUpperCase())
                          // C. 排序：倒序排列
                          .sorted((a, b) -> b.compareTo(a))
                          // D. 终止：收集结果
                          .collect(Collectors.toList());

                  // 3. 打印结果
                  System.out.println("原始列表: " + names);
                  System.out.println("处理结果: " + result);
              }
          }
          ```

          **运行结果预估：**

          ```plaintext
          原始列表: [Alice, Bob, Charlie, David, Edward, Frank]
          处理结果: [FRANK, EDWARD, DAVID, CHARLIE, ALICE]
          ```

           *(注意：Bob 被过滤掉了，因为长度不大于3)*
       5. 另一个例子：

          这句话其实就是用一种比较“时髦”的写法（Java 8 的 Stream 流），把普通的 **for 循环**给简化了。

          所谓的“流打印”，在这行代码里就是： **“把数组变成流水线，一个个拿出来，贴上标签，然后打印出来。”**

          我把这行代码拆解成你熟悉的“土话”和对应的“老式写法”来对比，你就秒懂了。

          1. 代码拆解

             代码是这一长串：

             ```java
             Arrays.asList(byteBuffers).stream()
                 .map(buffer -> "position=" + buffer.position() + ", limit=" + buffer.limit())
                 .forEach(System.out::println);
             ```

             我们可以把它想象成一个​**工厂流水线**：

             1. **​`Arrays.asList(byteBuffers)`​** 

                - **动作**：把你的那一排杯子（Buffer 数组）打包成一个列表。
                - **意思**：准备原材料。
             2. **​`.stream()`​** 

                - **动作**​：启动​**传送带**。
                - **意思**：把列表里的每一个 Buffer 对象，一个接一个地放到传送带上往下传。
             3. **​`.map(...)`​** ​ —— **这是核心！**

                - **动作**​：​**加工/转换**。
                - **意思**​：传送带流过来一个 `ByteBuffer`​ 对象，我不需要对象本身，我要把它​**变成**（Map 映射）一段文字描述。
                - *变化前*​：一个看不见的内存对象 `java.nio.HeapByteBuffer[pos=0 lim=5...]`
                - *变化后*​：一个字符串 `"position=0, limit=5"`
             4. **​`.forEach(System.out::println)`​** 

                - **动作**​：​**终点处理**。
                - **意思**：对传送带上流过来的每一个字符串，执行打印操作。
          2. 如果用“老式写法”是怎样的？

             这行“流打印”代码，完全等同于下面这段我们最熟悉的 `for` 循环：

             ```java
             // 老式写法：增强 for 循环
             for (ByteBuffer buffer : byteBuffers) {
                 // 1. 对应 map：把对象变成字符串
                 String info = "position=" + buffer.position() + ", limit=" + buffer.limit();
                 
                 // 2. 对应 forEach：打印出来
                 System.out.println(info);
             }
             ```
          3. 为什么要这么写？

             在 `Scattering Reads`​（分散读取）的场景下，你有**很多个** Buffer（比如 `byteBuffers` 数组里有 2 个、3 个甚至更多）。

             - **目的**​：你想一眼看到**每一个** Buffer 现在被填满到哪里了。
             - **流打印的好处**​：它能在一行代码里，把数组里**所有** Buffer 的状态（Position 和 Limit）都打印出来，不用写好几行 `for` 循环，代码看起来更简洁（显得更高级）。
          4. 总结

             这就好比点名：

             - **For 循环**：老师走到每个学生面前问：“你叫什么？”，学生回答，老师记下来。
             - **Stream 流**：学生们排成一队走过安检门，安检门自动扫描（map）出名字，并显示在屏幕上（println）。

             结果是一模一样的，只是处理方式不同。
       6. 惰性求值：如果没有终止操作比如 `forEach`​、`collect`​、`count`，中间的步骤根本不会执行。

          ```java
          import java.util.Arrays;
          import java.util.List;
          import java.util.stream.Stream;

          public class StreamLazyDemo {
              public static void main(String[] args) {
                  List<String> names = Arrays.asList("A", "B", "C");

                  System.out.println("--- 1. 定义流（开始） ---");
                  
                  Stream<String> stream = names.stream()
                      .map(s -> {
                          // 这里的打印是为了验证代码有没有执行
                          System.out.println("正在处理: " + s);
                          return s.toLowerCase();
                      });

                  System.out.println("--- 2. 定义流（结束） ---");
                  System.out.println("注意看：上面这两行中间，没有打印'正在处理'！因为还没有触发终止操作。");
                  System.out.println("--- 3. 执行终止操作 (forEach) ---");
                  
                  // 只有执行这一句，上面的 map 逻辑才会被触发
                  stream.forEach(System.out::println);
              }
          }
          ```

          **运行观察：** 你会发现，步骤 1 和 2 之间控制台​**一片死寂**​。直到步骤 3 执行，`正在处理: A` 这种日志才会吐出来。这就是“懒加载”。
       7. 并行流与Fork/Join 线程池

          鉴于你对并发感兴趣，这个 Demo 展示 `parallelStream()`​ 到底用了哪些线程。我们会打印出**当前线程的名字**。

          ```java
          import java.util.stream.IntStream;

          public class ParallelStreamDemo {
              public static void main(String[] args) {
                  System.out.println("当前主线程: " + Thread.currentThread().getName());
                  System.out.println("CPU 核心数: " + Runtime.getRuntime().availableProcessors());
                  System.out.println("--------------------------------");

                  // 生成 1 到 10 的数字，闭区间
                  IntStream.rangeClosed(1, 10).parallel() // 开启并行模式！
                          .map(i -> {
                              // 模拟一个耗时操作，让线程不得不切换
                              try { Thread.sleep(100); } catch (InterruptedException e) {}
                              
                              // 打印是哪个线程在干活
                              String threadName = Thread.currentThread().getName();
                              System.out.println("数字: " + i + " -> 处理线程: " + threadName);
                              return i * 10;
                          })
                          .forEach(result -> { /* 只是为了触发流 */ });
              }
          }
          ```

          **运行结果（示例）：** 你会看到类似下面的输出，证明了 Fork/Join 线程池在工作：

          ```plaintext
          当前主线程: main
          CPU 核心数: 8
          --------------------------------
          数字: 6 -> 处理线程: main
          数字: 3 -> 处理线程: ForkJoinPool.commonPool-worker-1
          数字: 8 -> 处理线程: ForkJoinPool.commonPool-worker-2
          数字: 2 -> 处理线程: ForkJoinPool.commonPool-worker-3
          ...
          ```

          **解析：**

          1. 你会看到 `ForkJoinPool.commonPool-worker-X` 这样的线程名，这就是 Java 8 自动调用的线程池。
          2. 你会惊讶地发现 `main`​ 线程自己也参与了干活！这是 Fork/Join 的一个策略：​**调用者线程（Caller Thread）也会帮忙计算**，防止主线程闲着没事做。
       8. 并行流最容易翻车的情况：**多线程写共享变量**。

          ```java
          import java.util.ArrayList;
          import java.util.Collections;
          import java.util.List;
          import java.util.stream.IntStream;

          public class StreamTrapDemo {
              public static void main(String[] args) {
                  // 创建一个非线程安全的 List
                  List<Integer> unsafeList = new ArrayList<>();

                  // 并行流：向 unsafeList 里添加 1000 个元素
                  IntStream.range(0, 1000).parallel().forEach(i -> {
                      // 危险！多个线程同时操作 ArrayList，没有加锁
                      unsafeList.add(i); 
                  });

                  System.out.println("期望大小: 1000");
                  System.out.println("实际大小: " + unsafeList.size());
                  // 结果通常会小于 1000，或者直接抛出 ArrayIndexOutOfBoundsException
                  // 或者是 null 元素
              }
          }
          ```

          **修正方案：** 在并行流中，尽量**不要**使用副作用（不要修改外部变量）。应该使用 `.collect()` 来汇总结果，Stream API 会自动处理好线程安全合并的问题。

          ```java
          // 正确写法
          List<Integer> safeList = IntStream.range(0, 1000).parallel()
                  .boxed()
                  .collect(Collectors.toList()); // 这里的 collect 内部是线程安全的
          ```
11. 循环遍历

    1. `++i`​ vs `i++`

       文本说：​ *“前置的自增（++i）速度快...后置的先定义一个临时变量”* 。

       - **理论上**​：是的，`i++` 确实在原理上多了一步（保留旧值）。
       - **实际上**​：在 Java 中，​**这完全不需要担心**​。HotSpot JVM 的 JIT（即时编译器）非常聪明，它会发现你根本没用那个旧值，然后直接把它优化成和 `++i`​ 一样的机器码。所以在写 `for` 循环时，用哪个性能都一样。
    2. 增强型 for 循环 (Enhanced for-loop)

       文本说：​ *“循环变量是不必要的：所以速度快”* 。

       - `for (String name : friends)` 是 Java 5 引入的语法糖。
       - **底层原理**：编译器会把它变成一个 `Iterator`（迭代器）调用。

         ```java
         // 编译后的样子
         Iterator<String> iter = friends.iterator();
         while (iter.hasNext()) {
             String name = iter.next();
             System.out.println(name);
         }
         ```
       - **性能真相**​：对于数组，它和普通 `for`​ 循环一样快；对于 `ArrayList`​，也差不多。但对于 `LinkedList`​，增强型循环比普通 `for(int i)`​ 循环要快得多（因为普通循环每次 `get(i)` 都要从头数一遍链表）。
       - **核心价值**​：它的价值不在于“速度快”，而在于​**代码干净、安全**，不容易写错索引（比如越界）。
12. IO和NIO：用来交换数据，把数据从 **外部设备** 搬进 **内存**（Input），或者从 **内存** 搬到 **外部设备**（Output）。计算机的核心是 CPU 和 内存（RAM）。除此之外的所有东西（硬盘、网卡、显卡、键盘）对 CPU 来说都是“外部设备”。

    1. IO (BIO - Blocking IO)：面向流，同步阻塞，`input.read()`​ 就像服务员站在那等。只要数据没传过来，线程就**卡死**在那里，啥都干不了。

       - **抽象模型**​：​**Stream (流)** 。
       - **数据传输**：数据像传送带一样，按字节序列顺序读取。你无法随意读取流中间的数据，除非你把前面的都读完（或者缓存在内存中）。Java 的 `InputStream`​ 设计思想确实是“字节流”，它的基础方法是 `int read()`​：一次读取一个字节，如果调用这个无参方法，Java 确实会给你返回下一个字节。但我们为了性能，人工引入了一个字节数组作为“临时载体”，使用重载方法 `read(byte[] b)`​。面向字节流是指**数据没有结构，只是无序的字节序列**，并不强制要求你每次只能搬运一个字节。为了效率，我们通常“一桶一桶”地搬。

         - 逻辑层面 (API 设计)

           Java 的 `InputStream` 设计思想确实是“字节流”。

           - 它的基础方法是 `int read()`：一次读取一个字节。
           - 如果你调用这个无参方法，Java 确实会给你返回下一个字节。
         - 物理层面 (性能陷阱)

           虽然**可以**一个一个传，但**绝对不推荐**这么做。 如果写出这样的代码：

           ```java
           // 极度低效的代码
           while ((b = fis.read()) != -1) { // 每次只读 1 byte
               fos.write(b);
           }
           ```

           **发生了什么？**

           - **系统调用（System Call）** ​：`read()` 是一个系统调用。
           - **上下文切换（Context Switch）** ​：每次调用 `read()`​，CPU 都要从**用户态**切换到​**内核态**，操作系统去硬件（磁盘/网卡）拿数据，然后再切回用户态。
           - **开销**​：切换一次的成本很高。如果你读一个 1MB 的文件，按字节读需要触发 **100 万次** 上下文切换。这会让程序慢得像蜗牛。
         - 实际做法 (批量传输)

           为了避免上述问题，我们使用重载方法 `read(byte[] b)`。 这就是你提到的“读到 buffer”。虽然它属于“面向流”的 IO 类，但我们为了性能，人工引入了一个字节数组作为“临时载体”。

           **结论**：面向字节流是指**数据没有结构，只是无序的字节序列**，并不强制要求你每次只能搬运一个字节。为了效率，我们通常“一桶一桶”地搬。
       - **线程行为（阻塞）** ​：当用户线程调用 `read()`​ 或 `write()`​ 系统调用时，该线程会从**用户态**切换到​**内核态**。如果内核缓冲区没有数据（例如网卡还没收到数据），操作系统会将该线程挂起（放入等待队列）。此时线程暂停执行，释放 CPU，直到数据准备好。
       - **资源消耗**：每个连接必须占用一个独立的线程。
       - **实现：** 逻辑简单直观：打开流 -\> 循环读取字节到数组 -\> 写入目标流。代码是单线程执行的，严格的“读一批，写一批”。绝对不是同时进行的。

         ```java
         import java.io.*;

         public class BioCopy {
             public static void main(String[] args) throws IOException {
                 File source = new File("input.txt");
                 File dest = new File("output_bio.txt");

                 try (FileInputStream fis = new FileInputStream(source);
                      FileOutputStream fos = new FileOutputStream(dest)) {

                     byte[] buffer = new byte[1024]; // 用户态的字节数组
                     int length;
                     
                     // read() 会阻塞，直到读到数据或者文件结束
                     while ((length = fis.read(buffer)) != -1) {
                  // 步骤 1：fis.read 执行。
                  // 在这行代码返回之前，程序卡在这里。
                  // 它会尝试把 buffer 装满，但如果文件只剩 5 个字节，它就只装 5 个，length=5。
                  // 只有这一步彻底做完了，CPU 才会往下走。

                  // 步骤 2：fos.write 执行。
                 // 程序拿到刚才读到的 length (比如 5)，立马把这 5 个字节写出去。
                 // 只有写完了，才会回到步骤 1 进行下一轮。
                         fos.write(buffer, 0, length);
                     }
                 }
             }
         }
         ```

         1. **​`new byte[1024]`​** ​：你在 JVM 的堆内存（Heap）里申请了一块 1KB 的空间。这叫**用户缓冲区 (User Buffer)** 。
         2. **​`fis.read(buffer)`​** ：

            - **触发系统调用**​：线程发起 `read` 请求。
            - **内核读取**​：操作系统内核（Kernel）从磁盘读取数据。注意，操作系统通常不会只读 1KB，它有预读机制（Read Ahead），可能一次读 4KB 到​**内核缓冲区 (Kernel Buffer)** 。
            - **数据拷贝 (Copy 1)** ​：CPU 将数据从**内核缓冲区**拷贝到你的​**用户缓冲区**​（也就是那个 `byte[]` 数组）。
            - **返回**​：方法返回读取到的实际字节数 `len`（比如读满了就是 1024，文件快结束了可能是 50）。
         3. **​`fos.write(buffer, 0, len)`​** ：

            - **Output 什么时候读？**  Input 彻底收工（方法返回）之后，Output 拿到 CPU 控制权，才开始干活。
            - **触发系统调用**​：线程发起 `write` 请求。
            - **数据拷贝 (Copy 2)** ​：CPU 将数据从你的​**用户缓冲区**​（`byte[]`​）拷贝回​**内核缓冲区**（Socket Buffer 或 File Cache）。
            - **异步刷盘**：操作系统会在合适的时候把内核缓冲区的数据真正写到磁盘上。
    2. NIO (Non-blocking IO)：面向缓冲区，同步非阻塞，NIO 的线程调用 `read()`​ 时，如果内核里没数据，它**立刻返回 0**，线程继续往下跑，不会卡死。

       - **抽象模型**​：**Channel (通道)**  + ​**Buffer (缓冲区)** 。
       - **数据传输**：数据以块（Block）为单位搬运。数据从 Channel 读取到 Buffer 中，或者从 Buffer 写入 Channel。开发者可以在 Buffer 内部通过移动指针（Position）随意访问数据。
       - **线程行为（非阻塞）** ：

         - 将 Channel 配置为非阻塞模式 (`configureBlocking(false)`)。
         - 当线程调用 `read()`​ 时，如果内核缓冲区没有数据，系统调用会**立即返回**一个数值（通常是 0），而不会挂起线程。线程可以去处理别的事情，稍后再来检查。
       - **多路复用（IO Multiplexing）** ：利用操作系统的 `select`​、`poll`​ 或 `epoll` 机制，一个线程可以监控多个文件描述符（File Descriptor）。
       - Buffer 的内部指针

         Buffer 本质上是一个数组，通过三个属性维护状态，不理解这三个属性就无法理解 NIO：

         - **Capacity（容量）** ：Buffer 总大小。
         - **Position（当前位置）** ：下一个要读/写的索引。
         - **Limit（限制）** ：在写模式下等于 Capacity；在读模式下，代表“最多能读到哪里”（即刚才写了多少数据）。
       - 实现：逻辑复杂，涉及 **Channel** 和 **Buffer** 的状态管理。

         ```java
         import java.io.*;
         import java.nio.ByteBuffer;
         import java.nio.channels.FileChannel;

         public class NioCopy {
             public static void main(String[] args) throws IOException {
                 File source = new File("input.txt");
                 File dest = new File("output_nio.txt");

                 // Channel 必须通过流或者 RandomAccessFile 获取
                 try (FileInputStream fis = new FileInputStream(source);
                      FileOutputStream fos = new FileOutputStream(dest);
                      FileChannel inChannel = fis.getChannel();
                      FileChannel outChannel = fos.getChannel()) {

                     // 1. 分配一个 Direct Buffer 或者 Heap Buffer
                     // allocate(1024) 在堆内存分配
                     ByteBuffer buffer = ByteBuffer.allocate(1024);

                     while (true) {
                         // 2. 从 Channel 读取数据写入 Buffer
                         // 此时 buffer 处于“写模式”
                         int bytesRead = inChannel.read(buffer);
                         
                         if (bytesRead == -1) {
                             break; // 读取结束
                         }

                         // 3. 翻转 Buffer (Flip)
                         // 将 buffer 从“写模式”切换为“读模式”
                         // 核心动作：limit = position; position = 0;
                         buffer.flip();

                         // 4. 将 Buffer 中的数据写入 Channel
                         outChannel.write(buffer);

                         // 5. 清空 Buffer (Clear)
                         // 准备下一次读取
                         // 核心动作：position = 0; limit = capacity;
                         buffer.clear();
                     }
                 }
             }
         }
         ```
       - **​`buffer.flip()`​** ​ **的技术含义**：

         ```java
         // 假设刚写入了 5 个字节：position=5, limit=1024
         public final Buffer flip() {
             limit = position; // limit 变成 5，表示一会读数据只能读到索引 5
             position = 0;     // position 归零，准备从头开始读
             mark = -1;
             return this;
         }
         ```
    3. 关键：

       1. Buffer数组

          1. IO **数据控制**：依靠**额外的变量**（比如 `len`​）。你必须告诉 `write`​ 方法：“我刚才读了 `len`​ 这么长，你也写这么长”。**Buffer 角色**：只是一个傻傻的数组，没有任何逻辑。
          2. NIO **数据控制**：依靠**Buffer 自身的状态**。你不需要传 `len`​ 给 `write`​ 方法。`write`​ 方法自己会去检查 Buffer 的 `limit`​ 和 `position`​，就知道该写多少数据。**Buffer 角色**：是智能的容器对象，自己记录了“数据是从哪里开始，到哪里结束”。
       2. `flip()`​ 只是修改了这个对象内部的指针变量，它没有发送“信号”给 OutputStream。是outputstream根据Limit \= Position和Position \= 0这两个属性知道从哪开始读，读到哪里
       3. 如果仅仅是用**单线程**去读写**本地文件**（比如写个 copyFile 的 demo），**IO 和 NIO 在宏观表现上确实几乎没区别**。都是“读到内存 -\> 倒手 -\> 写出硬盘”。在这种场景下，用 NIO 甚至纯属自找麻烦（代码变多了，性能还没提升）。**它们真正的区别，只有在“网络通信”和“高并发”场景下才会暴露无遗。** 区别的核心就两个词：**阻塞（Blocking）**  vs **非阻塞（Non-Blocking）** 。

          1. IO 的模式：一对一“保姆式”服务（阻塞）

             想象这是一家​**传统 IO 餐厅**：

             - **场景**：来了 1000 个顾客（1000 个网络连接）。
             - **规则**：一个服务员（线程）只能服务一个顾客，直到顾客吃完走人。
             - **过程**：

               1. 顾客坐下，开始看菜单（​**连接建立，但没发数据**）。
               2. 服务员必须站在桌边等着，哪怕顾客看菜单看了 1 个小时，服务员也不能走，也不能去服务别人（​**Thread 被阻塞在 read() 上**）。
               3. **后果**：如果你有 1000 个顾客，老板必须雇 1000 个服务员。
               4. **代价**：工资开销巨大（内存占用大），而且这 1000 个服务员大部分时间都在发呆等顾客看菜单（CPU 资源浪费）。

             **技术翻译**：

             - ```java
               // 假设 socket 是 BIO 模式
               byte[] buffer = new byte[1024];

               System.out.println("1. 准备开始读...");

               // 【体现】：如果没有数据，程序卡死在这行！
               // 你的控制台永远打印不出下一句话，直到对面发数据或者断网。
               // 此时线程状态：WAITING (监视器等待) 或 RUNNABLE (但在阻塞在系统调用上)
               int length = inputStream.read(buffer); 

               System.out.println("2. 终于读到了，长度：" + length); // <--- 这行代码遥遥无期
               System.out.println("3. 我去干点别的...");
               ```

             - IO 是**面向流**的。
             - `input.read()`​ 就像服务员站在那等。只要数据没传过来，线程就**卡死**在那里，啥都干不了。
          2. NIO 的模式：在大堂“巡逻”服务（非阻塞 + Selector）

             现在改成​**现代 NIO 餐厅**：

             - **场景**：还是 1000 个顾客。
             - **规则**​：只需要 **1 个** 超级服务员（Selector 线程）。
             - **过程**：

               1. 顾客坐下。服务员给他个菜单，说：“想好了举手（注册事件）”，然后立马转身去下一桌。
               2. 服务员在大厅里不停地转圈（​**轮询/Selector**）。
               3. 如果顾客 A 还在看菜单，服务员看他一眼，发现没举手，直接跳过（​**非阻塞**）。
               4. 突然顾客 B 举手说“我要点菜”（​**数据到达**）。
               5. 服务员走过去记录（​**读取 Buffer**），处理完马上又去巡逻。
               6. **后果**：1 个服务员就能轻松搞定 1000 个顾客，只要这些顾客不是同时在那儿大喊大叫。

             **技术翻译**：

             - ```java
               // 【关键配置】设置为非阻塞！
               socketChannel.configureBlocking(false); 
               ByteBuffer buffer = ByteBuffer.allocate(1024);

               System.out.println("1. 准备开始读...");

               // 【体现 A：立即返回】
               // 哪怕对面一个字节都没发，这行代码也会瞬间执行完，绝不等待。
               int bytesRead = socketChannel.read(buffer); 

               // 【体现 B：返回值为 0】
               // 此时 bytesRead 等于 0。
               System.out.println("2. 读完了，返回值是：" + bytesRead); 

               // 【体现 C：执行权在手】
               // 因为没有卡在上面，所以我可以根据返回值决定接下来干嘛
               if (bytesRead > 0) {
                   System.out.println("处理业务数据...");
               } else if (bytesRead == 0) {
                   // ★★★ 这里就是“非阻塞往下执行”的极致体现 ★★★
                   // 我没读到数据，但我还活着！我可以利用这个空档去干别的事！
                   System.out.println("3. 没数据，我去处理一下日志...");
                   System.out.println("4. 我去给别的连接发个心跳...");
               }
               ```

             - NIO 是**面向 Buffer** 的。为什么 Buffer 关键？因为服务员（线程）过来时，如果有数据，就捞一碗（Buffer）带走；如果没有，就空手离开。他不需要等着水流过来。
             - **核心区别**​：NIO 的线程调用 `read()`​ 时，如果内核里没数据，它​**立刻返回 0**，线程继续往下跑，不会卡死。
          3. 为什么本地文件操作看不出区别？

             你之前提到“本地文件”操作。

             - **文件系统差异**​：在大多数现代操作系统中，对**磁盘文件**的读写操作，通常**不支持**像网络 Socket 那样的“非阻塞”模式。即使你在 Java NIO 中使用 `FileChannel`，它在底层通常依然是阻塞的。
             - **数据就绪性**：磁盘数据通常被认为是“总是可获取的”（或者等待时间极短，由硬件控制器处理）。操作系统不会像对待网络数据那样（可能等几十秒）去挂起文件读取线程。

             **因此，IO 和 NIO 的核心区别，主要体现在网络编程（Network IO）中：**

             1. **IO**​：此时线程必须**等待**数据包经过路由器、光缆传输过来，这期间线程是**闲置且阻塞**的。
             2. **NIO**​：线程​**不等待**，它利用这段空闲时间去处理其他已经收到数据的连接。
       4. 核心区别：系统调用时的线程状态

          当你的 Java 代码执行 `read()` 操作时，底层会发生系统调用。

          - **BIO (Blocking IO) 的行为**

            1. **调用**​：Java 线程发起 `read` 系统调用。
            2. **检查**：操作系统内核检查网卡/Socket 缓冲区是否有数据。
            3. **挂起 (关键点)** ：

               - 如果​**没有数据**​：操作系统会将当前线程的状态从 `RUNNABLE`​ 改为 `WAITING`​ (或 `BLOCKED`)。
               - 该线程被移出 CPU 的调度队列。它依然占用内存资源，但不再消耗 CPU 时间片。它**彻底暂停**了。
            4. **唤醒**​：一旦数据通过网络到达内核缓冲区，操作系统发送中断，唤醒该线程，将其状态改回 `RUNNABLE`​，完成数据拷贝，`read` 方法才会返回。

          - **NIO (Non-Blocking IO) 的行为**

            1. **配置**​：Channel 被配置为 `configureBlocking(false)`。
            2. **调用**​：Java 线程发起 `read` 系统调用。
            3. **立即返回 (关键点)** ：

               - 如果​**没有数据**​：内核**不挂起**线程，而是直接返回一个错误码或 0（表示读取了 0 字节）。
               - Java 线程依然处于 `RUNNABLE` 状态，它持有 CPU 控制权，代码可以立刻执行下一行（比如去处理其他连接）。
            4. **结果**：线程没有被阻塞，它只是发起了一次“询问”。
       5. 并发模型的区别：多线程 vs 多路复用

          基于上述的原子行为差异，导致了宏观架构的根本不同。

          - **BIO 架构：Thread-Per-Connection (一连接一线程)**

            - **逻辑**​：因为 `read()` 会把线程挂起，所以你不能用一个线程去处理多个连接。否则，线程一旦被连接 A 阻塞，连接 B 发来数据也没法处理。
            - **实现**：必须为每一个 Socket 连接分配一个独立的线程。
            - **致命缺陷 (C10K 问题)** ：

              - **内存消耗**：JVM 中一个线程栈默认约 1MB。1 万个连接就需要 10GB 内存。
              - **上下文切换 (Context Switch)** ：当大量数据同时到达，操作系统需要在成千上万个线程之间频繁切换，CPU 时间全浪费在保存/恢复线程上下文上，而非真正的数据处理上。

          - **NIO 架构：IO Multiplexing (IO 多路复用 / Selector)**

            - **逻辑**：因为线程不会阻塞，所以一个线程可以轮流询问 1 万个连接。但“轮流询问”（忙轮询）效率太低。
            - **解决方案 (Selector)** ​：利用操作系统提供的 `select`​、`poll`​ 或 `epoll` 系统调用。

              - Java 线程只需要发起**一次**系统调用（`selector.select()`），把 1 万个文件描述符（FD）传给内核。
              - **内核负责监控**：操作系统内核在底层高效监控这 1 万个 Socket。
              - **返回就绪列表**：只有当某些 Socket 真的有数据了，内核才唤醒 Java 线程，并告诉它：“这 3 个 Socket 有数据”。
            - **实现**：单线程（或少量线程）即可管理海量连接。
       6. 线程将非阻塞IO的空闲时间用于在其它通道上执行IO操作**背景**： 在网络通信中，绝大部分时间是“等待时间” **（等待数据包通过网线传输过来），而不是**“计算时间”。

          1. 阻塞模式 (Blocking) 的浪费

             - 线程调用 `channelA.read()`。
             - 数据没到。
             - **操作系统行为**：强制剥夺该线程的 CPU 执行权，将其挂起（Sleep）。
             - **结果**​：这段等待时间（空闲时间），线程处于“昏迷”状态，它​**什么都做不了**。它虽然空闲，但不可用。
          2. 非阻塞模式 (Non-blocking) 的利用

             - 线程调用 `channelA.read()`。
             - 数据没到。
             - **操作系统行为**​：立即返回一个 `0`​（表示没读到数据），**不挂起**线程。
             - **结果**：线程依然拥有 CPU 执行权。
             - **如何利用空闲时间**​： 既然 `channelA`​ 没数据，代码逻辑可以立刻去执行 `channelB.read()`​，或者 `channelC.read()`​。 这就是“​*利用空闲时间在其它通道上执行 IO 操作*”。

             **技术推论**​： 这意味着，理论上你写一个 `while(true)`​ 循环，里面轮询 1000 个 Channel，就可以用**一个线程**管理它们。

             **但是，这里有一个新问题**​： 如果 1000 个 Channel 此时都没数据，你的线程就会在这个死循环里疯狂空转（Busy Wait），CPU 占用率直接飙升到 100%，却没干任何正事。**这就引出了第二句——选择器（Selector）。**
       7. Java NIO的选择器允许一个单独的线程来监视多个输入通道，你可以注册多个通道使用一个选择器，然后使用一个单独的线程来“选择”通道：这些通道里已经有可以处理的输入，或者选择已准备写入的通道。这种选择机制，使得一个单独的线程很容易来管理多个通道。

          选择器（Selector）是为了解决上面提到的“CPU 空转轮询”效率低下的问题。它利用了操作系统底层的 **IO 多路复用（IO Multiplexing）**  技术（如 Linux 的 `epoll`）。

          1. 核心原理：把“询问”交给内核

             不要让 Java 线程在一个 `for` 循环里一个个去问 Channel “你有数据吗”，而是把这份名单交给操作系统。

             - **注册（Register）** ： Java 线程告诉 Selector（进而告诉操作系统内核）：“我有 A、B、C 三个通道（文件描述符 FD），你帮我盯着。如果它们之中谁有数据了（可读事件），或者是谁准备好发数据了（可写事件），你再叫醒我。”
             - **阻塞在 Selector（Blocking on Selector）** ​： Java 线程调用 `selector.select()`。

               - 此时，线程​**会阻塞**（挂起）。
               - **关键区别**：它不是阻塞在某个具体的 Channel 上（死等 A），而是阻塞在“监控器”上（等 A 或 B 或 C... 任意一个有动静）。
               - 在没有任何 Channel 活跃时，线程释放 CPU，​**不消耗资源**（解决了 CPU 100% 空转的问题）。
          2. “选择”通道 (Select)

             当网络上有数据包到达，网卡中断通知 CPU，操作系统内核发现数据属于通道 B。

             - **唤醒**​：操作系统唤醒阻塞在 `selector.select()` 上的 Java 线程。
             - **返回结果**​：`select()` 方法返回，并给线程一个列表（SelectedKeys）。
             - **处理**：Java 线程拿到列表，发现里面只有“通道 B”。

               - 线程不再需要去问 A 和 C（因为名单里没有它们）。
               - 线程直接处理 B。
       8. NIO是卡在轮询器这里，这里有数据才会下一行代码read。但是BIO没有轮询器，要么只能read到了返回length通知下一行代码从buffer中拿多少，要么read没有数组就一直卡死阻塞这一行，这是BIO本质就是阻塞的，而如果写到while循环里read得到length\=0就会陷入循环中。而NIO本质就是非阻塞的，selector有数据了才叫醒去read，是阻塞在select这里，保证只有值得读的时候才调用read。

          1. 为什么 BIO 不返回 0？（为了防止“忙轮询”炸掉 CPU）

             **假设** BIO 设计成了“读不到数据就返回 0”，我们写代码时会发生什么？

             绝大多数时候，我们在等网络数据时，数据是断断续续的。如果你写了一个服务器，想接收客户端的消息，代码大概率会写成这样：

             ```java
             // 【假设】这是你想要的“非阻塞”BIO
             byte[] buf = new byte[1024];

             while (true) {
                 int len = input.read(buf);
                 
                 if (len > 0) {
                     // 处理数据
                 } else if (len == 0) {
                     // 【关键点】
                     // 假设 BIO 返回 0 代表没数据。
                     // 你这时候能干嘛？
                     // 你总不能 break 退出吧？退出了就不读了。
                     // 你只能 continue，马上再试一次。
                 }
             }
             ```

             **后果是灾难性的：**

             - **死循环空转**​：这个 `while(true)` 会在 1 秒钟内执行几千万次！
             - **CPU 100%** ​：因为没有“阻塞（睡觉）”，CPU 会一直在这个循环里空跑，检查有没有数据。这叫 ​ **“忙轮询” (Busy Waiting)** 。
             - **资源浪费**：如果有 1000 个连接，你就要开 1000 个线程，每个线程都在疯狂空转返回 0，服务器瞬间就崩溃了。

             **BIO 此时的选择：** 为了避免这种傻乎乎的空转，BIO 选择了“阻塞”。

             - **OS 说**：“既然现在没数据，你也没别的事干（BIO模型下通常一个线程只伺候一个连接），那你先去睡觉（挂起），别占用 CPU 资源。等数据来了，我把你叫醒。”
             - **结果**​：BIO 线程在没数据时，​**CPU 占用率几乎是 0%** 。这是非常高效的资源利用方式（对于单连接而言）。

             你设想的场景是这样的：

             > 线程调用 `read`​ -\> 没数据 -\> `read`​ 立刻返回 0 -\> 线程继续跑。
             >

             但在 BIO（Blocking I/O）模式下，**真实发生的物理过程**是这样的：

             1. **Java 层**​：调用 `inputStream.read(buffer)`。
             2. **系统层**​：JVM 发起一个系统调用（System Call，比如 Linux 的 `recv`）。
             3. **内核层（关键）** ：

                - 操作系统内核检查网卡：有数据吗？
                - **没数据！**
                - 因为这个 Socket 是​**阻塞模式（Blocking Mode）** ​，操作系统直接把当前线程​**挂起（Suspend/Sleep）** ，剥夺了它的 CPU 使用权。
             4. **Java 层（结果）** ：

                - 这时候 Java 线程都已经“昏迷”了，它哪里有机会去执行 `return 0` 这行代码？
                - 它只能躺在那里等。等到数据来了，操作系统把它摇醒，它才能醒过来，拿到数据，然后返回 length \> 0。

             **结论**​：BIO 不能非阻塞读，是因为​**操作系统把线程给掐停了**，而不是因为 Java 里的数组没记录状态。
          2. 那为什么 NIO 敢返回 0？（因为有 Selector 兜底）

             NIO 之所以敢设计成“读不到返回 0”，是因为它后面站着一个大佬：​**Selector（多路复用器）** 。

             NIO 的玩法不是让你在一个死循环里不停地问 `read() == 0`，而是配合 Selector：

             1. **注册**：告诉 Selector，“帮我盯着这 1000 个连接，谁有数据了告诉我”。
             2. **阻塞（Selector.select）** ​：线程在 `selector.select()` 这里阻塞睡觉（这里依然是阻塞的！但是一个线程阻塞监听 1000 个连接）。
             3. **唤醒**​：只有当某个连接**真的有数据**时，Selector 才会醒来。
             4. **读取**​：这时候你去调 `read()`​，**肯定**是有数据的（或者连接断开），几乎不会出现返回 0 还要你处理的情况。

             **结论**：NIO 的“返回 0”是为了配合 Selector 这种\*“批处理”机制而存在的。如果没有 Selector，单纯的非阻塞返回 0 就是在谋杀 CPU。
          3. 返回值含义的历史包袱

             还有一个语义上的小原因。在 Java 的 `InputStream`​ 定义中，`read` 返回值的定义非常死板：

             -  **​`> 0`​**：读到的字节数。
             -  **​`-1`​**：文件末尾（EOF）或连接关闭。
             - **​`0`​**​：**注意！**  在 BIO 中，返回 0 通常意味着“你传进去的 byte 数组长度是 0”（`read(new byte[0])`），而不是“没读到数据”。

             如果强行把 0 定义为“没数据”，会破坏原有 API 的语义。
          4. 有 Selector：`read()`​ 确实可能返回 0。但在上面这个架构里，`read() == 0`​ **不再可怕**。

             ```java
             while (true) {
                 // 1. 先睡觉！(Blocking)
                 // 只有真的有事发生，Selector 才会把你叫醒
                 selector.select(); 

                 // 2. 醒了，去读数据
                 int n = channel.read(buf);

                 if (n == 0) {
                     // 即使这次运气不好读到了 0
                     // handleRead 方法结束
                     // loop 回到第一步 -> selector.select()
                     // 3. 又去睡觉了！
                     // 只要客户端不发数据，你就一直睡在 select() 这里，不耗 CPU。
                 }
             }
             ```
       9. 为什么 BIO 不能也用 Selector 呢

          1. 逻辑层面：BIO 会把 Selector 那个唯一的线程“坑死”

             Selector 的核心目的是 ​ **“用一个线程管理 1000 个连接”** ​。 为了实现这个目的，这个线程必须像个**渣男**一样： **“谁有数据我找谁，读完我就走，绝不留恋。”**

             如果强行把 BIO 塞给 Selector，会发生以下灾难：

             - **场景**：Selector 监控着 1000 个 BIO 连接。
             - **事件**​：Selector 发现 连接A 有数据了（`select()` 返回）。
             - **动作**​：Selector 派唯一的那个线程去处理 连接A，调用 BIO 的 `read()`。
             - **意外**​：虽然 Selector 说有数据，但假设读数据的过程中发生了某种​**滞后**（比如数据包很大，正在传输中；或者刚准备读，对方网络波动卡住了）。
             - **结果**：

               - 因为是 BIO，这个唯一的线程就会卡死（阻塞）在 连接A 的 `read()` 方法里。
               - **大灾难**：旁边 连接B、连接C、连接D 虽然也有数据来了，但因为唯一的线程被 连接A 绑架了，没人能处理它们。
               - **全剧终**：整个服务器瘫痪。

             **只有 NIO（非阻塞）才能配合 Selector**​：即便 Selector 判断失误（或者数据不完整），NIO 的 `read` 会立刻返回（哪怕读很少或读不到），线程能立马抽身去伺候 连接B。
          2. 操作系统（内核）层面：底层机制不兼容

             Selector 在 Linux 底层通常对应 ​**​`epoll`​**​（或者 `poll`​/`select`）。

             - **​`epoll`​**​ **的工作前提**​：它要求注册给它的文件描述符（File Descriptor, fd）最好是**非阻塞**的。
             - **为什么**​：操作系统的 `epoll` 机制设计初衷就是为了配合非阻塞 I/O。如果文件描述符是阻塞模式，虽然也能注册，但在进行边缘触发（Edge Triggered）等高级模式时，阻塞 I/O 会导致非常复杂的死锁或饥饿问题。

             **BIO 的 Socket** 在操作系统层面就是被配置为 **Blocking Mode** 的，它天然不适合放进 `epoll` 这种“快速反应堆”里。
          3. Java API 代码层面：血统不同

             这是最直接的限制。

             - **Selector 要求**​：`selector.register(Channel, ...)`​ 方法的参数必须是 **​`SelectableChannel`​** 的子类。
             - **NIO 的 Channel**​：`SocketChannel`​ 继承了 `SelectableChannel`，所以能注册。
             - **BIO 的 Stream**​：`Socket`​、`InputStream`​ 根本没有继承 `SelectableChannel`。

             **为什么 JDK 不改一下让 BIO 也能注册？** 因为 `InputStream` 的设计契约就是“流式、同步、阻塞”。如果要让它支持 Selector，就得把它改造成非阻塞，那它就变成 NIO 了……
       10. BIO的阻塞体现在read读不到就阻塞，NIO的非阻塞体现在read不到就返回0然后执行下一行代码（是selector的话就会又在selector的select方法阻塞，这样一个selector就可以监控很多个数据读取），BIO怎么知道读取不到数据的，是返回-1吗，NIO也怎么知道的呢

           1. BIO 怎么知道“读取不到数据”的？

              **你的猜测：“是返回 -1 吗？”答案：不是。**

              在 BIO 中，​ **“-1” 专门代表“连接关闭/文件结束”** ​。 如果仅仅是“暂时读不到数据”（比如对方正在打字，还没按回车），BIO **绝不会**返回 -1，也不会返回 0。

              **真实过程（操作系统的“催眠术”）：**

              1. **Java 调用**​：你调用 `in.read(buf)`。
              2. **系统调用**：JVM 告诉操作系统内核：“我要读数据”。
              3. **内核检查**​：内核看了一眼网卡缓冲区，发现​**是空的**（暂时没数据）。
              4. **动作（挂起）** ：

                 - 因为是 BIO（阻塞模式），内核**不会**给 Java 返回任何数值。
                 - 内核直接把当前线程​**踢出 CPU 运行队列**，把它标记为“睡眠/等待”状态。
                 - **此时 Java 代码卡在** **​`read`​**​ **这一行，没有任何返回值，线程动不了了。**
              5. **唤醒**​：等了几秒钟，网卡收到数据了。内核把数据复制进去，然后把线程​**摇醒**（恢复到 CPU 运行队列）。
              6. **返回**​：Java 线程醒来，`read`​ 方法终于执行结束，​**返回一个大于 0 的整数**（读到的字节数）。

              **总结 BIO：**

              - **暂时没数据** \= ​**死等（阻塞）** ，不返回值。
              - **连接断开了** \= ​**返回 -1**。
           2. NIO 怎么知道“读取不到数据”的？

              **你的猜测：“read不到就返回0？”答案：是的。**

              在 NIO（配置了非阻塞）中，它利用了操作系统提供的“非阻塞读”特性。

              **真实过程（操作系统的“快速回执”）：**

              1. **Java 调用**​：你调用 `channel.read(buf)`。
              2. **系统调用**​：JVM 告诉操作系统内核：“我要读数据，但我是**非阻塞**的（O\_NONBLOCK）”。
              3. **内核检查**​：内核看了一眼网卡缓冲区，发现​**是空的**。
              4. **动作（报错变现）** ：

                 - 内核**不挂起**线程。
                 - 内核立刻函数返回，并抛出一个特定的系统错误码（在 Linux 上通常是 `EAGAIN`​ 或 `EWOULDBLOCK`，意思是“现在没数据，待会再来试”）。
              5. **Java 翻译**：

                 - JVM 接收到这个“错误码”。
                 - JVM 明白这代表“缓冲区为空”，于是它不抛异常，而是**优雅地返回整数 0** 给你的 Java 代码。
              6. **Java 继续**：你的代码拿到 0，知道“哦，现在没数据”，于是执行下一行。

              **总结 NIO：**

              - **暂时没数据** \= ​**返回 0**（底层是内核告诉 JVM“现在没货”）。
              - **连接断开了** \= ​**返回 -1**。
           3. |**场景**|**BIO (InputStream)**|**NIO (SocketChannel 非阻塞)**||||
              | --| -------------------| ------------------------| --| --| --|
              |**有数据来了**|返回`> 0`(长度)|返回`> 0`(长度)||||
              |**暂时没数据 (缓冲区空)**|**不返回！** (线程被挂起/阻塞)|**返回**​**​`0`​**(立即返回，继续执行)||||
              |**连接已断开 (EOF)**|**返回**​ **​`-1`​**|**返回**​ **​`-1`​**||||
           4. 是selector的话就会又在selector的select方法阻塞，这样一个selector就可以监控很多个数据读取

              **对！就是这样！**

              - NIO 的 `read` 返回 0 虽然不阻塞，但如果你在一个死循环里一直问，CPU 就炸了。
              - 所以我们把“等待”的任务交给了 `selector.select()`。
              - `selector.select()`​ 是**阻塞**的（它在内核层调用 `epoll_wait`）。

                - 如果你监控的 1000 个连接都没动静，它就带着线程睡觉（省 CPU）。
                - 只要有**任何一个**连接有动静（数据来了、断开了），它就醒过来，告诉你“来活了”。
              - 然后你再去调 `read`​，这时候通常都能读到数据（\>0）或者读到断开（-1），几乎不会遇到 0 了。
       11. 总结：**非阻塞 Read** (保证线程不卡死在单个连接上) **+Selector** (保证线程不空转，精准打击有数据的连接) **+While 循环** (也就是 Event Loop，不断驱动整个处理流程) **=高效处理高并发（单线程管理成千上万个连接）**

           1. 自己写的：“所以就是read是否非阻塞，决定了能否用while循环和selector高效处理数据传输”
           2. 为什么“非阻塞 Read”是基石？

              - **如果 Read 是阻塞的（BIO）** ：

                - 一旦你在 `while`​ 循环里调用了 `read`，线程就被“绑架”了。
                - Selector 哪怕告诉你“连接 A 有事”，但万一你读的时候稍微卡了一下，整个 `while` 循环就停了，Selector 也没法去监控连接 B、C、D 了。
                - **结论**​：阻塞的 `read` 导致线程无法抽身，所以无法复用。
              - **如果 Read 是非阻塞的（NIO）** ：

                - 不管有没有数据，`read` 都是瞬间返回（有数据返长度，没数据返 0）。
                - **线程始终拥有控制权**。
                - 这就给了线程“回到 while 循环开头，去处理下一个连接”的机会。
           3. Selector 在其中的角色？

              - Selector 的本质是一个“过滤器”。
              - 既然 `read`​ 是非阻塞的，如果不加 Selector，我们只能在 `while` 循环里疯狂轮询（忙等待），CPU 会爆炸。
              - 有了 Selector，我们把 `while`​ 循环的节奏控制住了：**只有“有事做”的时候，循环才转一下；没事做的时候，Selector 帮我们挂起线程省电。**
13. Java IO 库的装饰模式和适配器模式

    1. 装饰模式 (Decorator Pattern) —— 增强功能

       **核心逻辑**​： 在不修改原有类代码，也不使用继承爆炸（即不要创建 `BufferedFileInputStream`​, `BufferedByteArrayInputStream` 等无数子类）的情况下，动态地给一个对象添加额外的职责（功能）。

       **文本对应点：**  `BufferedInputStream(InputStream in)`

       1. 为什么叫“装饰”？（结构视角）

          查看 JDK 源码，你会发现 `BufferedInputStream`​ 的构造函数接收的参数类型是 `InputStream`。

          - **输入**​：一个普通的 `InputStream`​（比如 `FileInputStream`，它每次读取都要访问硬盘，慢）。
          - **输出**​：一个依然是 `InputStream` 类型的对象，但在内部“包装”了刚才传入的流。
          - **增强**​：它重写了 `read()` 方法。
       2. 它是怎么工作的？（内存视角）

          文本中提到：`protected volatile byte[] buf = new byte[8192];`这是装饰模式带来的“物理增强”。

          - **没有装饰时 (**​**​`FileInputStream.read()`​** ​ **)** ​： 每次调用 `read()`，JVM 发起一次系统调用（System Call），向操作系统请求读 1 个字节。硬盘磁头转动，读取。效率极低。
          - **有装饰时 (**​**​`BufferedInputStream.read()`​** ​ **)** ：

            1. 你调用 `read()`。
            2. `BufferedInputStream`​ 发现内部数组 `buf` 是空的。
            3. 它一次性向 `FileInputStream`​ 请求 ​**8192 个字节（8KB）** 。
            4. `FileInputStream`​ 发起系统调用，一次搬运 8KB 数据到内存的 `buf` 数组中。
            5. 然后 `BufferedInputStream` 直接从内存数组里拿 1 个字节给你。
            6. 接下来的 8191 次 `read()`​ 调用，都直接从内存拿，​**不发生系统调用**。
       3. 关于并发：`synchronized`​ 修饰方法或代码块。 这说明 Java早期的 IO 库（BIO）设计是**线程安全**的，但这种锁粒度较大（直接锁整个方法或对象）。在多线程高并发环境下，这会造成线程竞争和阻塞。这也是为什么后来 NIO 出现的原因之一（NIO 的 Buffer 并不是线程安全的，需要开发者自己控制，但减少了锁的开销）。
    2. 适配器模式 (Adapter Pattern) —— 接口转换

       **核心逻辑**： 将一个类的接口转换成客户希望的另外一个接口。使得原本由于接口不兼容而不能一起工作的那些类可以一起工作。

       **文本对应点：**  `ByteArrayInputStream`​ 和 `InputStreamReader`

       1. 场景 A：数据源适配 (`ByteArrayInputStream`)

          - **问题**​：你有一个字节数组 `byte[] data = {1, 2, 3}`​（在内存里）。但是你的某个业务方法定义是 `void process(InputStream in)`。
          - **冲突**：数组不是流，传不进去。
          - **适配**​：`ByteArrayInputStream` 就是适配器。

            - **内部**​：它持有一个 `byte[]` 引用。
            - **外部**​：它实现了 `InputStream`​ 接口（即实现了 `read()` 方法）。
            - **逻辑**​：当你调用它的 `read()`​ 时，它不是去读硬盘，而是维护一个内部索引 `i`​，返回 `array[i++]`。它把“数组的操作”伪装成了“流的操作”。
       2. 场景 B：类型适配与编码 (`InputStreamReader`)

          这是 IO 库中最关键的适配器，被称为“桥梁”。

          - **问题**：

            - `InputStream`​ 只懂 ​**byte（字节）** ：机器视角，二进制，010101。
            - `Reader`​ 只懂 ​**char（字符）** ：人类视角，文本，"你好"。
            - Java 中 `char`​ 占 2 个字节（UTF-16），而流里的 `byte` 是 1 个字节。不能直接强转。
          - **适配过程**​：`new InputStreamReader(inputStream, "UTF-8")`

            1. **持有**​：它内部持有一个 `InputStream`（字节流）。
            2. **实现**​：它实现了 `Reader` 接口（字符流）。
            3. **转换（Decode）** ​：当你调用 `read()` 请求读取字符时：

               - 它去底层的字节流里读取 1 个或多个字节（取决于编码，比如 UTF-8 中文可能是 3 个字节）。
               - 利用\*\*编码表（Charset）\*\*将这些字节解析成对应的 Unicode 字符。
               - 返回这个 `char`。
    3. **代码中的体现：** 原始版本的InputStream fis \= new FileInputStream("test.txt");就是一个字节一个字节读，加了BufferedInputStream之后就可以一次多读x kb的数据了放到byte[]字节数组里，这里的每一个格子都是8bit的UTF-8 格式的数据二进制数据，InputStreamReader又可以把字节数组里对应格子的数据解码为 Unicode格式的数据放到char[]字符数组里（如'a'，'中'）（但这里的数组不囤货，给多少解码多少），这里的字符数组每一个格子都是转换成Unicode的数据，每个格子占2字节16bits，存的是unicode格式，那BufferedReader就是再次对InputStreamReader进行加速，可以使用readline，快速扫描数据读到自己的char[]字符数组，扫描到换行符/n后就把数组的这一段数据截取成string返回，还可以减少InputStreamReader的调用，直接一次出8000个字符放到bufferedreader里的字符数组里。

       - **BufferedXxx** 是为了​**性能**（减少 IO 次数）。
       - **XxxStreamReader** 是为了​**兼容**（字节转字符）。
       - **ByteArrayXxx** 是为了**伪装**（把内存数据伪装成流）。

       ```java
       // 1. FileInputStream (被装饰者/源头): 
       //    负责最底层的硬盘 IO，只懂读字节。
       InputStream fis = new FileInputStream("test.txt");

       // 2. BufferedInputStream (装饰器): 
       //    包装了 fis。并没有改变接口（还是字节流），但增加了 8KB 缓存，减少了系统调用次数。
       InputStream bis = new BufferedInputStream(fis);

       // 3. InputStreamReader (适配器): 
       //    包装了 bis。将“字节流接口”适配成了“字符流接口”。
       //    它负责把 bis 吐出来的 byte 翻译成 char。
       Reader isr = new InputStreamReader(bis, "UTF-8");

       // 4. BufferedReader (又是装饰器): 
       //    包装了 isr。虽然 isr 已经是字符流了，但为了更方便，
       //    BufferedReader 增加了 "readLine()" (按行读取) 的功能，
       //    并且内部又有了一个字符数组做缓存，进一步提高处理文本的效率。
       BufferedReader reader = new BufferedReader(isr);

       // 最终调用
       String line = reader.readLine(); 
       ```

       - 代码：

         - InputStream fis \= new FileInputStream("test.txt");

           - **是读到 fis 里吗？**  ​**不是**。
           - **发生了什么**：

             - Java 调用操作系统内核，打开了 `test.txt` 这个文件。
             - 操作系统返回一个​**文件描述符 (File Descriptor)** 。
             - `fis` 对象仅仅是持有了这个描述符（相当于拿到了文件的“句柄”或“钥匙”）。
             - **内存状态**：此时内存里没有文件内容。
         - InputStream bis \= new BufferedInputStream(fis);

           - **是读到 bis 里吗？**  ​**不是**。
           - **发生了什么**：

             - 创建了一个 `bis` 对象。
             - `bis`​ 在内部创建了一个 `byte[8192]`​ 的字节数组（​**是空的**，全是 0）。
             - `bis`​ 持有了 `fis`​ 的引用（`bis` 知道一会找谁要数据）。
             - **内存状态**：有一个空的 8KB 数组。
         - Reader isr \= new InputStreamReader(bis, "UTF-8");

           - **是读到 isr 里吗？**  ​**不是**。
           - **发生了什么**：

             - 创建了一个 `isr` 对象。
             - 它持有了 `bis` 的引用。
             - 它加载了 UTF-8 的解码器（Decoder）。
             - **内存状态**：没有数据读取。
         - BufferedReader reader \= new BufferedReader(isr);

           - **是读到 reader 里吗？**  ​**不是**。
           - **发生了什么**：

             - 创建了一个 `reader` 对象。
             - `reader`​ 在内部创建了一个 `char[8192]`​ 的字符数组（​**是空的**）。
             - `reader`​ 持有了 `isr` 的引用。
             - **内存状态**：有一个空的 8KB 字符数组。
         - String line \= reader.readLine();

           **也就是这一行，触发了连锁反应（Chain Reaction）。这是一个“拉取（Pull）”的过程：**

           1. **调用**​：你问 `reader` 要一行数据。
           2. **Reader 检查**​：`reader`​ 看自己的 `char[]` 数组，发现是空的。
           3. **请求解码**​：`reader`​ 问 `isr`：“给我一些字符”。
           4. **ISR 检查**​：`isr`​ 说：“我需要原始字节才能翻译成字符”。于是它问 `bis`：“给我一些字节”。
           5. **Buffer 检查**​：`bis`​ 看自己的 `byte[]` 数组，发现是空的。
           6. **物理读取 (关键点)** ​：`bis`​ 调用 `fis.read(buffer)`。

              - **系统调用**​：`fis` 指挥操作系统读取硬盘。
              - **数据填充**​：操作系统把硬盘上的数据（比如 8KB）一次性填满 `bis`​ 里的那个 `byte[]` 数组。
           7. **数据回流**：

              - **bis ->**  **isr**​：`bis`​ 从数组里拿出数据给 `isr`。
              - **isr ->**  **reader**​：`isr`​ 把字节翻译成字符（char），填入 `reader`​ 的 `char[]` 数组。
              - **reader ->**  **line**​：`reader`​ 在自己的数组里找换行符 `\n`​，把这一行内容复制出来，生成一个新的 `String`​ 对象给你的变量 `line`。
       - 数据流转过程：

         - 最底层：文件里存的是什么？(关于“abc”和“8bit”)

           你的理解是对的：**文件里没有“字符”，只有“二进制”。**

           - 假设文件内容是 `abc`。
           - **物理存储**：硬盘上存的是 3 个字节（Byte）。

             - `a`​ -\> ASCII 码 97 -\> 二进制 `01100001`
             - `b`​ -\> ASCII 码 98 -\> 二进制 `01100010`
             - `c`​ -\> ASCII 码 99 -\> 二进制 `01100011`
           - **FileInputStream**：

             - 如果不加缓冲，调用 `read()`​，它就指挥操作系统去硬盘把 `01100001`​ 这 8 个 bit 抠出来，转换成 Java 的 `int` (97) 返回给你。
             - **代价**：读一个字节，就要和硬盘打一次交道（很累）。
         - 第一层缓冲：BufferedInputStream (字节层面的加速)

           你的理解完全正确：

           - **FIS**：一次搬 1 个字节。
           - **BIS**​：它有一个 `byte[]` 数组（假设 8KB）。它对 FIS 说：“你别跑 8000 趟了，去跑一趟，把这 8000 个字节全拿回来，填满我的数组。”
           - **数组里的格子**​：确实，每一个格子 (`byte[i]`​) 存的就是那 8bit 的二进制数据（比如 `01100001`）。
         - 关键转换：InputStreamReader (字节 -\> 字符)

           这里你的理解有一点点偏差：​**它不一定是“把每一个格子的数组转换为 utf-8”** 。

           - **英文 (ASCII)** ​：`a`​ 占 1 个字节。此时，它读数组里的 ​**1 个格子**​，翻译成 **1 个字符** `'a'`。
           - **中文 (UTF-8)** ​：`中`​ 这个字，在 UTF-8 编码里占 ​**3 个字节**。

             - 此时，`InputStreamReader`​ 会从 `byte[]`​ 数组里连续拿走 ​**3 个格子**​（比如 `1110xxxx`​, `10xxxxxx`​, `10xxxxxx`）。
             - 经过复杂的数学运算（解码），把这 3 个字节拼成 **1 个字符** `'中'`。

           **结论**​：`InputStreamReader`​ 的作用是​**解码 (Decoding)** 。它是“生肉（字节）”变“熟肉（字符）”的加工厂。
         - BufferedReader：**字符层面的缓冲** 和 **按行读取的能力**

           - **原因一：减少“解码器”的调用频率（性能）**

             如果没有 `BufferedReader`​，你直接用 `InputStreamReader.read()`：

             1. 你要读 1 个字符。
             2. `InputStreamReader`​ 去找 `BufferedInputStream` 要数据（可能要 1 个 byte，也可能要 3 个）。
             3. `InputStreamReader`​ 启动解码逻辑，算出一个 `char` 给你。
             4. 如果你读 1000 个字符，就要启动 1000 次解码逻辑，这依然有开销。

             **加上 BufferedReader 后**：

             1. `BufferedReader`​ 也有一个数组，是 `char[]`（字符数组）。
             2. 它对 `InputStreamReader`​ 说：“你别一个一个解了，你一次性给我解出 8000 个​**字符**，填满我的字符数组。”
             3. 这样，解码动作是大批量进行的，效率更高。
           - 原因二：`readLine()` (功能，这是最重要的)

             这才是 99% 的人使用 `BufferedReader` 的原因。

             - **没有它**​： 你想读一行字。你只能写一个 `while`​ 循环，一个字符一个字符地读，每读一个都要判断：“你是换行符 `\n`​ 吗？”。如果不是，就先拼接到 `StringBuilder` 里；如果是，就停止。这代码写起来很麻烦。
             - **有它**​：`BufferedReader`​ 在把数据读到自己的 `char[]`​ 数组后，它内部的方法帮你做了上面的事。它在内存数组里快速扫描 `\n`​，然后直接把这一段截取成 `String` 返回给你。
       - 总结全流程

         假设文件内容：`A中\n`​ (A是1字节，中是3字节，\\n是1字节，共5字节)

         1. **硬盘**​：存储二进制 `01000001`​ (A) `11100100 10111000 10101101`​ (中) `00001010`​ (\\n)
         2. **FileInputStream**：负责去搬运这些二进制。
         3. **BufferedInputStream**：

            - **动作**​：一次性把这 5 个字节搬到内存的 `byte[]` 数组里。
            - **状态**​：`byte[] = {0x41, 0xE4, 0xB8, 0xAD, 0x0A, ...}`
         4. **InputStreamReader**：

            - **动作**：被 BufferedReader 催促，开始解码。
            - 拿到 `0x41`​ -\> 算出字符 `'A'`。
            - 拿到 `0xE4, 0xB8, 0xAD`​ -\> 算出字符 `'中'`。
            - 拿到 `0x0A`​ -\> 算出字符 `\n`。
         5. **BufferedReader**：

            - **动作**​：把解出来的字符存到自己的 `char[]` 数组里。
            - **状态**​：`char[] = {'A', '中', '\n', ...}`
            - **​`readLine()`​** ​：在 `char[]`​ 里扫描到 `\n`​，于是把 `'A'`​ 和 `'中'`​ 拼成字符串 `"A中"` 返回给你。
       - `BufferedInputStream`​ 缓冲的是 **Byte (生肉)** ，为了减少**硬盘**访问。`BufferedReader`​ 缓冲的是 **Char (熟肉)** ，为了减少**解码**次数，并提供  **“按行读”**  的功能。

         - `InputStreamReader`​ 为了完成工作，它肚子里其实有**两个仓库**：**原料仓库（ByteBuffer - 存字节）：** 这就是我说“凑字节”的地方。作用：专门暂存那些“读了一半、还凑不成一个整字”的残余字节（Leftover bytes）。**成品仓库（CharBuffer - 存字符）：** 这就是你说的“存的不就是字符吗”的地方。作用：解码器一旦凑齐了字节，解出了字符，就批量放在这里，等着你来拿。

           - 两个仓库的具体大小

             直接给结论：在默认情况下，这两个仓库的大小​**通常都是 8KB (8192)** 。

             - **原料仓库（ByteBuffer）** ​：默认 ​**8192 字节**。

               - *用途：*  一次性从硬盘/网络捞 8KB 的二进制数据上来。
             - **成品仓库（CharBuffer）** ​：默认 ​**8192 字符**。

               - *用途：*  解码器全力工作，把上面的字节尽可能转成字符，填满这 8192 个位置。
           - 既然成品仓库（CharBuffer）能存 8192 个字符，那它不就是批量存储了吗？为什么还需要 BufferedReader？

             这是一个非常精彩的逻辑博弈。是的，`InputStreamReader`​ ​**内部确实已经批量存储了**。

             但是， **“内部有批量存储”**  和  **“让你用得爽、跑得快”**  之间，还隔着 ​**3 个致命问题**​。这就是为什么我们在 8KB 的 `InputStreamReader`​ 外面，还要再套一个 8KB 的 `BufferedReader` 的原因。

             1. 原因一：锁的开销（Synchronization Overhead）—— 最关键的性能杀手

                请注意，`InputStreamReader`​ 是线程安全的，它的底层实现（StreamDecoder）在进行解码和读取时，通常会​**加锁（synchronized）** 。

                - **只用 InputStreamReader (ISR)** ：

                  - 假设你要读 10,000 个字符。
                  - 你调用 10,000 次 `read()`。
                  - 虽然 ISR 内部有缓存，不需要每次都找操作系统，但是！**你触发了 10,000 次获取锁和释放锁的动作**。

                    - **“为什么是 10,000 次锁？read 一次读一个字符吗？”**

                      答案是：**是的，如果你调用的是无参的** **​`read()`​** ​ **方法，它就是一次读一个字符。**

                      为了让你彻底明白这里的“数量级差距” **，我们需要对比一下**“你直接读 ISR”**和**“BR 帮你读 ISR”这两种代码写法上的巨大区别。

                      1. **场景 A：你直接用 InputStreamReader (ISR)**

                         如果你想把文件读完，你需要写一个 `while`​ 循环。因为 `isr.read()`​ 这个 API 的定义就是：​**每次只返回 1 个字符**​（返回 `int`，读到末尾返 -1）。

                         ```java
                         // 你的代码逻辑
                         int c;
                         // 【关键点】这个循环会执行 10,000 次
                         while ((c = isr.read()) != -1) { 
                             // 每一次循环，都是一次单独的“方法调用”
                             // 每一次调用，都要经历：加锁 -> 检查内部状态 -> 取字符 -> 解锁
                         }
                         ```

                         - **调用次数**：10,000 次。
                         - **锁的次数**​：ISR（及其底层的 StreamDecoder）为了线程安全，核心方法都是加锁的（`synchronized`​）。所以你​**进出大门 10,000 次**。
                      2. **场景 B：你用了 BufferedReader (BR)**

                         当你套了一层 `BufferedReader`​ 后，你的代码虽然看起来也是调 10,000 次 `br.read()`，但底层发生了质变。

                         **代码逻辑：**

                         ```java
                         int c;
                         while ((c = br.read()) != -1) { // 你找 BR 读 10,000 次
                             // ...
                         }
                         ```

                         **底层发生了什么？**

                         1. **第 1 次循环**：

                            - 你找 BR 要字符。BR 发现自己数组是空的。
                            -  **【关键动作】**  BR 转身找 ISR，调用了一个​**批量 API**​：`isr.read(myBuffer, 0, 8192)`。
                            - **ISR 锁情况**​：ISR ​**只加 1 次锁**。在这一次锁的保护下，ISR 全速运转，把 8192 个字符填满了 BR 的数组。
                            - BR 给你返回第 1 个字符。
                         2. **第 2**  **~**  **8192 次循环**：

                            - 你找 BR 要字符。
                            - BR 发现数组里还有货。
                            - **BR 完全不需要去找 ISR**​。它直接从自己的数组里拿出来给你：`return cb[nextChar++];`。
                            - **ISR 锁情况**​：​**0 次**。连 ISR 的门都不用敲。
                         3. **第 8193 次循环**：

                            - BR 数组空了。
                            - BR 再次转身找 ISR，再调用一次批量读取。
                            - **ISR 锁情况**：这是第 2 次加锁。

                         **对比结果（假设读 1 万个字符）：**

                         - **不用 BR**​：你要去骚扰 ISR ​**10,000 次**​，触发 **10,000 次** 锁竞争。
                         - **用了 BR**​：你只需要骚扰 ISR ​**2 次**​（因为 8192 \* 2 \> 10000），只触发 **2 次** 锁竞争。
                      3. **一个通俗的例子**

                         假设 **InputStreamReader** 是 ​**银行柜台**（有防弹玻璃，进去要安检，很慢）。

                         - **场景 A（没有 BufferedReader）** ：

                           - 你要领 10,000 块钱现金。
                           - 你​**去排 10,000 次队**。每次排到窗口，都只跟柜员说：“给我 1 块钱”。
                           - 柜员（ISR）每次都要：**核对身份（加锁）**  -\> 拿 1 块钱 -\> ​**签字确认（解锁）** 。
                           - **结果**：你和柜员都崩溃了。
                         - **场景 B（有 BufferedReader）** ：

                           - 你带了个​**大钱包**（BufferedReader）。
                           - 你第 1 次去窗口，跟柜员说：“把我的钱包塞满（8000块）”。
                           - 柜员：**核对身份（加锁 1 次）**  -\> 哗啦啦数 8000 块放你包里 -\> ​**签字确认（解锁 1 次）** 。
                           - 接下来 7999 次花钱，你直接从自己钱包里拿就行了，不用再去银行排队。
                      4. 总结

                         你的理解非常正确。

                         - `read()` 无参方法：一次读一个。
                         - `read(char[] cbuf)` 有参方法：一次读一堆。

                         `BufferedReader`​ 的魔力就在于：**它把你自己代码里原本低效的“10,000 次单字符读取”，转化成了底层高效的“2 次批量读取”。**  这就是它能减少锁开销和系统调用开销的根本原因。
                  - *后果：*  即使是内存操作，频繁加锁解锁也会严重拖慢 CPU。
                - **套上 BufferedReader (BR)** ：

                  - BR 也有一个 8KB 的数组。
                  - 当你调用 `br.read()` 时，BR 发现空了。
                  - BR 调用 **一次** `isr.read(buffer, 0, 8192)`。
                  - **关键点**：这一次调用，只进出一次锁，把 8192 个字符一口气搬运到了 BR 的数组里。
                  - 接下来的 8191 次读取，是你跟 BR 之间的事，​**完全不需要加锁**（或者锁的粒度非常小），纯内存数组访问，飞快。

                > **比喻：** ISR 的内部仓库就像是​**银行柜台里的点钞机**​。虽然点钞机一次能点很多钱，但你（用户）每次去取钱，都要​**排队、输入密码、签字**​（加锁开销）。哪怕你只取 1 块钱，这一套流程都少不了。`BufferedReader`​ 就像是你​**自己的钱包**。你一次性从柜台取 8000 块放钱包里。后面你花钱时，直接从钱包拿，不需要再走银行那一套繁琐流程。
                >
             2. 原因二：readLine() 的算法逻辑

                这是功能层面的硬伤。

                - `InputStreamReader`​ 的内部成品仓库（CharBuffer）是一个“滑动窗口”。它的目的是为了解码服务，解码满了解码器就停了。它没有逻辑去扫描哪里是换行符 `\n`。
                - 如果你想用 ISR 实现“按行读取”，你需要自己写代码：从 ISR 读一个 char，判断是不是 `\n`，不是就拼接到 StringBuilder...
                - `BufferedReader` 把这个脏活干了。它利用自己的数组，提供了高效的搜索算法来找换行符。
             3. 原因三：双重缓冲（Double Buffering）的权衡

                你可能会觉得： **“ISR 内部 8KB，BR 外部 8KB，这不是浪费内存吗？”**

                是的，这确实是 ​**Double Buffering（双重缓冲）** 。

                - **代价**：多消耗了 16KB 的内存（微不足道）。
                - **收益**：

                  1. 极大减少了底层 `read` 方法的调用次数（从 10000 次降为 2 次）。
                  2. 极大减少了锁竞争和同步开销。
                  3. 获得了高级 API (`readLine`)。
             4. 总结：

                你的质疑非常有道理：**InputStreamReader 确实不仅仅是转换器，它也是个“小仓库”。**

                但我们依然需要 `BufferedReader`，不是因为 ISR 存不住货，而是因为：

                1. **取货手续费太贵**：直接找 ISR 拿货（调用 read）涉及同步锁和状态检查，频次太高会亏本。
                2. **没有高级服务**：ISR 不提供“按行发货”的服务。

                所以，`BufferedReader`​ 本质上是一个  **“为了减少与底层交互频率 + 提供高级文本处理功能”**  的​**超级缓存层**。
    4. **核心区别：UTF-8 (在 byte[] 里)** ：它是**变长**的。英文占 1 字节，中文通常占 3 字节。所以它不能直接放入固定大小的 `char`​ 格子。**Unicode/UTF-16 (在 char[] 里)** ：它是**定长**的。不管英文 `'a'`​ 还是中文 `'中'`​，在 Java 内存里统统变成 **2 个字节** 存储。

       1. byte[] (UTF-8)和char[] (Unicode/UTF-16)都是二进制，但是“数字”变了

          - **byte[] (UTF-8)** ：存的是“传输/存储格式”的二进制。为了节省空间或适应网络，它把一个字拆成了好几段。
          - **char[] (Unicode/UTF-16)** ：存的是“内存工作格式”的二进制。为了让 CPU 好算数，它把每个字都规定成固定的长度（16位）。
       2. 以汉字“中”为例：汉字“中”的 Unicode 编号（码点）是 `20013`​（十六进制 `4E2D`）

          1. 场景 A：在 BufferedInputStream 的 byte[] 数组里 (UTF-8)

             UTF-8 是一种​**变长编码**。它规定“中”字在这个格式下，必须拆成 3 个字节存储。

             - **二进制数据**​：`11100100`​ `10111000`​ `10101101`
             - **物理存储**：

               - `byte[0]`​ \= `11100100` (这只是一个毫无意义的 8位数字)
               - `byte[1]`​ \= `10111000` (这也是一个毫无意义的 8位数字)
               - `byte[2]`​ \= `10101101` (同上)
             - **现状**：在这里，你必须凑齐这 3 个格子，才能拼出一个字。单独看任何一个格子，都是乱码。
          2. 场景 B：在 InputStreamReader 转换后的 char[] 数组里 (Unicode/UTF-16)

             Java 的 `char`​ 本质上是一个 ​**16位无符号整数**（UTF-16 编码）。

             - **InputStreamReader 做的事**： 它读取了上面那 3 个字节，通过一套位运算公式（解码逻辑），算出了“中”字在 Unicode 表里的原始编号。

               - 公式逻辑（简化版）：把 UTF-8 那三个字节里的有效位抠出来，重新拼在一起。
               - 计算结果：`0100111000101101`​ (十六进制 `4E2D`)。
             - **物理存储**：

               - `char[0]`​ \= `0100111000101101` (这 16个 bit 此时作为一个整体)
             - **现状**​：这 16个 bit 在计算机眼里就是一个整数 `20013`​。但是因为它的类型是 `char`​，Java 虚拟机在显示它的时候，会去查字库：“编号 20013 对应什么图画？” -\> “哦，对应‘中’字”。
       3. 再看英文字母 “A”

          这也很有趣，能帮你理解为什么需要两种格式。

          - **在 byte[] (UTF-8) 里**：

            - 二进制：`01000001` (占用 1 个字节，8 bit)
            - 节省空间。
          - **在 char[] (Unicode) 里**：

            - 二进制：`00000000 01000001` (占用 2 个字节，16 bit)
            - **注意**​：为了保持队形整齐（方便 CPU 寻址，每个字都是 2 字节），前面强行补了 8 个 `0`。
            - 虽然浪费了一半空间，但处理起来快。
       4. 总结：InputStreamReader没有把二进制变成“非二进制”。它是把  **“一种排列方式的二进制”**  翻译成了  **“另一种排列方式的二进制”** 。

          - **输入 (byte[])** ​：可能是 1 字节代表一个字，也可能是 3 字节代表一个字。​**长短不一，CPU 很难直接处理**（比如你想取第 5 个字，你无法直接算出它在内存的哪个位置，必须从头一个一个数）。
          - **转换**​：`InputStreamReader` 进行数学计算。
          - **输出 (char[])** ​：固定 2 字节代表一个字（绝大多数情况下）。​**长短一致，CPU 处理极快**​（想取第 5 个字？直接跳到内存偏移量 `5 * 2 = 10` 的位置拿数据就行了）。

          所以，`BufferedReader`​ 里的 `char[]`​ 存的依然是 `0`​ 和 `1`​，只不过这串 `0`​ 和 `1`​ 是经过**标准化**后的、Java 虚拟机能直接理解为字符的​**编码**。
14. 在 Java 8 及以前是这样的（char[]）string的一句话也是把每个字符放到字符数组里存储的，但在 Java 9 之后发生了重大变化（变成了 byte[]）。

    1. 经典时代：Java 8 及以前 (char[])

       你的直觉完全正确。在这个时期，`String` 类的源码里就是这么写的：

       ```java
       public final class String {
           // 确实就是一个 char 类型的数组
           private final char value[];
           // ...
       }
       ```

       如果你有一个字符串 `"A中"`：

       - **存储方式**​：`char[] value = new char[2];`
       - **内存样子**：

         - `value[0]`​ \= `'A'`​ (0x0041，占 2 字节) —— **浪费了高 8 位的 00**
         - `value[1]`​ \= `'中'` (0x4E2D，占 2 字节)
       - **总占用**：4 个字节。

       **结论**​：在 Java 8 之前，String 的底层和 `BufferedReader`​ 里的缓存一样，就是标准的 `char[]`。
    2. 现代时代：Java 9 及以后 (byte[] + 压缩)

       Java 的工程师发现了一个问题：**Java 程序里绝大多数时候存的都是纯英文（比如日志、URL、JSON key）。**

       对于纯英文 `'A'`​，它的 Unicode 是 `00000000 01000001`。

       - 用 `char` 存（2字节）：前 8 个 bit 全是 0，纯属浪费内存。
       - 如果能用 `byte` 存（1字节）：就能省下一半的内存空间！

       于是，从 JDK 9 开始，`String` 内部变天了：

       ```java
       public final class String {
           // 变成了 byte 数组！
           private final byte[] value;
           
           // 多了一个标记，记录现在的编码格式（0 表示 Latin-1，1 表示 UTF-16）
           private final byte coder;
       }
       ```

       这就叫  **“Compact Strings（紧凑字符串）”**  技术。它会根据你的字符串内容自动决定怎么存：

       - **情况 A：纯英文**  **​`"abc"`​** 

         - **Coder**​：标记为 `LATIN1`。
         - **存储**：也就是退化成单字节存储。

           - `value`​ \= `[0x61, 0x62, 0x63]` (也就是 'a', 'b', 'c')
         - **占用**​：3 个字节。（​**对比 Java 8 省了一半空间**）

       - **情况 B：包含中文**  **​`"A中"`​** 

         - **Coder**​：标记为 `UTF16`。
         - **存储**：回退到双字节存储（但容器是 byte[]）。

           - `value[0]`​ \= `0x41` ('A' 的低位)
           - `value[1]`​ \= `0x00` ('A' 的高位)
           - `value[2]`​ \= `0x2D` ('中' 的低位)
           - `value[3]`​ \= `0x4E` ('中' 的高位)
         - **占用**：4 个字节。（和 Java 8 一样，没省，也没亏）
    3. 关键区别：此**Java 9+ String 里的** **​`byte[]`​** ​非彼**BufferedInputStream 里的** **​`byte[]`​** 

       这里特别容易晕，千万别混淆：

       1. **BufferedInputStream 里的** **​`byte[]`​** ：

          - 存的是 ​**UTF-8**（变长的，中文占 3 字节）。
          - 这是为了​**传输**。
       2. **Java 9+ String 里的** **​`byte[]`​** ：

          - 存的是 ​**Latin-1**​（1 字节）或者 ​**UTF-16**​（2 字节）。**绝对不是 UTF-8！**
          - 这是为了​**内存计算**。
          - 它只是为了省去 `char`​ 那个“高位 0”，如果存不了（比如有中文），它本质上还是按照 `char`​ 的逻辑（2字节）把数据拆开放在 `byte` 数组里。
    4. 总结

       - **逻辑上**​：你可以永远把 String 当作是 `char[]`​（字符数组）。不管它底层怎么变，`String.charAt(0)`​ 永远返回一个 `char`（2字节）。
       - **物理上**：

         - **JDK 1.8**​：它就是 `char[]`。
         - **JDK 1.9+** ​：它是 `byte[]`​。如果是纯英文，它就压缩存储；如果有中文，它就假装自己是 `char[]` 把它拆碎了存。

       所以，你现在的理解模型已经非常完善了：**内存里处理文本，本质上就是按“字符”（16位/2字节）来玩的，String 只是为了省内存做了一点黑科技。**
15. **String** 是“一次性筷子”，用完就扔，频繁用很浪费。**StringBuilder** 是“可伸缩的碗”，能一直往里装东西，满了就换个更大的碗把东西倒进去，单人专用。**StringBuffer** 也是“可伸缩的碗”，但是每次夹菜都要先申请“夹菜许可证”（锁），适合大家一起用。

    1. 核心区别：不可变 vs 可变 (Immutable vs Mutable)

       它们的底层确实都是数组（Java 9 之前是 `char[]`​，之后是 `byte[]`），但对待这个数组的态度完全不同。

       - **String：不可变**

         - **内存行为**：

           - `String`​ 内部的数组是 `final` 的（且没有公开的方法去修改它）。
           - 当你执行 `str + "a"`​ 时，JVM ​**不会**（也无法）在原数组后面直接加一个字符。
           - **实际动作**：

             1. JVM 申请一块​**新内存**​（大小 \= 旧长度 + 1）。
             2. 把旧数据拷贝过去。
             3. 把 `'a'` 放进去。
             4. 让你的引用指向这个​**新对象**。
             5. 旧对象变成垃圾，等待 GC 回收。
         - **代价**​：如果你在一个 `for` 循环里拼接字符串，会疯狂创建新对象，频繁触发 GC，性能极差。

       - **StringBuilder / StringBuffer：可变**

         - **内存行为**：

           - 它们继承自 `AbstractStringBuilder`​，内部数组**不是** `final` 的，而且通常会预留多余的空间（默认 16 个字符的缓冲）。
           - 当你执行 `.append("a")` 时：

             - 如果数组没满：直接在下一个空位填入 `'a'`​。**没有对象创建，没有内存拷贝。**
             - 如果数组满了：执行​**扩容**（后面讲）。
    2. 线程安全：锁 vs 裸奔

       1. String：天然安全。因为它是**不可变**的。一旦创建就不改，所以 100 个线程同时读它也没问题。如果需要改，反正会生成新对象，互不干扰。
       2. StringBuffer：线程安全。它的核心方法（如 `append`​）都加了 `synchronized` 关键字。安全多线程同时操作一个 StringBuffer 不会乱，但也慢，哪怕只有单线程在跑，它也要不断地去申请锁、释放锁（虽然 JVM 有锁优化，但依然有开销）
       3. StringBuilder：非线程安全。完全没有锁，代码和 StringBuffer 几乎一样，就是去掉了 `synchronized`​。很快，但多线程同时 append，可能会覆盖数据或报错。但在方法内部（局部变量）使用时，它是**首选**。
    3. 为什么有时候 `String` 拼接反而快？那个“JVM 的把戏”：编译器优化

       #### **场景 A：编译期常量折叠 (Constant Folding)**

       ```java
       // 你的代码
       String s1 = "This is only a" + " simple" + " test";
       ```

       - **编译器 (javac) 的视角**​： “我看出来了，这三个都是​**字面量（常量）** ，它们永远不会变。我干嘛要等到运行的时候才拼接？我现在就算好！”
       - **编译后的 .class 文件**：
       - **结论**​：这不需要计算，直接从常量池拿，当然快到飞起。这也解释了为什么 `a == c` 是 true，因为它们指向常量池里的同一个对象。

       #### **场景 B：运行时拼接**

       ```java
       String s2 = "This is only a";
       String s3 = " simple";
       // 你的代码
       String s1 = s2 + s3; 
       ```

       - **编译器视角**​： “`s2`​ 和 `s3` 是变量，虽然现在看着像常量，但鬼知道运行的时候会不会变？我不能提前算好。”
       - **实际执行**：

         - **Java 8 以前**​：编译器会偷偷把这行代码改成 `new StringBuilder().append(s2).append(s3).toString()`。
         - **Java 9 以后**​：利用 `InvokeDynamic` 指令进行更高级的优化，但本质上依然涉及计算和内存分配。
       - **结论**：这种情况下，String 拼接比 StringBuilder 慢，因为它涉及新 String 对象的创建。
    4. 扩容机制：System.arraycopy

       当 StringBuilder 发现内部数组满了，它怎么变大？

       1. **计算新容量**​：通常是 `oldCapacity * 2 + 2`（大约翻倍）。
       2. **分配新数组**​：`char[] newArray = new char[newCapacity];`
       3. **底层拷贝**​：`System.arraycopy(oldArray, 0, newArray, 0, count);`

          - 这是一个 ​**native 方法**（C++ 实现）。
          - 它直接在内存层面进行块拷贝（memcpy），速度极快，比用 `for` 循环一个一个赋值要快得多。
       4. **替换**​：内部指针指向 `newArray`，丢弃旧数组。
16. 内存泄露是指无用对象（不再使用的对象）持续占有内存或无用对象的内存得不到及时释放，从而造成的内存空间的浪费称为内存泄露。无法被GC

‍
