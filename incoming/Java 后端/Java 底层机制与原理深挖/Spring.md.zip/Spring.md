1. 只要 XML 解析完，`BeanDefinition`​ 就已经在 Map 里了。`BeanFactoryPostProcessor` 是对着 Map 里已经存在的东西进行“修补”或“调整参数”。
2. Spring AOP 具体工作流程：**入口拦截**、**链的获取**、**链的递归执行。** MethodInterceptor是真正的方法（比如前置后置通知会被打包为MethodInterceptor对象），methodinvocation对象（包装了这个连接点所有上下文信息）就是这条链上去找interceptor用的，只有proceed方法，自己作为驱动器，真正实现类还会把index设为-1。exposeinvocationinterceptor对象作为链的第一个，MethodInterceptor执行完就执行调它的MethodInvocation的proceed方法（注意是同一个 Invocation 对象实例），这个proceed方法里呢就index+1取到下一个methodinterceptor，直到链的最后一个执行真正的方法，但是注意在递归过程中，**所有**拦截器（包括 AfterAdvice）都在目标方法**之前**被调用进入 `invoke`​ 方法。**区别在于控制流的写法，BeforeAdvice** 是在 `proceed()`​ **之前**执行增强逻辑，**AfterAdvice** 是在 `proceed()`​ **返回之后**（即 `finally` 块中）执行增强逻辑，看起来像是只占位不执行一样

   1. Spring AOP 在运行时通过 `JdkDynamicAopProxy`​ 的 `invoke`​ 方法作为总入口拦截代理对象的调用，它首先获取由适配器（Adapter）将各种 Advice 转换而成的 `MethodInterceptor`​ 拦截器链（链首通常是 `ExposeInvocationInterceptor`​），并实例化一个封装了连接点所有上下文信息（如目标对象、方法、参数）及执行索引（初始为-1）的 `ReflectiveMethodInvocation`​ 对象；随后该对象作为驱动器，利用责任链模式通过 `proceed()`​ 方法的伪递归机制推进流程，每次调用使索引自增并获取下一个拦截器执行其 `invoke`​ 方法，拦截器在执行完增强逻辑后必须回调 `proceed()` 从而将请求不断压入调用栈，直至链条遍历完毕反射调用目标原本方法，最后随着调用栈逐层回溯（出栈）完成后续逻辑并将结果返回给调用方。
   2. 第一阶段：入口拦截 (`JdkDynamicAopProxy`)

      当客户端调用代理对象的方法（如 `proxy.save()`​）时，JVM 会将请求转发给 `JdkDynamicAopProxy.invoke()` 方法。这是 AOP 逻辑的物理入口。

      **核心代码逻辑 (**​**​`JdkDynamicAopProxy.java`​**​ **)：**

      ```java
      public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
          MethodInvocation invocation;
          List<Object> chain;

          // 1. 获取目标对象 (Target)
          // AdvisedSupport advised 是保存配置信息的对象
          TargetSource targetSource = this.advised.targetSource;
          Object target = targetSource.getTarget();
          Class<?> targetClass = (target != null ? target.getClass() : null);

          // 2. 【关键】获取拦截器链
          // 根据当前调用的方法 (method) 和目标类 (targetClass)，去查找匹配的 Advisor
          // 并将 Advisor 中的 Advice 适配成 MethodInterceptor
          chain = this.advised.getInterceptorsAndDynamicInterceptionAdvice(method, targetClass);

          // 3. 判断链是否为空
          if (chain.isEmpty()) {
              // 如果没有配置拦截器，直接反射调用目标对象的方法
              return method.invoke(target, args);
          } else {
              // 4. 【关键】创建 MethodInvocation (执行器)
              // 将代理对象、目标对象、方法、参数、拦截器链，全部封装进去
              invocation = new ReflectiveMethodInvocation(
                      proxy, target, method, args, targetClass, chain);

              // 5. 开始执行链
              return invocation.proceed();
          }
      }
      ```
   3. 第二阶段：链的递归执行 (`ReflectiveMethodInvocation`)

      这是 AOP 流程中最复杂、也是最精妙的部分。Spring 使用 **​`ReflectiveMethodInvocation`​** 类来实现链式调用。

      它的核心机制是：**维护一个索引指针** **​`currentInterceptorIndex`​**​ **，在** **​`proceed()`​** ​ **方法中递归调用。而Chain 对象**只是死数据，它不知道当前执行到哪了。

      **核心代码逻辑 (**​**​`ReflectiveMethodInvocation.java`​**​ **)：**

      ```java
      public class ReflectiveMethodInvocation implements MethodInvocation {

          protected final List<?> interceptorsAndDynamicInterceptionAdvice; // 拦截器链
          private int currentInterceptorIndex = -1; // 当前执行到的拦截器索引，初始为 -1

          public Object proceed() throws Throwable {
              // 1. 【递归终止条件】
              // 如果索引指到了链条的末尾，说明所有拦截器都执行完了
              if (this.currentInterceptorIndex == this.interceptorsAndDynamicInterceptionAdvice.size() - 1) {
                  // 通过反射，真正调用目标对象 (Target) 的业务方法
                  return invokeJoinpoint();
              }

              // 2. 获取下一个拦截器
              // ++this.currentInterceptorIndex：索引自增，取出下一个
              Object interceptorOrInterceptionAdvice =
                      this.interceptorsAndDynamicInterceptionAdvice.get(++this.currentInterceptorIndex);

              // 3. 执行拦截器
              // 注意：这里将 'this' (当前的 MethodInvocation 对象) 作为参数传给了拦截器
              // 这就是为什么拦截器里必须调用 mi.proceed() 才能回到这里继续往下走
              // return 拿到的就是methodInterceptor的mi.proceed();的返回结果
              // 但是又进入mi.proceed();意味着index+1且invoke下一个methodInterceptor，然后又进入mi.proceed();
              // 直到proceed方法的if判断判断为所有拦截器都执行完了
              return ((MethodInterceptor) interceptorOrInterceptionAdvice).invoke(this);
          }
      }
      ```
   4. 第三阶段：拦截器与链的交互 (`MethodInterceptor`)

      为了形成闭环，所有的拦截器（如 `MethodBeforeAdviceInterceptor`​）在执行完自己的增强逻辑后，**必须**回调 `MethodInvocation.proceed()`。

      **以“前置通知”的适配器为例 (**​**​`MethodBeforeAdviceInterceptor`​**​ **)：**

      ```java
      public class MethodBeforeAdviceInterceptor implements MethodInterceptor {
          private MethodBeforeAdvice advice;

          @Override
          public Object invoke(MethodInvocation mi) throws Throwable {
              // 1. 执行前置增强逻辑 (Advice)
              // 用户正在调用的那个方法是哪个？，用户传进来的参数是什么，在这个操作中，目标对象（Target）是谁？
              this.advice.before(mi.getMethod(), mi.getArguments(), mi.getThis());

              // 2. 【关键回跳】
              // 调用 mi.proceed()，控制权回到 ReflectiveMethodInvocation
              // 从而触发 list.get(++index)，去执行下一个拦截器
              return mi.proceed();
          }
      }
      ```
      ```java
      public class AspectJAfterAdvice implements MethodInterceptor {

          @Override
          public Object invoke(MethodInvocation mi) throws Throwable {
              try {
                  // 【Part A：直接放行】
                  // 它是第一行代码！啥也没干，直接把控制权交出去了！
                  // 此时程序继续递归下潜，去找目标方法了...
                  return mi.proceed(); 
              } finally {
                  // 【Part B：后置逻辑】
                  // 只有当 mi.proceed() 执行完（也就是目标方法跑完，拿着结果回来了）
                  // 或者是抛异常回来了
                  // 这行代码才会执行！
                  this.advice.after();
              }
          }
      }
      ```
