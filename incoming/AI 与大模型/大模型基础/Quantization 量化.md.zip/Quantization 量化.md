1. **量化 quantization = 把原来很精细的小数，用更少 bit 的离散数字近似表示。**
2. **Linear Quantization: reconstructed weight = (quantized weight - zero_point) × scale**

   1. scale：缩放比例float 值 ↔ int 编号  zero point：零点偏移
   2. scale 的作用是决定：**每两个量化档位之间隔多远。**

      公式：scale = (原始最大值 - 原始最小值) / (整数最大值 - 整数最小值)
   3. zero point 的目标是：**让整数 q 的某个值刚好对应真实的 0。**

      先算 scale：

      ```
      // max数据的最大值，q_max这个范围能表示的最大值，如int3的q_max为4
      scale = (max - min) / (q_max - q_min) 
            = (2.12 - (-1.08)) / (1 - (-2))
            = 3.20 / 3
            ≈ 1.07
      ```

      然后算 zero point：

      ```
      zero_point = q_min - min / scale
      ```
3. **Post-training quantization：已经训练好的 LLM，不再训练它，只是把每一层的权重矩阵 W 压缩成低 bit 整数，并保存 scale、zero point；推理时再近似还原使用。**

   1. 权重的quantization：很直接，因为模型训练完以后，权重 `W` 已经固定了
   2. activation的quantization：不直接，因为**activation 不是固定存在模型文件里的，** 它取决于输入。

      1. activation就是每一层的输出到下一层的输入的中间状态，input不同每一层的h就不同

         比如你输入：

         ```
         “你好”
         ```

         第 1 层可能产生一堆 `h1`。

         你输入：

         ```
         “解释一下量化”
         ```

         第 1 层产生的 `h1` 又不一样。

         你输入：

         ```
         “写一段 Java 代码”
         ```

         `h1、h2、h3` 又变了。

         所以 activation 的范围不是固定的。
      2. activation quantization 要用 samples：拿一小批样本输入模型，跑一遍前向传播，收集每一层的 activation，然后估计它们的范围。（这时候要用原始的W而不是量化后的W）

         比如拿 128 条校准样本：

         ```
         样本1：你好
         样本2：解释量化
         样本3：写代码
         ...
         样本128：总结文章
         ```

         把它们喂进模型，得到：

         ```
         第1层的 h1 样本
         第2层的 h2 样本
         第3层的 h3 样本
         ...
         ```

         然后统计每层 activation 的范围。

         比如第 1 层的激活值大概在：

         ```
         h1: -3.2 到 4.5
         ```

         那就给第 1 层 activation 算一组：

         ```
         S1, Z1
         ```

         第 2 层激活值大概在：

         ```
         h2: -8.1 到 6.7
         ```

         那就给第 2 层 activation 算一组：

         ```
         S2, Z2
         ```

         所以图右上角的意思就是：

         ```
         怎样确定 S, Z？
         ↑
         用 samples of h1, h2, ...
         ```

         也就是：**通过样本输入，收集中间激活值，再用这些激活值估计 scale 和 zero point。**
      3. 如果用户输入不在 sample 里，但产生的 activation 分布和 sample 差不多，就没事；如果差很多，activation 超出校准范围，就会被 clipping，误差变大，模型效果下降。

         1. **情况 1：用户输入产生的 activation 仍然落在估计范围内**

            比如校准样本估出来第 10 层 activation 大概是：

            ```
            -4 到 4
            ```

            真实用户输入虽然没出现在 sample 里，但它产生的 activation 是：

            ```
            -3.2, 1.7, 2.8
            ```

            那没问题，还是能正常量化。

            因为 calibration sample 不需要包含所有用户输入，只需要​**代表大多数输入分布**。

            就像你不需要问全国所有人身高，只抽样一万人，大概也能估出身高范围。
         2. **情况 2：用户输入产生的 activation 超出估计范围**

            比如 calibration sample 估出来：

            ```
            activation 范围：-4 到 4
            ```

            但某个真实输入产生了：

            ```
            activation = 8.7
            ```

            那 int8 量化时怎么办？

            它不能表示超过范围的值，只能把它​**截断/夹住**​，叫 ​**clipping**。

            比如最大只能还原到 4，那么：

            ```
            8.7 → 被夹成 4
            ```

            这就会产生很大误差。

            所以极端输入、分布外输入、很长文本、代码、数学推理、多语言场景，都可能让 activation 分布和 calibration samples 不一样，从而导致量化效果下降。
         3. **所以 calibration samples 要尽量“代表真实使用场景”，** 比如你量化的是聊天模型，那 calibration samples 里就要有：

            ```
            日常对话
            代码
            数学
            中文
            英文
            长文本
            推理问题
            总结问题
            ```

            如果你只拿 128 条英文闲聊样本去校准，然后真实用户大量问中文代码和数学，activation 范围可能就不准。

            所以 PTQ 里的 activation quantization 很依赖校准数据质量。
         4. **那怎么解决这个问题？**

            1. **用更好的 calibration samples**

               选更接近真实使用场景的数据。

               比如大模型常用一些通用文本、对话、代码、数学样本来校准，让 activation 范围更稳。
            2. **不量化 activation，只量化 weight**

               很多 LLM 部署里的 4bit 量化主要是：

               ```
               weight-only quantization
               ```

               也就是：

               ```
               权重量化：W 变 int4/int8
               激活值：h 仍然用 fp16/bf16
               ```

               这样就避开了 activation 范围难估的问题。

               例如很多本地大模型 int4，其实重点是把权重压小，activation 不一定也压成 int4。
            3. **动态量化 activation**：**每次推理时，根据当前输入实时统计 activation 的范围，再算 scale。**

               也就是：

               ```
               用户输入来了
               ↓
               这一层产生 activation
               ↓
               现场看这一批 activation 的 min/max
               ↓
               现场算 scale / zero point
               ↓
               再量化
               ```

               这叫 ​**dynamic quantization**。

               优点是更适应当前输入。  
               缺点是运行时要额外统计范围，可能更慢、更复杂。
   3. W\_hat 不是原来的小数权重，它只是低 bit 整数编号。同一个档里的所有原始 float 值，最后只能还原成同一个近似值。不过补充一个细节：**同一个编号 q 在同一组 scale/zero point 下只有一个还原值。** 但如果不同层、不同通道、不同 group 有不同的 scale，那么同样的 `q = 1` 在不同组里可能对应不同的还原值。

      比如图里 2-bit 只有 4 个档：

      ```
      编号 q = -2  →  还原值 -1.07
      编号 q = -1  →  还原值  0
      编号 q =  0  →  还原值  1.07
      编号 q =  1  →  还原值  2.14
      ```

      所以原来很多不同的小数：

      ```
      -1.08, -0.98, -0.91
      ```

      可能都会被分到 `q = -2` 这个档。

      然后推理时，它们全都只能还原成：

      ```
      -1.07
      ```

      也就是说：

      ```
      -1.08 → q=-2 → -1.07
      -0.98 → q=-2 → -1.07
      -0.91 → q=-2 → -1.07
      ```

      它们原来是不一样的，但量化后都变成同一个代表值。
   4. 流程：

      已经训练好的 LLM  
              ↓  
      拿出每一层权重 W  
              ↓  
      计算每一层的 scale S 和 zero point Z  
              ↓  
      把 float 权重量化成低 bit 整数 W_hat  
              ↓  
      保存 W_hat、S、Z  
              ↓  
      推理时用 S × (W_hat - Z) 近似还原  
              ↓  
      用近似权重做前向传播
4. **Quantization-aware Training：量化感知训练，训练的时候就模拟量化，让模型提前知道自己未来会被量化。**

   1. 流程：

      原始权重 W  
         ↓  
      模拟量化成 int4/int8  
         ↓  
      再反量化成近似 float  
         ↓  
      用这个近似权重去前向传播  
         ↓  
      计算 loss  
         ↓  
      反向传播更新原始权重
   2. 既然 W、X、Y 都可以用「整数编号 + scale + zero point」表示，那我们就把 `Y = WX` 改写成整数版本，让矩阵乘法尽量发生在整数上。

      假设：

      ```
      W = 2.14
      X = 3.00
      ```

      真实 float 计算是：

      ```
      Y = W × X = 2.14 × 3.00 = 6.42
      ```

      但量化后，模型里面可能存的是：

      ```
      q_w = 1
      q_x = 5
      ```

      它们不是直接等于真实值，而是通过 scale 和 zero point 还原。

      比如：

      ```
      W = S_w × (q_w - z_w)
      X = S_x × (q_x - z_x)
      ```

      所以推理时不一定要先完整还原成 float，而是可以先算整数部分：

      ```
      (q_w - z_w)(q_x - z_x)
      ```

      再乘一个总缩放：

      ```
      S_w × S_x / S_y
      ```

      最后得到输出整数：

      ```
      q_y
      ```
5. **SmoothQuant：activation 很难量化，所以把 activation 里的“大尖刺/离群值”转移到 weight 里面去,用一个缩放系数 S，把 activation 里的大 outlier “搬”到 weight 里，让 activation 变平滑，从而更容易量化。**

   1. 怎么算：

      ```
      1. 先算每个通道的 s_j
      2. 用 s_j 缩小 X 的对应列
      3. 用 s_j 放大 W 的对应行
      ```

      原公式是：

      ```
      Y = XW
      ```

      SmoothQuant 改成：

      ```
      Y = (X · diag(s)^-1) · (diag(s) · W)
      ```

      中间的 `diag(s)^-1 · diag(s)`​ 会抵消，所以结果还是原来的 `XW`。diag对角线每一个都是每通道的s，除此之外都是0

‍
