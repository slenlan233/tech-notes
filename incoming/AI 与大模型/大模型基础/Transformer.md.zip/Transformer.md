1. $$
   Z = \mathrm{softmax}\left(\frac{QK^T}{\sqrt{d_k}}\right)V
   $$

   每个 token 先用自己的 Q 去和所有 token 的 K 计算相关性，得到“该关注谁”的分数；再经过 softmax 变成比例；最后按照这些比例，从所有 token 的 V 里加权拿信息，得到新的 token 表示 Z。Attention 最终输出的是每个 token 的新语义向量，不是一个单独的数，这个新向量已经融合了它关注到的上下文信息，表示的是这个 token 在语义空间里的位置

   1. **Q、K、V 分别是什么？**

      假设一句话有几个 token，比如：

      > 我 / 喜欢 / 你
      >

      每个 token 原本都有一个向量。经过三个矩阵变换后，会变成三套向量：

      1. **Q：Query，查询向量**

         表示：

         > 我这个 token 现在想找什么信息？
         >

         像一个人拿着问题去问别人。
      2. **K：Key，键向量**

         表示：

         > 我这个 token 身上有什么“标签”可以被别人匹配？
         >

         像每个人胸前贴着关键词。
      3. **V：Value，值向量**

         表示：

         > 如果别人关注我，真正能从我这里拿走的信息是什么？
         >

         所以：

         **Q 和 K 是用来算“该看谁”的，V 是真正被拿来加权汇总的信息。**
   2. **为什么是** **$QK^T$**​ **？**

      假设图里：

      $$
      Q =
      \begin{bmatrix}
      q_1 \\
      q_2
      \end{bmatrix}
      $$

      有 2 个 token，每个 token 一个 Q 向量。

      $$
      K =
      \begin{bmatrix}
      k_1 \\
      k_2
      \end{bmatrix}
      $$

      也有 2 个 token，每个 token 一个 K 向量。

      算：

      $$
      QK^T
      $$

      会得到一个 ​**2 × 2 的分数矩阵**：

      $$
      \begin{bmatrix}
      q_1 \cdot k_1 & q_1 \cdot k_2 \\
      q_2 \cdot k_1 & q_2 \cdot k_2
      \end{bmatrix}
      $$

      意思是：

      $$
      \begin{bmatrix}
      第1个token看第1个token的分数 & 第1个token看第2个token的分数 \\
      第2个token看第1个token的分数 & 第2个token看第2个token的分数
      \end{bmatrix}
      $$

      也就是每个 token 都会问：

      > 我应该关注自己多一点，还是关注别人多一点？
      >
   3. **为什么要除以** **$\sqrt{d_k}$**​ **？**

      因为如果向量维度很大，点积结果可能会特别大。

      比如维度是 64，Q 和 K 点积出来可能很容易变成 20、30 这种大数。

      大数丢进 softmax 后会变得特别极端：

      $$
      [20, 1, 0] \rightarrow [几乎100\%, 几乎0, 几乎0]
      $$

      这样梯度容易不好训练。

      所以除以：

      $$
      \sqrt{d_k}
      $$

      就是把分数压一压，让 softmax 不要太极端。
   4. **softmax 在这里干嘛？**

      假设某个 token 算出来它对两个 token 的关注分数是：

      $$
      [2, 1]
      $$

      softmax 后大概变成：

      $$
      [0.73, 0.27]
      $$

      意思是：

      > 我 73% 注意第一个 token，27% 注意第二个 token。
      >

      所以 softmax 的作用是：

      **把原始分数变成注意力权重，并且每一行加起来等于 1。**

      注意，是 ​**每一行做 softmax**。
   5. **最后为什么还要乘 V？**

      因为前面只是算出了“该看谁”，还没真正拿信息。

      假设 softmax 后得到：

      $$
      A =
      \begin{bmatrix}
      0.7 & 0.3 \\
      0.2 & 0.8
      \end{bmatrix}
      $$

      V 是：

      $$
      V =
      \begin{bmatrix}
      v_1 \\
      v_2
      \end{bmatrix}
      $$

      那么：

      $$
      Z = AV
      $$

      得到：

      $$
      z_1 = 0.7v_1 + 0.3v_2
      $$

      $$
      z_2 = 0.2v_1 + 0.8v_2
      $$

      也就是说：

      第一个 token 的新表示，不再只是它自己，而是：

      > 70% 自己的信息 + 30% 第二个 token 的信息
      >

      第二个 token 的新表示是：

      > 20% 第一个 token 的信息 + 80% 自己的信息
      >

      这就是 attention 最核心的东西：

      **每个 token 根据上下文，重新混合其他 token 的信息，生成更懂上下文的新向量 Z。**
   6. **如果一个 attention 层里有 8 个 head，那么通常会把 8 个 head 各自的** **$W_q$** **拼成一个大的** **$W_q$**​ **，一次矩阵乘法算出所有 head 的 Q，再 reshape 拆成 8 个 head。但如果是：一个 Transformer 有 8 层，那每层都有自己的** **$W_q, W_k, W_v, W_o$**​ **，不能跨层合成一次算完。**

      1. **8 个 head 的情况：可以合成一个大** **$W_q$**  

         假设每个 token 的 hidden size 是：

         $$
         d_{model}=512
         $$

         有 8 个 head，每个 head 的维度是：

         $$
         d_k = 64
         $$

         因为：

         $$
         8 \times 64 = 512
         $$

         每个 head 本来可以有自己的：

         $$
         W_q^{(1)}, W_q^{(2)}, ..., W_q^{(8)}
         $$

         每个小 $W_q$ 的形状是：

         $$
         512 \times 64
         $$

         也就是：

         ```
         输入512维 → 变成这个head自己的64维Q
         ```

         如果一个一个算，就是：

         $$
         Q_1 = XW_q^{(1)}
         $$

         $$
         Q_2 = XW_q^{(2)}
         $$

         一直到：

         $$
         Q_8 = XW_q^{(8)}
         $$

         但这样太麻烦，所以实际代码里经常把它们横着拼成一个大矩阵：

         $$
         W_q =
         [W_q^{(1)}, W_q^{(2)}, ..., W_q^{(8)}]
         $$

         形状变成：

         $$
         512 \times 512
         $$

         然后一次算：

         $$
         Q = XW_q
         $$

         得到的 $Q$ 形状是：

         $$
         seq\_len \times 512
         $$

         再把这 512 维拆成 8 份：

         $$
         seq\_len \times 8 \times 64
         $$

         也就是每个 head 拿到自己的那 64 维。

         所以你听到的“8 个 $W_q$ 合成一个大矩阵计算”，**大概率说的是 8 个 attention head，不是 8 层。**
      2. **那 8 层 Transformer 呢？**

         如果是 8 层 Transformer，那是这样的：

         ```
         第1层输入 X0 → 第1层输出 X1
         第2层输入 X1 → 第2层输出 X2
         第3层输入 X2 → 第3层输出 X3
         ...
         第8层输入 X7 → 第8层输出 X8
         ```

         第 2 层的输入不是原始 $X$，而是第 1 层处理完的结果。

         所以不能直接把 8 层的 $W_q$ 合成一个巨大矩阵一次算完，因为：

         $$
         X_1 = Layer_1(X_0)
         $$

         $$
         X_2 = Layer_2(X_1)
         $$

         每一层都依赖上一层的结果。

         这就像做菜：

         ```
         洗菜 → 切菜 → 炒菜 → 调味
         ```

         你不能把“洗、切、炒、调味”合成一个矩阵同时做，因为后一步依赖前一步的结果。
   7. **那模型怎么用这个向量生成词？**

      最后一层输出某个 token 的向量，比如：

      ```
      h = [0.12, -0.83, 1.45, ...]
      ```

      然后模型会拿这个向量去和词表里的所有词做比较。

      可以理解成：

      ```
      当前上下文向量 h
      分别和：
      “苹果”的向量
      “香蕉”的向量
      “电脑”的向量
      “但是”的向量
      ……
      计算匹配分数
      ```

      分数最高的 token，就最可能成为下一个 token。

      更正式一点：

      ```
      logits = h × W_vocab
      ```

      其中：

      ```
      h: 当前 token 的输出向量
      W_vocab: 词表输出矩阵
      logits: 每个词的分数
      ```

      再经过 softmax，就变成每个词的概率。
2. $$
   MultiHead(Q,K,V)=Concat(head1​,…,headh​)Wo​+bo​
   $$

   bias 是线性层里的“平移修正项”；Wo 是多头 attention 最后的“总融合矩阵”，把多个 head 拼接后的结果重新混合成下一层能用的向量。Wo 也是训练出来的，最后学会怎么把多个 head 的输出融合得最好。

   1. **bias 是什么？**

      bias 就是偏置项，类似：

      $$
      y = xW + b
      $$

      里面的 $b$。

      它不是矩阵主角，主角是 $W$，但是 bias 可以让输出整体平移一下。

      比如没有 bias：

      $$
      y = 2x
      $$

      当 $x=0$ 时，$y=0$。

      有 bias：

      $$
      y = 2x + 3
      $$

      当 $x=0$ 时，$y=3$。

      所以 bias 的作用可以理解成：

      > 不只允许模型“旋转/拉伸”向量，还允许模型把结果整体往某个方向推一点。
      >

      在 Transformer 里，常见的是：

      $$
      Q = XW_q + b_q
      $$

      $$
      K = XW_k + b_k
      $$

      $$
      V = XW_v + b_v
      $$

      也就是每个投影层都可以有自己的 bias。

      不过有些模型为了简化或者稳定训练，会不用 bias，比如：

      ```
      Linear(d_model, d_model, bias=False)
      ```

      所以 bias 不是注意力机制必需的，但经常会出现。
   2. **$W_o$** **是什么？**

      你说的 **W0** 大概率其实是：

      $$
      W_o
      $$

      这个 $o$ 是 output 的 o，不是数字 0。

      它叫 ​**输出投影矩阵**，也就是 Multi-Head Attention 里面最后那个线性层。
   3. **为什么需要** **$W_o$**​ **？**

      假设有 8 个 head。

      每个 head 输出 64 维：

      $$
      head_1, head_2, ..., head_8
      $$

      每个都是：

      $$
      seq\_len \times 64
      $$

      拼起来之后：

      $$
      \mathrm{Concat}(head_1,\ldots,head_8)
      $$

      形状是：

      $$
      seq\_len \times 512
      $$

      因为：

      $$
      8 \times 64 = 512
      $$

      但是这 512 维只是简单把 8 个 head 的结果拼在一起。

      这时候问题是：

      > 8 个 head 各看各的，最后怎么融合成一个统一的新 token 表示？
      >

      答案就是靠：

      $$
      W_o
      $$

      它负责把拼起来的多头结果重新混合一次。
   4. **$W_o$** **的形状是什么？**

      假设：

      $$
      d_{model}=512
      $$

      8 个 head，每个 head：

      $$
      d_k=64
      $$

      拼接后仍然是：

      $$
      512
      $$

      所以：

      $$
      W_o \in \mathbb{R}^{512 \times 512}
      $$

      最终：

      $$
      Z = \mathrm{Concat}(head_1,\ldots,head_8)W_o
      $$

      形状：

      $$
      (seq\_len \times 512)(512 \times 512)
      =
      seq\_len \times 512
      $$

      所以输出维度还是 512，方便送进下一层 Transformer。
   5. **生动理解**

      8 个 head 像 8 个专家：

      ```
      head1：看语法关系
      head2：看主谓宾
      head3：看前后指代
      head4：看情绪
      head5：看位置
      ...
      ```

      每个专家都给出一份 64 维意见。

      然后把 8 份意见拼起来：

      ```
      [专家1意见 | 专家2意见 | 专家3意见 | ... | 专家8意见]
      ```

      但是这只是“堆在一起”，还没有真正整合。

      所以 $W_o$ 就像一个总编辑：

      > 把 8 个专家的意见重新整理、加权、融合，变成一个统一的 512 维结果。
      >
   6. **和** **$W_q, W_k, W_v$** **的区别**

      $$
      W_q
      $$

      负责生成 Query：

      > 我想找什么？
      >

      $$
      W_k
      $$

      负责生成 Key：

      > 我有什么标签？
      >

      $$
      W_v
      $$

      负责生成 Value：

      > 我能提供什么内容？
      >

      $$
      W_o
      $$

      负责输出融合：

      > 多个 head 的结果怎么重新组合成最终输出？
      >

      所以它们的分工是：

      ```
      Wq / Wk：决定注意力分数
      Wv：提供被提取的信息
      Wo：融合所有 head 的输出
      bias：给线性变换结果加一个可学习的平移量
      ```
3. Embedding 是一张可训练的查找表：一开始表的向量是随机的，tokenizer 做的是文字 → 固定 token ID，Embedding 做的是token ID → 训练出来的向量，Transformer 再做基础向量 → 根据当前上下文不断加工。**前向传播时它确实就是查表，** 但“查表”不代表这张表不能训练，训练时表里的向量会被反向传播修改；推理时表固定，只负责给每个 token 提供初始向量，后续 Transformer 再根据上下文把它加工成不同的表示

   1. **Embedding 矩阵** **$E$** **用在开头，把离散的 token ID 变成模型能计算的向量；**​**$W_{\text{vocab}}$** **用在结尾，把模型算出的隐藏向量变成每个 token 的分数。**

      输入 Embedding 矩阵 $E$ 是在 **token 刚进入 Transformer、还没做 Attention 之前**使用的。Tokenizer 先把文字变成 token ID，例如：

      $$
      \text{I}\rightarrow 17,\qquad
      \text{like}\rightarrow 326
      $$

      模型不能直接计算整数 ID，所以会用 ID 去 Embedding 矩阵中查找对应的一行。假设：

      $$
      E\in\mathbb{R}^{50000\times4096}
      $$

      那么词表有 50000 个 token，每个 token 对应一个 4096 维向量。`like` 的 ID 如果是 326，就取：

      $$
      E[326]
      $$

      得到 `like` 的初始向量。

      在传统 Transformer 的 Encoder 中，源句：

      ```
      我 喜欢 苹果
      ```

      会先变成 token ID，然后分别查 Embedding：

      $$
      e_{\text{我}},\quad e_{\text{喜欢}},\quad e_{\text{苹果}}
      $$

      再加上位置编码，形成 Encoder 第一层真正接收的输入：

      $$
      X=
      \begin{bmatrix}
      e_{\text{我}}+p_1\\
      e_{\text{喜欢}}+p_2\\
      e_{\text{苹果}}+p_3
      \end{bmatrix}
      $$

      然后才进入 Encoder 的 Self-Attention。

      在传统 Transformer 的 Decoder 中也一样。第一次预测时，Decoder 输入是 `<BOS>`​，模型先用 `<BOS>` 的 ID 查 Embedding：

      $$
      e_{\text{BOS}}
      $$

      加上位置编码后，再进入 Masked Self-Attention。生成 `I` 后，下一轮 Decoder 输入相当于：

      ```
      <BOS> I
      ```

      `I` 也要先通过 Embedding 矩阵变成向量，然后才能进入 Decoder。

      所以生成第二个 token 时，流程是：

      ```
      I 的 token ID
      → 查 Embedding 矩阵
      → 得到 I 的初始向量
      → 加位置编码
      → Masked Self-Attention
      → Cross-Attention
      → FFN
      → 最终隐藏向量
      → W_vocab
      → 预测 like
      ```

      GPT 中也是一样。用户输入的每个 token 都先查 Embedding 矩阵；模型生成一个新 token 后，这个 token 在下一轮又会被转换成 Embedding，作为新的输入继续预测。

      例如：

      ```
      输入：法国的首都是
      ```

      所有 token 先经过：

      $$
      \text{token ID}\rightarrow E[\text{token ID}]
      $$

      模型生成“巴黎”后，为了继续预测句号，“巴黎”这个 token 也要查一次 Embedding，变成向量后进入模型。

      训练时和推理时都会使用 Embedding。区别是，训练时通常一次输入一整段 token：

      $$
      [\text{BOS},I,like]
      $$

      一次性查出整个向量矩阵；推理时通常只需要为刚刚生成的新 token 查 Embedding，之前 token 的中间结果可以通过 KV Cache 保留。

      还要区分输入 Embedding 和输出 $W_{\text{vocab}}$：

      $$
      \text{token ID}
      \xrightarrow{E}
      \text{隐藏维度向量}
      $$

      这是模型的入口；

      $$
      \text{最终隐藏向量}
      \xrightarrow{W_{\text{vocab}}}
      \text{50000 个 token 的 logits}
      $$

      这是模型的出口。
   2. **前向传播时它确实就是查表，但“查表”不代表这张表不能训练，token ID 本身不能反向传播，但被查出来的那一行 Embedding 向量是模型参数，可以接收梯度并被更新。**

      假设 Embedding 矩阵是：

      $$
      E=
      \begin{bmatrix}
      e_{\text{I}}\\
      e_{\text{like}}\\
      e_{\text{apples}}\\
      e_{\text{am}}
      \end{bmatrix}
      $$

      输入 token 是 `like`，它的 ID 是 1，那么前向传播就是：

      $$
      x=E[1]=e_{\text{like}}
      $$

      确实就是直接取第二行。

      但这行向量会继续进入 Attention、FFN，最终影响预测结果和 Loss：

      $$
      e_{\text{like}}
      \rightarrow
      \text{Transformer}
      \rightarrow
      \text{预测概率}
      \rightarrow
      L
      $$

      因此反向传播时，可以计算：

      $$
      \frac{\partial L}{\partial e_{\text{like}}}
      $$

      也就是：

      > 如果把 `like` 的 Embedding 中某个数字稍微改变一点，最终 Loss 会怎样变化？
      >

      于是优化器就更新这行：

      $$
      e_{\text{like}}
      \leftarrow
      e_{\text{like}}
      -
      \eta
      \frac{\partial L}{\partial e_{\text{like}}}
      $$

      ---

      1. **一个极简例子**

         假设 `like` 当前的 Embedding 是：

         $$
         e_{\text{like}}=[0.2,-0.5,0.8]
         $$

         经过模型后，算出的梯度是：

         $$
         \frac{\partial L}{\partial e_{\text{like}}}
         =
         [0.1,-0.2,0.3]
         $$

         学习率假设为：

         $$
         \eta=0.01
         $$

         那么更新后：

         $$
         e_{\text{like}}'
         =
         [0.2,-0.5,0.8]
         -
         0.01[0.1,-0.2,0.3]
         $$

         得到：

         $$
         e_{\text{like}}'
         =
         [0.199,-0.498,0.797]
         $$

         所以下一次再查 `like` 时，查出来的就是更新后的向量。

         ---
      2. **token ID 不会被求导**

         假设：

         ```
         like → ID 326
         ```

         模型不会计算：

         $$
         \frac{\partial L}{\partial 326}
         $$

         也不会把 ID 从 326 改成 325.9。

         因为 token ID 只是一个索引，作用类似：

         ```
         embedding = E[326]
         ```

         真正训练的是：

         ```
         E 的第 326 行里的数字
         ```

         所以：

         - token ID：固定索引，不训练；
         - Embedding 矩阵：参数，会训练；
         - 本次查到的那几行：能够收到输入侧梯度。

         ---
      3. **为什么查表也可以看成矩阵乘法**

         假设词表只有 4 个 token，`like` 的 ID 是 1。

         可以把它表示成 one-hot 向量：

         $$
         o_{\text{like}}
         =
         [0,1,0,0]
         $$

         Embedding 矩阵：

         $$
         E\in\mathbb{R}^{4\times3}
         $$

         那么查表其实等价于：

         $$
         e_{\text{like}}
         =
         o_{\text{like}}E
         $$

         因为：

         $$
         [0,1,0,0]
         \begin{bmatrix}
         e_I\\
         e_{\text{like}}\\
         e_{\text{apples}}\\
         e_{\text{am}}
         \end{bmatrix}
         =
         e_{\text{like}}
         $$

         也就是说，查表可以理解成：

         > 用 one-hot 向量选中 Embedding 矩阵的一行。
         >

         反向传播时：

         $$
         \frac{\partial L}{\partial E}
         $$

         只有被选中那一行会收到输入侧梯度，其他没有被用到的行梯度通常为 0。

         ---
      4. **一句话中有多个 token 呢**

         例如输入：

         ```
         I like apples
         ```

         分别查出：

         $$
         e_I,\quad e_{\text{like}},\quad e_{\text{apples}}
         $$

         形成矩阵：

         $$
         X=
         \begin{bmatrix}
         e_I\\
         e_{\text{like}}\\
         e_{\text{apples}}
         \end{bmatrix}
         $$

         这些行进入 Transformer，最终 Loss 反向传回来。

         因此这次训练中：

         - `I` 对应的行收到梯度；
         - `like` 对应的行收到梯度；
         - `apples` 对应的行收到梯度；
         - 没出现在输入中的 token，输入 Embedding 一侧通常没有梯度。

         大量语料训练后，每个 token 会在不同句子中反复出现，于是它对应的 Embedding 行被不断更新。

         ---
      5. **为什么词义相近的 token 最后会变得相似**

         例如：

         ```
         cat
         dog
         rabbit
         ```

         它们经常出现在相似上下文：

         ```
         The cat is sleeping.
         The dog is sleeping.
         The rabbit is sleeping.
         ```

         为了降低预测 Loss，模型可能需要让它们在某些方向上产生相似的表示。反向传播会一次次调整这些 token 对应的 Embedding 行，最终让它们在向量空间中形成某些相似结构。

         不是有人提前规定：

         ```
         cat 和 dog 要靠近
         ```

         而是它们在训练数据中承担相似作用，收到相似的梯度更新。

         ---
      6. **使用权重共享时还有一个细节**

         如果：

         $$
         W_{\text{vocab}}=E^T
         $$

         那么同一个 Embedding 矩阵同时用于：

         1. 输入时查表；
         2. 输出时给所有 token 打分。

         此时 Embedding 会从两条路径收到梯度。

         输入路径：

         $$
         \text{token ID}\rightarrow E[\text{ID}]
         \rightarrow\text{Transformer}\rightarrow L
         $$

         输出路径：

         $$
         hE^T\rightarrow\text{logits}\rightarrow L
         $$

         在输入查表路径中，通常只有被查到的行收到梯度。

         但在输出 Softmax 路径中，由于模型会给整个词表的 token 打分，理论上很多甚至所有 token 对应的输出权重都会收到梯度，只是大小不同。

         所以最核心的结论是：

         > **查表只是前向传播中选择参数的方式。被选中的表项仍然参与后续计算，因此 Loss 可以沿计算图反向传到这些表项，并修改其中的数值。**
         >
   3. **表里的向量不是预先正确写好的。模型刚开始训练时，这些数字通常接近随机值。某个 token 被查出来后，它会参与后面的 Attention、FFN 和最终预测。**

      对，​**那个“数据库”里的向量在训练期间真的会变**。

      你可以把 Embedding 矩阵理解成一张可学习的表：

      ```
      token ID 0 → [0.12, -0.33, 0.08, ...]
      token ID 1 → [0.41,  0.05, -0.27, ...]
      token ID 2 → [-0.09, 0.18, 0.62, ...]
      ```

      前向传播时确实只是查表：

      ```
      “苹果”的 token ID
      → 找到 Embedding 表对应那一行
      → 取出它的向量
      ```

      但表里的向量不是预先正确写好的。模型刚开始训练时，这些数字通常接近随机值。某个 token 被查出来后，它会参与后面的 Attention、FFN 和最终预测。如果预测错了，Loss 会沿着计算过程反向传回来，告诉模型：

      > “刚才查出来的这个向量，如果稍微往这个方向改一点，预测会更准确。”
      >

      于是对应那一行就会被更新。

      例如原本：

      $$
      e_{\text{苹果}}=[0.2,-0.5,0.8]
      $$

      反向传播后可能变成：

      $$
      e_{\text{苹果}}=[0.201,-0.497,0.794]
      $$

      下一次再遇到“苹果”，查到的就是这个更新后的向量。

      所以它像数据库，但更准确地说是：

      > **一张会被训练修改的参数表。**
      >

      普通数据库里的记录通常是人为写入、查询时不变；Embedding 表里的记录则是模型参数，会被梯度下降不断改写。

      还有一个特别重要的区别：

      1. **训练期间**

         Embedding 向量不断变化：

         ```
         随机向量
         → 训练一次，改一点
         → 再训练，继续改
         → 逐渐形成有用的语言表示
         ```
      2. **模型训练结束、正常推理时**

         Embedding 通常固定不变：

         ```
         用户输入“苹果”
         → 每次查到同一行训练好的基础向量
         ```

         正常聊天时，模型不会因为你说了一次“苹果”，就永久修改“苹果”的 Embedding。只有继续训练或微调模型时，参数才会更新。

         不过还要区分两个东西。

          **“苹果”的基础 Embedding** 是查表得到的固定起点；它进入 Transformer 后，会根据当前句子变成不同的上下文隐藏状态。

         例如：

         ```
         我吃了一个苹果。
         苹果发布了新手机。
         ```

         两句话中，“苹果”一开始可能查到相同的基础 Embedding，但经过 Self-Attention 后：

         - 第一处会融合“吃了一个”，偏向水果含义；
         - 第二处会融合“发布、新手机”，偏向公司含义。

         所以：

         $$
         \text{基础 Embedding 相同}
         $$

         但：

         $$
         \text{经过 Transformer 后的上下文向量不同}
         $$

         最准确的记法是：

         > **Embedding 是一张可训练的查找表：训练时表里的向量会被反向传播修改；推理时表固定，只负责给每个 token 提供初始向量，后续 Transformer 再根据上下文把它加工成不同的表示。**
         >
   4. 感慨一下：我去，那这个数据库很牛啊，我还以为是人为规定好哪个字对应哪个向量的，我还以为这么牛编码这么多字

      对，就是这个地方最容易让人第一次知道时“我去”一下。

      人类真正提前规定好的，通常只有：

      > 这个 token 叫“苹果”，它的 ID 是 3267。
      >

      但并没有人手工规定：

      > “苹果”应该对应 $[0.21,-0.37,0.84,\dots]$ 这个 4096 维向量。
      >

      这些向量一开始往往就是随机数字。然后模型看了海量文本，不断做“预测下一个 token”，预测错了就反向传播，一点点修改“苹果”“香蕉”“手机”“公司”这些 token 对应的向量。

      训练久了以后，整个 Embedding 表里居然会自己形成某种结构。比如语义相近、用法相似的 token，在一些方向上往往会更接近；“苹果”既经常出现在“水果、吃、甜”附近，也经常出现在“手机、发布、公司”附近，所以它的基础向量会同时携带这些统计关系，真正进入句子后再由 Attention 根据上下文判断具体含义。

      所以 tokenizer 做的是：

      ```
      文字 → 固定 token ID
      ```

      Embedding 做的是：

      ```
      token ID → 训练出来的向量
      ```

      Transformer 再做：

      ```
      基础向量 → 根据当前上下文不断加工
      ```

      最神奇的是，没人告诉模型“猫和狗都是动物”“巴黎和北京都是城市”。模型只是被要求不停预测下一个 token，结果为了把 Loss 降下来，它不得不自己在向量空间里整理出语义、语法、实体关系，甚至某些抽象概念。

      所以你之前把它想成“人类给几万个字精心编码”，其实真实情况反而更离谱：

      > 人类只搭了学习规则，向量里的意义大部分是模型自己从数据中长出来的。
      >
4. **传统 Transformer 把“输入文本”和“输出文本”分开处理：Encoder 负责读懂输入，Decoder 负责生成输出。传统 Transformer 的 Decoder 不是只有 Encoder 输出这一个输入，它同时接收两类输入：Encoder 输出的上下文矩阵** **$H$**​ **：表示源句信息；Decoder 已经看到的目标端 token：决定目前生成到哪里。GPT 则把输入和输出拼成同一条文本序列，从左到右不断预测下一个 token，因此不再需要单独的 Encoder**

   1. **传统 Transformer 的 Encoder-Decoder**

      原始 Transformer 最初主要是为**机器翻译**设计的。

      例如：

      ```
      输入：我喜欢苹果
      输出：I like apples
      ```

      它天然分成两部分：

      ```
      中文原文 → Encoder → 语义表示
                           ↓
      英文前文 → Decoder → 下一个英文 token
      ```

      整体结构可以理解为：

      ```
      输入序列 x₁, x₂, x₃...
              ↓
      ┌─────────────────────┐
      │       Encoder       │
      │                     │
      │ 双向 Self-Attention │
      │ FFN                  │
      └─────────────────────┘
              ↓
      编码后的语义信息 H
              ↓
      ┌──────────────────────────┐
      │         Decoder          │
      │                          │
      │ 1. Masked Self-Attention │
      │ 2. Cross-Attention       │ ← 查看 Encoder 输出 H
      │ 3. FFN                   │
      └──────────────────────────┘
              ↓
      输出序列 y₁, y₂, y₃...
      ```

      ---
   2. **Encoder 到底做什么**

      假设输入是：

      ```
      我 喜欢 吃 苹果
      ```

      Encoder 会把每个 token 转成向量，然后经过多层计算。

      ## 1. Encoder 的 Self-Attention

      Encoder 中的每个 token，可以同时查看输入中的​**所有 token**。

      例如“苹果”可以关注：

      ```
      我
      喜欢
      吃
      苹果
      ```

      “我”也可以反过来关注后面的“苹果”。

      所以 Encoder 的注意力是：

      ```
      双向注意力
      ```

      大致可以表示为：

      |当前 token|能看到什么|
      | ------------| --------------------|
      |我|我、喜欢、吃、苹果|
      |喜欢|我、喜欢、吃、苹果|
      |吃|我、喜欢、吃、苹果|
      |苹果|我、喜欢、吃、苹果|

      经过多层 Encoder 后，每个 token 的向量都会融合整句话的信息。

      最终得到：

      $$
      H=\operatorname{Encoder}(x_1,x_2,\dots,x_n)
      $$

      这里的 $H$ 是一个矩阵，包含每个输入 token 的上下文表示。

      可以把它想象成：

      ```
      原句：我 喜欢 吃 苹果

      Encoder 输出：
      “我”的上下文向量
      “喜欢”的上下文向量
      “吃”的上下文向量
      “苹果”的上下文向量
      ```

      这些向量不是最终答案，而是供 Decoder 使用的“语义资料库”。

      ---
   3. 3. **传统 Transformer 的 Decoder 不是只有 Encoder 输出这一个输入。它同时接收两类输入。**

         1. **Encoder 输出的上下文矩阵** **$H$**：表示源句信息；
         2. **Decoder 已经看到的目标端 token**：决定目前生成到哪里。

         ```
         已经生成的目标文本 → Decoder 的 Masked Self-Attention
         Encoder 输出 H     → Decoder 的 Cross-Attention
         ```

         1. 第一个输入通常是 `<BOS>`​ 或功能等价的启动 token，并非必须字面叫 `<BOS>`
         2. 生成第二个 token 时，Decoder 中仍包括 `<BOS>`​；只是最终读取的是 `I`​ 位置的输出。`I`​ 位置通过 Masked Self-Attention 已经融合了 `<BOS>`​，然后由 `I` 位置状态作为 Query 查询 Encoder 输出
         3. 也就是经过masked self attention后，I就包含了bos的信息了，所以Wq矩阵乘 `I` 位置经过 Masked Self-Attention 后的隐藏状态得到的Q矩阵，Encoder 输出矩阵则分别乘 $W_K^{cross}$ 和 $W_V^{cross}$ 得到 Key 和 Value，再进行 Cross-Attention

            完整链路是：

            $$
            \text{原始 }I\text{ 向量}
            \rightarrow
            \text{Masked Self-Attention}
            \rightarrow
            \text{融合了 BOS 和 I 的状态}
            \rightarrow
            \text{Cross-Attention}
            $$

            ---

            1. **Decoder 当前输入**

               预测第二个 token 时，Decoder 输入是：

               $$
               [\text{BOS}, I]
               $$

               初始向量分别是：

               $$
               x_{\text{BOS}}=e_{\text{BOS}}+p_1
               $$

               $$
               x_I=e_I+p_2
               $$

               其中 $e$ 是 token embedding，$p$ 是位置编码。

               ---
            2. **Masked Self-Attention**

               在 `I` 位置：

               - Query 来自 `I`；
               - Key、Value 来自 `BOS`​ 和 `I`；
               - 因为有因果 Mask，不能看到未来的 `like`。

               具体是：

               $$
               q_I^{self}=x_IW_Q^{self}
               $$

               $$
               K^{self}=
               \begin{bmatrix}
               x_{\text{BOS}}W_K^{self}\\
               x_IW_K^{self}
               \end{bmatrix}
               $$

               $$
               V^{self}=
               \begin{bmatrix}
               x_{\text{BOS}}W_V^{self}\\
               x_IW_V^{self}
               \end{bmatrix}
               $$

               于是 `I` 位置的注意力输出是：

               $$
               a_I
               =
               \operatorname{softmax}
               \left(
               \frac{q_I^{self}(K^{self})^T}{\sqrt{d_k}}
               \right)V^{self}
               $$

               假设注意力权重是：

               $$
               [0.2,\ 0.8]
               $$

               那么：

               $$
               a_I
               =
               0.2v_{\text{BOS}}+0.8v_I
               $$

               所以此时 `I` 位置已经融合了：

               $$
               \text{BOS 信息}+\text{I 信息}
               $$

               不过实际还会有残差连接和 LayerNorm，例如：

               $$
               h_I^{self}
               =
               \operatorname{LayerNorm}(x_I+a_I)
               $$

               所以更准确地说：

               > $h_I^{self}$ 是一个表示目标端前缀 `<BOS> I` 的上下文向量。
               >

               ---
            3. **进入 Cross-Attention**

               然后才是你说的这一步。

               Cross-Attention 的 Query 来自：

               $$
               h_I^{self}
               $$

               而不是原始 $x_I$。

               所以：

               $$
               q_I^{cross}
               =
               h_I^{self}W_Q^{cross}
               $$

               Encoder 已经得到输出矩阵：

               $$
               H=
               \begin{bmatrix}
               h_{\text{我}}\\
               h_{\text{喜欢}}\\
               h_{\text{苹果}}
               \end{bmatrix}
               $$

               Encoder 输出经过 Cross-Attention 自己的投影矩阵：

               $$
               K^{cross}=HW_K^{cross}
               $$

               $$
               V^{cross}=HW_V^{cross}
               $$

               然后计算：

               $$
               c_I
               =
               \operatorname{softmax}
               \left(
               \frac{
               q_I^{cross}(K^{cross})^T
               }{
               \sqrt{d_k}
               }
               \right)V^{cross}
               $$

               所以可以画成：

               ```
               <BOS> ─┐
                      ├→ Masked Self-Attention
               I ─────┘
                         ↓
               I 位置的新状态 hI
               已经包含 <BOS> 和 I 的信息
                         ↓
               乘 WQ_cross 得到 Query
                         ↓
               查询 Encoder 输出的 K、V
                         ↓
               得到融合源句信息的状态
               ```

               ---
            4. **一个很重要的区分**

               Self-Attention 中：

               $$
               Q,K,V
               $$

               都来自 Decoder：

               ```
               <BOS>、I
               ```

               Cross-Attention 中：

               $$
               Q=\text{Decoder 的 I 位置状态}
               $$

               $$
               K,V=\text{Encoder 输出}
               $$

               也就是：

               ```
               Query：
               “我已经生成了 <BOS> I，现在需要什么信息？”

               Key、Value：
               Encoder 对“我 喜欢 苹果”的上下文表示
               ```
         4. Decoder 在当前位置最终得到一个隐藏向量 $h$，比如维度是 4096。这个向量表示“结合前文和当前语境，下一个 token 应该具有什么特征”。要给 50000 个 token 打分，模型会准备一个输出矩阵 $W_{\text{vocab}}$，形状通常是 $[4096,50000]$。这个矩阵的每一列对应一个 token 的“评分向量”。于是 $h$ 分别和这 50000 列做点积，就得到 50000 个 logits。一次矩阵乘法 $hW_{\text{vocab}}$，本质上就是同时完成 50000 次点积。这些 logits 还不是概率，它们只是原始分数。模型再对 50000 个 logits 做 Softmax，把它们转换成总和为 1 的概率分布。之后可以直接选概率最大的 token，也可以按概率采样。比如 `like`​ 的 logit 最高，Softmax 后概率也最高，那么模型就更可能输出 `like`。词表里的 token 和 ID 通常不是反向传播训练出来的；但输入 Embedding 和 $W_{\text{vocab}}$ 中的数值都是训练出来的。若使用权重共享，$W_{\text{vocab}}$ 就是训练后的 Embedding 矩阵转置，而不是另一套单独参数。

            1. **假设隐藏维度只有 3**

               Decoder 在 `I` 位置最终得到隐藏向量：

               $$
               h=[2,\ 1,\ -1]
               $$

               它表示：

               ```
               结合源句“我喜欢苹果”
               以及当前已生成“I”
               下一个 token 应该是什么
               ```

               真实模型里 $h$ 可能有 512、4096 等维度，这里只用 3 维。

               ---
            2. **假设词表只有 4 个 token**

               词表是：

               ```
               token 0：I
               token 1：like
               token 2：apples
               token 3：am
               ```

               现在模型需要给这 4 个 token 分别打分。

               于是给每个 token 准备一个长度为 3 的“输出评分向量”：

               $$
               w_I=
               \begin{bmatrix}
               0\\
               1\\
               1
               \end{bmatrix}
               $$

               $$
               w_{\text{like}}=
               \begin{bmatrix}
               2\\
               1\\
               0
               \end{bmatrix}
               $$

               $$
               w_{\text{apples}}=
               \begin{bmatrix}
               1\\
               -1\\
               2
               \end{bmatrix}
               $$

               $$
               w_{\text{am}}=
               \begin{bmatrix}
               -1\\
               2\\
               1
               \end{bmatrix}
               $$

               这 4 个向量拼在一起，就是 $W_{\text{vocab}}$：

               $$
               W_{\text{vocab}}
               =
               \begin{bmatrix}
               0 & 2 & 1 & -1\\
               1 & 1 & -1 & 2\\
               1 & 0 & 2 & 1
               \end{bmatrix}
               $$

               它的形状是：

               $$
               3\times4
               $$

               因为：

               - 隐藏维度是 3；
               - 词表大小是 4。

               每一列对应一个 token：

               $$
               W_{\text{vocab}}
               =
               \begin{bmatrix}
               | & | & | & |\\
               w_I & w_{\text{like}} & w_{\text{apples}} & w_{\text{am}}\\
               | & | & | & |
               \end{bmatrix}
               $$

               ---
            3. **隐藏向量乘** **$W_{\text{vocab}}$**  

               现在计算：

               $$
               \text{logits}
               =
               hW_{\text{vocab}}
               $$

               也就是：

               $$
               [2,\ 1,\ -1]
               \begin{bmatrix}
               0 & 2 & 1 & -1\\
               1 & 1 & -1 & 2\\
               1 & 0 & 2 & 1
               \end{bmatrix}
               $$

               结果会是一个长度为 4 的向量：

               $$
               [z_I,\ z_{\text{like}},\ z_{\text{apples}},\ z_{\text{am}}]
               $$

               这其实等价于分别算 4 次点积。

               ---

               ## 给 `I` 打分

               取矩阵第一列：

               $$
               w_I=[0,1,1]
               $$

               计算：

               $$
               z_I
               =
               h\cdot w_I
               $$

               $$
               =
               2\times0+1\times1+(-1)\times1
               $$

               $$
               =0
               $$

               所以 `I` 的分数是：

               $$
               0
               $$

               ---

               ## 给 `like` 打分

               取第二列：

               $$
               w_{\text{like}}=[2,1,0]
               $$

               $$
               z_{\text{like}}
               =
               2\times2+1\times1+(-1)\times0
               $$

               $$
               =5
               $$

               所以 `like` 的分数是：

               $$
               5
               $$

               ---

               ## 给 `apples` 打分

               $$
               w_{\text{apples}}=[1,-1,2]
               $$

               $$
               z_{\text{apples}}
               =
               2\times1+1\times(-1)+(-1)\times2
               $$

               $$
               =-1
               $$

               ---

               ## 给 `am` 打分

               $$
               w_{\text{am}}=[-1,2,1]
               $$

               $$
               z_{\text{am}}
               =
               2\times(-1)+1\times2+(-1)\times1
               $$

               $$
               =-1
               $$

               ---

               所以最终：

               $$
               \text{logits}
               =
               [0,\ 5,\ -1,\ -1]
               $$

               对应：

               |token|logit|
               | -------| -------|
               |`I`|0|
               |`like`|5|
               |`apples`|-1|
               |`am`|-1|

               于是 `like` 的分数最高。

               ---
            4. **为什么一次矩阵乘法能同时算完**

               因为矩阵乘法本身就是：

               > 左边这个向量，分别和右边矩阵的每一列做点积。
               >

               也就是：

               $$
               hW_{\text{vocab}}
               =
               [
               h\cdot w_I,\,
               h\cdot w_{\text{like}},\,
               h\cdot w_{\text{apples}},\,
               h\cdot w_{\text{am}}
               ]
               $$

               所以真实模型里，假设：

               $$
               h\in\mathbb{R}^{4096}
               $$

               词表有 50000 个 token，那么：

               $$
               W_{\text{vocab}}
               \in
               \mathbb{R}^{4096\times50000}
               $$

               这个矩阵里有 50000 列：

               ```
               第1列：token 1 的评分向量
               第2列：token 2 的评分向量
               第3列：token 3 的评分向量
               ……
               第50000列：token 50000 的评分向量
               ```

               然后：

               $$
               [1\times4096]
               \times
               [4096\times50000]
               =
               [1\times50000]
               $$

               结果的第 $j$ 个数字就是：

               $$
               z_j=h\cdot w_j
               $$

               也就是第 $j$ 个 token 的 logit。

               ---
            5. **这些“评分向量”是怎么来的：** 词表里的 token 和 ID 通常不是反向传播训练出来的；但输入 Embedding 和 $W_{\text{vocab}}$ 中的数值都是训练出来的。若使用权重共享，$W_{\text{vocab}}$ 就是训练后的 Embedding 矩阵转置，而不是另一套单独参数。

               它们不是人工设计的，而是训练出来的。

               一开始：

               $$
               W_{\text{vocab}}
               $$

               通常也是随机初始化。

               例如训练样本中，正确下一个 token 是：

               ```
               like
               ```

               但模型得到的 logits 可能是：

               ```
               I：3.0
               like：1.0
               apples：2.0
               am：4.0
               ```

               Softmax 后 `like` 概率很低，因此 Loss 很大。

               反向传播就会调整：

               - 隐藏向量 $h$ 是怎么生成的；
               - $w_{\text{like}}$；
               - 其他 token 的评分向量；
               - Decoder 中间所有参数。

               目标是让：

               $$
               h\cdot w_{\text{like}}
               $$

               变大，让不合适 token 的点积变小。

               训练无数次以后，模型逐渐学会：当隐藏状态表达“已经生成 I，源句接下来对应喜欢”时，它和 `like` 的评分向量点积应该很大。

               **第一，词表本身。**   
               词表只是固定的 token 和 ID 对应关系，例如：

               $$
               \text{like}\rightarrow 1234
               $$

               这个对应关系通常由 tokenizer 提前确定，大模型训练时一般不通过反向传播改变。

               **第二，输入 Embedding 矩阵** **$E$**​ **。**   
               它的形状通常是：

               $$
               E\in\mathbb{R}^{V\times d}
               $$

               一行对应一个 token 的输入向量。这里面的数字是模型参数，会通过反向传播训练。

               **第三，输出矩阵** **$W_{\text{vocab}}$**​ **。**   
               它的形状通常是：

               $$
               W_{\text{vocab}}\in\mathbb{R}^{d\times V}
               $$

               它负责把 Decoder 最终隐藏向量 $h$ 变成整个词表的 logits：

               $$
               \text{logits}=hW_{\text{vocab}}+b
               $$

               $W_{\text{vocab}}$ 里面的数字也会通过反向传播训练。

               ---
            6. **可以把每一列想成一个“检测器”**

               例如极度简化地想象，隐藏向量的三个维度表示：

               ```
               第1维：是否需要动词
               第2维：是否需要表达喜欢
               第3维：是否需要名词
               ```

               当前隐藏状态：

               $$
               h=[2,1,-1]
               $$

               可能表示：

               ```
               非常需要动词
               有一些“喜欢”的语义
               暂时不需要名词
               ```

               而 `like` 的评分向量：

               $$
               w_{\text{like}}=[2,1,0]
               $$

               意味着：

               ```
               如果很需要动词，给高分
               如果有“喜欢”的语义，也给高分
               对名词需求不敏感
               ```

               于是点积很高。

               当然，真实模型的 4096 个维度没有这么清晰地一维对应一个概念，它们通常是分布式表示。但这个比喻能帮助你理解：

               > $W_{\text{vocab}}$ 的每一列，都在检测当前隐藏状态是否适合生成对应 token。
               >

               ---
            7. **Softmax 后发生什么**

               现在 logits 是：

               $$
               [0,\ 5,\ -1,\ -1]
               $$

               Softmax：

               $$
               P_i=\frac{e^{z_i}}{\sum_j e^{z_j}}
               $$

               大概得到：

               |token|概率|
               | -------| --------|
               |`I`|0.0066|
               |`like`|0.988|
               |`apples`|0.0024|
               |`am`|0.0024|

               然后：

               - 贪心解码：选概率最大的 `like`；
               - 采样：按这些概率随机抽，几乎也会抽到 `like`。

               ---
            8. **你可以把整个过程理解成这样**

               假设有 50000 个候选 token：

               ```
               I
               like
               apples
               am
               you
               the
               ……
               ```

               每个 token 都有一套评分参数：

               $$
               w_1,w_2,\dots,w_{50000}
               $$

               当前 Decoder 隐藏向量是 $h$。

               模型做：

               $$
               \begin{aligned}
               z_1 &= h\cdot w_1\\
               z_2 &= h\cdot w_2\\
               z_3 &= h\cdot w_3\\
               &\vdots\\
               z_{50000} &= h\cdot w_{50000}
               \end{aligned}
               $$

               只是 GPU 不会傻乎乎一个个循环算，而是合并成一次矩阵乘法：

               $$
               \boxed{
               \text{logits}
               =
               hW_{\text{vocab}}
               }
               $$

               所以：

               > $W_{\text{vocab}}$ 并不是“词库本身”，而是一张巨大的评分表：每一列负责给一个 token 打分。
               >

               最简洁的维度关系是：

               $$
               \boxed{
               \underbrace{[1\times4096]}_{\text{当前语境向量}}
               \times
               \underbrace{[4096\times50000]}_{\text{50000套评分规则}}
               =
               \underbrace{[1\times50000]}_{\text{每个token一个分数}}
               }
               $$

         ---
   4. **传统 Encoder-Decoder 是怎么训练的**

      假设训练数据是：

      ```
      中文输入：我喜欢苹果
      英文答案：I like apples
      ```

      首先，Encoder 一次性读取：

      ```
      我 喜欢 苹果
      ```

      得到编码结果 $H$。

      Decoder 的训练输入通常会向右错开一位：

      ```
      Decoder 输入：<BOS> I like
      正确答案：     I    like apples
      ```

      对应关系是：

      |Decoder 看到|应该预测|
      | --------------| ----------|
      |`&lt;BOS&gt;`|I|
      |`&lt;BOS&gt; I`|like|
      |`&lt;BOS&gt; I like`|apples|

      概率可以写成：

      $$
      P(y_1,y_2,\dots,y_m\mid x)
      =
      \prod_{t=1}^{m}
      P(y_t\mid y_{<t},H)
      $$

      其中：

      - $x$：中文输入；
      - $H$：Encoder 对中文的编码；
      - $y_{<t}$：已经出现的英文 token；
      - $y_t$：当前应该预测的英文 token。

      训练时会比较模型预测概率和正确 token，计算交叉熵 Loss：

      $$
      L=-\sum_t\log P(y_t\mid y_{<t},H)
      $$

      然后反向传播，更新 Encoder 和 Decoder 的参数。

      ---
   5. **GPT 的“纯 Decoder”是什么**

      GPT 没有单独的 Encoder。

      它的结构大致是：

      ```
      输入 token
          ↓
      Masked Self-Attention
          ↓
      FFN
          ↓
      Masked Self-Attention
          ↓
      FFN
          ↓
      ……
          ↓
      预测下一个 token
      ```

      严格来说，GPT 的每层不是完整的“传统 Transformer Decoder 层”。

      因为传统 Decoder 层有：

      ```
      Masked Self-Attention
      Cross-Attention
      FFN
      ```

      GPT 去掉了 Cross-Attention，只留下：

      ```
      Causal Self-Attention
      FFN
      ```

      所以“Decoder-only”更准确的意思是：

      > GPT 使用了类似 Transformer Decoder 的因果注意力结构，但没有 Encoder，也没有与 Encoder 连接的 Cross-Attention。
      >

      ---
   6. **GPT 为什么可以省掉 Encoder**

      关键在于：**GPT 不再把输入和输出看成两个独立序列，而是把它们拼成一条连续文本。**

      例如问答：

      ```
      问题：法国的首都是哪里？
      回答：巴黎。
      ```

      GPT 可以把它处理成一整条序列：

      ```
      问题：法国的首都是哪里？回答：巴黎。
      ```

      然后统一做“预测下一个 token”。

      也就是：

      ```
      看到：问题
      预测：：

      看到：问题：
      预测：法

      ……

      看到：问题：法国的首都是哪里？回答：
      预测：巴黎
      ```

      GPT 不需要先做：

      ```
      问题 → Encoder → 语义信息
      ```

      再做：

      ```
      Decoder 根据语义信息生成答案
      ```

      它直接做：

      ```
      问题 token + 已生成答案 token
                   ↓
               预测下一个 token
      ```

      当 GPT 开始生成答案时，问题已经全部位于答案 token 的左边。

      因此答案 token 可以通过因果 Self-Attention 直接查看整个问题。

      例如：

      ```
      问题：法国的首都是哪里？回答：巴
                                    ↑
      ```

      预测这个位置时，它可以注意到左边的：

      ```
      法国
      首都
      哪里
      回答
      ```

      所以不需要 Encoder 单独把问题变成一个 $H$。

      ---
   7. **GPT 的训练过程**

      假设训练文本是：

      ```
      我 喜欢 吃 苹果
      ```

      加入起始符后，可以构造：

      ```
      模型输入：<BOS> 我 喜欢 吃
      正确答案：我    喜欢 吃 苹果
      ```

      也就是每个位置预测下一个 token：

      |当前看到的内容|预测目标|
      | ----------------| ----------|
      |`&lt;BOS&gt;`|我|
      |`&lt;BOS&gt; 我`|喜欢|
      |`&lt;BOS&gt; 我 喜欢`|吃|
      |`&lt;BOS&gt; 我 喜欢 吃`|苹果|

      概率写成：

      $$
      P(x_1,x_2,\dots,x_n)
      =
      \prod_{t=1}^{n}
      P(x_t\mid x_1,x_2,\dots,x_{t-1})
      $$

      Loss 是：

      $$
      L=-\sum_{t=1}^{n}\log P(x_t\mid x_{<t})
      $$

      这就是 GPT 最核心的训练目标：

      > 根据左边所有 token，预测下一个 token。
      >

      ---

      ## 训练时是不是一个 token 一个 token 地算？

      不是。

      虽然逻辑上是：

      ```
      前文 → 预测下一个 token
      ```

      但训练时，整句话的正确答案已经知道，所以可以把所有位置​**并行计算**。

      例如输入：

      ```
      <BOS> 我 喜欢 吃
      ```

      一次前向传播，同时得到：

      ```
      位置1预测“我”
      位置2预测“喜欢”
      位置3预测“吃”
      位置4预测“苹果”
      ```

      之所以不会偷看未来，是因为注意力中加入了 Causal Mask：

      ```
                能看的 Key 位置
                1   2   3   4
      Query 1   ✓   ×   ×   ×
      Query 2   ✓   ✓   ×   ×
      Query 3   ✓   ✓   ✓   ×
      Query 4   ✓   ✓   ✓   ✓
      ```

      注意力矩阵的右上角会被屏蔽。

      所以：

      - **训练时：多个位置并行预测；**
      - **信息上：每个位置只能看到左边。**

      这两件事并不冲突。

      ---
   8. **GPT 的推理过程**

      训练完成后，用户输入：

      ```
      法国的首都是
      ```

      GPT 首先计算：

      $$
      P(\text{下一个 token}\mid \text{法国的首都是})
      $$

      可能得到：

      ```
      巴黎：0.92
      北京：0.01
      伦敦：0.01
      ……
      ```

      选择“巴黎”后，拼到序列末尾：

      ```
      法国的首都是巴黎
      ```

      然后再次计算：

      $$
      P(\text{下一个 token}\mid \text{法国的首都是巴黎})
      $$

      可能生成句号：

      ```
      法国的首都是巴黎。
      ```

      继续重复：

      ```
      输入当前全部 token
              ↓
      预测下一个 token
              ↓
      把 token 添加到末尾
              ↓
      再次预测
      ```

      因此 GPT 推理是自回归的：

      $$
      x_1\rightarrow x_2\rightarrow x_3\rightarrow\cdots
      $$

      训练可以并行，生成却通常必须逐 token 进行，因为后一个 token 取决于模型刚刚生成的前一个 token。

      ---
   9. **KV Cache 在这里有什么用**

      如果没有 KV Cache，生成每个新 token 时，都要重新计算前面所有 token 的 K 和 V。

      例如已经生成：

      ```
      法国的首都是巴黎
      ```

      要预测下一个 token 时，前面“法国的首都是巴黎”的 K、V 实际上和上一轮一样。

      所以可以缓存起来：

      ```
      之前 token 的 K、V → KV Cache
      新 token → 只计算它自己的 Q、K、V
      ```

      然后新 token 的 Query 去查询：

      ```
      旧 token 的缓存 K/V
      +
      新 token 的 K/V
      ```

      这样不用每次都从头重算整段前文。

      但新 token 仍然要依次生成，所以 KV Cache 是​**减少重复计算**，不是让所有未来 token 一次性并行生成。

      ---
   10. **GPT 为什么不需要传统 Encoder 的双向注意力**

       Encoder 的优势是：输入中每个 token 都可以同时查看左右两侧。

       例如：

       ```
       小明把苹果放在桌子上，因为它很重。
       ```

       Encoder 在理解“它”时，可以综合前后的全部信息。

       GPT 的每个 token 只能看左边，但在真正开始生成答案时，用户的整个问题都已经位于左侧。

       比如：

       ```
       用户问题全部内容 ｜ 助手答案即将开始
       ```

       当 GPT 预测第一个答案 token 时，它已经能看到整个用户问题。

       所以对“根据一段前文继续生成”这个任务而言，单向注意力已经足够使用。

       不过这里要注意：

       > 不是说 Encoder 没用，也不是说单向注意力永远比双向注意力强，而是 GPT 把所有任务统一改写成了“根据前文生成后文”。
       >

       ---
   11. **指令微调时，GPT 又是怎么训练的**

       例如训练样本：

       ```
       用户：1+1等于多少？
       助手：2
       ```

       模型看到的仍然是一条序列：

       ```
       <用户> 1+1等于多少？ <助手> 2
       ```

       训练目标还是预测下一个 token：

       ```
       <用户> → 1
       <用户>1 → +
       ……
       <用户>1+1等于多少？<助手> → 2
       ```

       实际进行 SFT 时，经常只对助手回答部分计算主要 Loss：

       ```
       用户问题部分：作为上下文，不一定计算 Loss
       助手回答部分：计算 Loss
       ```

       可以表示为：

       ```
       用户：解释一下注意力机制。
       助手：注意力机制是……
             ↑ 从这里开始重点计算 Loss
       ```

       但底层仍然没有改变，还是：

       $$
       P(\text{回答}\mid\text{用户问题})
       $$

       通过“预测下一个 token”实现。

       ---
   12. **传统 Transformer 和 GPT 的本质对照**

       |项目|传统 Encoder-Decoder|GPT Decoder-only|
       | ------------------------| ----------------------| --------------------------------|
       |输入与输出|两条序列|拼成一条序列|
       |Encoder|有|没有|
       |Decoder|有|有类似 Decoder 的结构|
       |Encoder 注意力|双向 Self-Attention|不存在|
       |Decoder Self-Attention|因果注意力|因果注意力|
       |Cross-Attention|有|没有|
       |典型概率|$P(y\mid x)$|$P(x_t\mid x_{<t})$|
       |典型用途|翻译、摘要、序列转换|开放式文本生成、对话、代码生成|
       |输入处理|先编码，再解码|输入本身就是生成前缀|

       ---
   13. **用一个翻译例子直接对比**

       ## 传统 Encoder-Decoder

       输入：

       ```
       我 喜欢 苹果
       ```

       Encoder：

       ```
       读取完整中文句子
       ↓
       生成中文语义矩阵 H
       ```

       Decoder：

       ```
       <BOS> + H → I
       <BOS> I + H → like
       <BOS> I like + H → apples
       ```

       数学上：

       $$
       P(\text{I like apples}\mid\text{我喜欢苹果})
       $$

       ---

       ## GPT

       输入直接写成：

       ```
       把“我喜欢苹果”翻译成英文：I like apples
       ```

       训练时统一做：

       ```
       把 → “
       把“ → 我
       ……
       把“我喜欢苹果”翻译成英文： → I
       ……
       ```

       推理时用户给：

       ```
       把“我喜欢苹果”翻译成英文：
       ```

       GPT 把这段内容作为前缀，然后继续生成：

       ```
       I like apples.
       ```

       它没有显式区分：

       ```
       这是 Encoder 输入
       这是 Decoder 输出
       ```

       对于 GPT 来说，都是 token，只是前后位置不同。

       ---
   14. **为什么 GPT 的方案特别适合大模型**

       因为它把大量任务统一成了一种形式：

       ```
       给定前文，生成后文
       ```

       翻译：

       ```
       中文：我喜欢苹果
       英文：
       ```

       摘要：

       ```
       文章：……
       摘要：
       ```

       问答：

       ```
       问题：……
       回答：
       ```

       代码生成：

       ```
       需求：写一个快速排序
       代码：
       ```

       数学推理：

       ```
       题目：……
       解答：
       ```

       从模型角度看，它们全都是：

       $$
       \text{前缀}\rightarrow\text{继续生成}
       $$

       于是只需要一种架构和一种预训练目标，就能在海量文本上训练。
5. **Flash attention：普通 Attention 存概率表 P，再用 P 算 O。Flash Attention 不存 P，它边算 P 边把 P 乘进 V，最后只保留累计输出 O。** 原来的attention是要经过softmax归一化后再乘v得到一个数，softmax就是全部的注意力分数先减去最大的注意力分数，再算exp，再把所有的exp加起来得到分母，任何exp各项除以分母，得到的这个向量*v是这个token包含全部上下文信息的语义，flash attention是分块，第一块就是直接这一块的注意力分数减去截止目前块最大的注意力分数的exp，然后直接乘v，得到A这个中间值作为分子，然后分母是这一块的注意力分数减去这这一块最大的注意力分数的exp，然后分子除以分母，第二块得看最大值有没有变化，没有变化的话直接就是分子为旧分子+当前块的注意力分数减去第一第二块最大的注意力分数的exp，然后直接乘v，分母也是旧分母+当前块的注意力分数减去第一第二块最大的注意力分数的exp，最终值为新分子除以新分母；如果最大值变了，那就旧分母乘exp（旧最大值-新最大值），旧分子也是乘exp（旧最大值-新最大值），然后再算第二块，用新最大值来算。**其实最根本的区别就是普通attention得有归一化的概率P后才能乘V，而flash attention则是exp（当前值-最大值）直接***​***V了，最终输出除以分母，这个分母才是flash attention用来控制归一化的，只不过是如果最大值不变新分母就是旧分母直接加上新的exp（当前值-最大值）之和，新分子就是旧分子和直接加上新的exp（当前值-最大值）****  **V之和就行了，注意不是旧输出因为旧输出已经除过旧分母了，最大值变了的话就对旧分子分母都先**​***exp（旧最大值-新最大值），然后再用新最大值算新一块，最后新分母就是缩放后的旧分母再加上第二块的exp（当前值-第一二块的最大值），新分子就是缩放后的旧分子再加上第二块的exp（当前值-第一二块的最大值）****  **V**

   1. **普通 Attention 怎么算？**

      分数：

      ```
      S = [2, 4, 1, 3]
      ```

      为了稳定，先减最大值 `4`：

      ```
      S - max(S) = [2-4, 4-4, 1-4, 3-4]
                 = [-2, 0, -3, -1]
      ```

      算 exp：

      ```
      exp(-2) ≈ 0.135
      exp(0)  = 1
      exp(-3) ≈ 0.050
      exp(-1) ≈ 0.368
      ```

      所以分母总和是：

      ```
      l = 0.135 + 1 + 0.050 + 0.368
        = 1.553
      ```

      softmax 概率是：

      ```
      [0.135/1.553, 1/1.553, 0.050/1.553, 0.368/1.553]
      ≈ [0.087, 0.644, 0.032, 0.237]
      ```

      然后乘 V：

      ```
      O = 0.087×10 + 0.644×20 + 0.032×30 + 0.237×40
      ```

      算一下：

      ```
      O ≈ 0.87 + 12.88 + 0.96 + 9.48
        ≈ 24.19
      ```

      所以普通 Attention 最后输出：

      ```
      O ≈ 24.19
      ```

      普通 Attention 中间会真的保存：

      ```
      softmax 概率表 = [0.087, 0.644, 0.032, 0.237]
      ```

      ---
   2. **Flash Attention 怎么算？**

      Flash Attention 不一次性看完整的：

      ```
      [2, 4, 1, 3]
      ```

      它分块。

      比如切成两块：

      ```
      第一块：[2, 4]
      第二块：[1, 3]
      ```

      它维护三个东西：

      ```
      m = 当前看过的最大分数
      l = 当前 softmax 分母
      A = 当前累计的加权分子
      ```

      最后：

      ```
      O = A / l
      ```

      这里的 `A` 是：

      ```
      A = exp(score1 - m) × V1 + exp(score2 - m) × V2 + ...
      ```

      你可以把它理解成：  
      ​`l`​ 是分母，`A`​ 是分子，最后 `O = 分子 / 分母`。

      ---
   3. **第一块：[2, 4]**

      第一块分数：

      ```
      [2, 4]
      ```

      当前最大值：

      ```
      m_old = 4
      ```

      分母：

      ```
      l_old = exp(2-4) + exp(4-4)
            = exp(-2) + exp(0)
            ≈ 0.135 + 1
            = 1.135
      ```

      对应的 V 是：

      ```
      [10, 20]
      ```

      所以累计分子：

      ```
      A_old = exp(2-4)×10 + exp(4-4)×20
            = 0.135×10 + 1×20
            = 1.35 + 20
            = 21.35
      ```

      此时如果只看第一块，临时输出是：

      ```
      O_old = A_old / l_old
            = 21.35 / 1.135
            ≈ 18.81
      ```

      但是注意，Flash Attention ​**不会把第一块的 softmax 概率**  **​`[0.119, 0.881]`​** ​ **存下来**。

      它只保留：

      ```
      m_old = 4
      l_old = 1.135
      A_old = 21.35
      ```

      或者等价地保留 `O_old`​ 和 `l_old`。

      ---
   4. **第二块来了：[1, 3]**

      第二块分数：

      ```
      [1, 3]
      ```

      对应 V：

      ```
      [30, 40]
      ```

      现在完整分数其实是：

      ```
      [2, 4, 1, 3]
      ```

      最大值还是：

      ```
      m_new = 4
      ```

      因为第二块里的 `1`​ 和 `3`​ 都没超过 `4`。

      所以分母更新：

      ```
      l_new = l_old + exp(1-4) + exp(3-4)
      ```

      也就是：

      ```
      l_new = 1.135 + exp(-3) + exp(-1)
            ≈ 1.135 + 0.050 + 0.368
            = 1.553
      ```

      分子也更新：

      ```
      A_new = A_old + exp(1-4)×30 + exp(3-4)×40
      ```

      也就是：

      ```
      A_new = 21.35 + 0.050×30 + 0.368×40
            = 21.35 + 1.50 + 14.72
            = 37.57
      ```

      最后输出：

      ```
      O_new = A_new / l_new
            = 37.57 / 1.553
            ≈ 24.19
      ```

      你看，结果和普通 Attention 一样：

      ```
      普通 Attention：O ≈ 24.19
      Flash Attention：O ≈ 24.19
      ```

      但 Flash Attention 中间没有保存完整 softmax：

      ```
      [0.087, 0.644, 0.032, 0.237]
      ```

      它只是边看边更新：

      ```
      m, l, A
      ```

      ---
   5. **你问的关键：前面 softmax 不会变吗？**

      会变。

      第一块单独看时：

      ```
      softmax([2,4]) ≈ [0.119, 0.881]
      ```

      但完整看时：

      ```
      softmax([2,4,1,3]) ≈ [0.087, 0.644, 0.032, 0.237]
      ```

      前两个概率确实从：

      ```
      [0.119, 0.881]
      ```

      变成了：

      ```
      [0.087, 0.644]
      ```

      也就是说，前面那一块的权重被“稀释”了。

      但是 Flash Attention 不需要回头改 softmax 表，因为它根本没存 softmax 表。

      它只需要让：

      ```
      分母 l 从 1.135 变成 1.553
      分子 A 从 21.35 变成 37.57
      ```

      最后统一算：

      ```
      O = A / l
      ```

      这样前面那部分的占比自然就变小了。

      ---
   6. **用“奶茶兑水”理解**

      第一块 `[2,4]` 算完时，Flash Attention 得到一杯浓缩奶茶：

      ```
      A_old = 21.35
      l_old = 1.135
      O_old = 18.81
      ```

      第二块 `[1,3]` 来了之后，不是回头改前面每一滴奶茶。

      而是说：

      ```
      我现在总量变了，分母变大了；
      再把新的贡献加进来；
      最后重新除一下总量。
      ```

      所以旧贡献会自动被稀释。

      这就是为什么它不用保存完整 softmax。

      ---
   7. **再看一个“最大值变了”的例子**

      刚才第二块 `[1,3]`​ 没超过最大值 `4`，所以比较简单。

      现在换成：

      ```
      第一块：[2, 4]
      第二块：[8, 3]
      ```

      V 还是：

      ```
      V = [10, 20, 30, 40]
      ```

      第一块算完还是：

      ```
      m_old = 4
      l_old = 1.135
      A_old = 21.35
      ```

      但第二块来了：

      ```
      [8, 3]
      ```

      新最大值变成：

      ```
      m_new = 8
      ```

      麻烦来了：  
      之前所有东西都是按照 `m_old = 4`​ 算的，现在要改成按 `m_new = 8` 算。

      所以旧的分母和旧的分子都要缩放：

      ```
      缩放系数 = exp(m_old - m_new)
               = exp(4 - 8)
               = exp(-4)
               ≈ 0.018
      ```

      旧分母变成：

      ```
      l_old_adjusted = l_old × exp(4-8)
                     = 1.135 × 0.018
                     ≈ 0.0208
      ```

      旧分子变成：

      ```
      A_old_adjusted = A_old × exp(4-8)
                     = 21.35 × 0.018
                     ≈ 0.391
      ```

      然后算第二块的新贡献。

      第二块 `[8,3]`​ 在新最大值 `8` 下：

      ```
      exp(8-8) = exp(0) = 1
      exp(3-8) = exp(-5) ≈ 0.0067
      ```

      新分母：

      ```
      l_new = l_old_adjusted + exp(8-8) + exp(3-8)
            = 0.0208 + 1 + 0.0067
            = 1.0275
      ```

      新分子：

      ```
      A_new = A_old_adjusted + exp(8-8)×30 + exp(3-8)×40
            = 0.391 + 1×30 + 0.0067×40
            = 0.391 + 30 + 0.268
            = 30.659
      ```

      最终输出：

      ```
      O_new = A_new / l_new
            = 30.659 / 1.0275
            ≈ 29.84
      ```

      这时候你能看到：  
      因为 `8`​ 太大了，第 3 个 token 的 V\=30 几乎统治了输出，所以最终 O 接近 30。

      ---
   8. **核心公式版**

      对于每一块，Flash Attention 做的事情大概是：

      ```
      新最大值：
      m_new = max(m_old, 当前块最大值)
      ```

      旧分母缩放：

      ```
      l_old_adjusted = l_old × exp(m_old - m_new)
      ```

      旧分子缩放：

      ```
      A_old_adjusted = A_old × exp(m_old - m_new)
      ```

      当前块分母：

      ```
      l_block = sum(exp(s_block - m_new))
      ```

      当前块分子：

      ```
      A_block = sum(exp(s_block - m_new) × V_block)
      ```

      更新：

      ```
      l_new = l_old_adjusted + l_block
      A_new = A_old_adjusted + A_block
      O_new = A_new / l_new
      ```

      ---
   9. **真正的矩阵里是什么样？**

      刚才我们把 V 简化成数字。真实情况里，V 不是一个数，而是向量。

      比如某个 token 的 V 可能是：

      ```
      V1 = [10, 1, 0]
      V2 = [20, 2, 5]
      V3 = [30, 0, 8]
      V4 = [40, 7, 1]
      ```

      那 `A` 也不是一个数，而是一个向量：

      ```
      A = exp(score1-m)×V1
        + exp(score2-m)×V2
        + exp(score3-m)×V3
        + exp(score4-m)×V4
      ```

      最后：

      ```
      O = A / l
      ```

      只是把每一维都除以同一个 `l`。

      所以本质没变：

      ```
      分母 l 是一个数
      分子 A 是一个向量
      输出 O 是一个向量
      ```

      ---
   10. **你现在应该抓住这个结论**

       Flash Attention 的关键不是：

       ```
       我存一小块 softmax，然后后面再更新它
       ```

       而是：

       ```
       我根本不存 softmax。
       我只存累计分母 l 和累计分子 A。
       后面来了新块，我更新 l 和 A。
       最后 O = A / l。
       ```

       一句话：

       > **普通 Attention 存“概率表”；Flash Attention 存“已经算到一半的答案”。**
       >

       这就很像做加权平均：

       普通 Attention：

       ```
       先把所有人的权重都算出来、写下来，
       再用权重乘分数。
       ```

       Flash Attention：

       ```
       边看人，边更新：
       当前总权重是多少？
       当前加权总分是多少？
       最后加权总分 / 总权重。
       ```

       最终答案一样，但中间不用存那张巨大的注意力概率表。
   11. **Attention 最后不是“得到一个数”，而是得到一个向量**

       如果为了方便举例，`V = [10,20,30,40]`，那最后确实是一个数。

       但真实模型里，每个 `V` 是一个向量，比如：

       ```
       V1 = [10, 1, 3]
       V2 = [20, 2, 5]
       V3 = [30, 0, 8]
       V4 = [40, 7, 1]
       ```

       所以最后输出也是一个向量：

       ```
       O = p1V1 + p2V2 + p3V3 + p4V4
       ```

       它不是单个 `概率 × V`，而是：

       ```
       所有 softmax 概率 × 各自的 V，再加起来
       ```

       这个输出向量 `O` 才是“这个 token 融合上下文后的新语义表示”。
   12. **你的普通 Attention 理解是对的**

       标准 Attention 对某一行注意力分数：

       ```
       S = [2, 4, 1, 3]
       ```

       会先找最大值：

       ```
       m = 4
       ```

       然后每项减最大值：

       ```
       [2-4, 4-4, 1-4, 3-4]
       = [-2, 0, -3, -1]
       ```

       再算 exp：

       ```
       [exp(-2), exp(0), exp(-3), exp(-1)]
       ```

       再求和得到分母：

       ```
       l = exp(-2) + exp(0) + exp(-3) + exp(-1)
       ```

       每一项除以分母，得到 softmax 概率：

       ```
       p_i = exp(s_i - m) / l
       ```

       最后：

       ```
       O = p1V1 + p2V2 + p3V3 + p4V4
       ```

       这部分你理解是对的。
   13. **Flash Attention 的核心：A 是“未归一化分子”**

       你说的 `A` 作为分子，这个非常关键，理解对了。

       对于第一块，比如：

       ```
       第一块分数：[2, 4]
       对应 V：[V1, V2]
       ```

       第一块最大值：

       ```
       m = 4
       ```

       分母：

       ```
       l = exp(2-4) + exp(4-4)
       ```

       分子：

       ```
       A = exp(2-4)V1 + exp(4-4)V2
       ```

       临时输出：

       ```
       O = A / l
       ```

       这里注意：  
       **A 本身还不是最终语义，A / l 才是归一化后的输出。**
   14. **第二块来了，如果最大值没变**

       假设第二块是：

       ```
       第二块分数：[1, 3]
       ```

       旧最大值是：

       ```
       m_old = 4
       ```

       第二块最大值是 `3`​，没有超过 `4`，所以：

       ```
       m_new = 4
       ```

       这时候更新很简单：

       ```
       l_new = l_old + exp(1-4) + exp(3-4)
       ```

       ```
       A_new = A_old + exp(1-4)V3 + exp(3-4)V4
       ```

       最后：

       ```
       O_new = A_new / l_new
       ```

       你这里理解是对的。

       只是有个小细节：  
       第二块不是“减去这一块最大的注意力分数”，而是减去​**当前全局最大值**。

       也就是这里第二块 `[1,3]`​，它自己块内最大值是 `3`​，但我们减的是旧最大值 `4`：

       ```
       exp(1-4), exp(3-4)
       ```

       不是：

       ```
       exp(1-3), exp(3-3)
       ```

       因为目前见过的最大值还是 `4`。
   15. **第二块来了，如果最大值变了**

       假设第二块是：

       ```
       第二块分数：[8, 3]
       ```

       旧最大值：

       ```
       m_old = 4
       ```

       新最大值：

       ```
       m_new = 8
       ```

       这时候你说得对：旧分母和旧分子都要缩放。

       旧分母：

       ```
       l_old_adjusted = l_old × exp(m_old - m_new)
       ```

       也就是：

       ```
       l_old_adjusted = l_old × exp(4 - 8)
       ```

       旧分子：

       ```
       A_old_adjusted = A_old × exp(m_old - m_new)
       ```

       也就是：

       ```
       A_old_adjusted = A_old × exp(4 - 8)
       ```

       然后第二块要用新的最大值 `8` 来算：

       ```
       l_block = exp(8-8) + exp(3-8)
       ```

       ```
       A_block = exp(8-8)V3 + exp(3-8)V4
       ```

       最后：

       ```
       l_new = l_old_adjusted + l_block
       ```

       ```
       A_new = A_old_adjusted + A_block
       ```

       ```
       O_new = A_new / l_new
       ```

       这部分你理解也对。
   16. **小修正 1：不是“普通 Attention 必须先存 P”，而是“普通实现通常会显式生成 P”**

       数学上 Attention 本来就是：

       ```
       O = softmax(S) V
       ```

       所以从公式上看，是先有 `P = softmax(S)`​ 再乘 `V`。

       但严格说，`P`​ 不一定非得作为完整矩阵存下来；只是普通实现里通常会真的生成并保存完整的 `P`。

       Flash Attention 的厉害点就是：

       ```
       数学上还是 softmax(S) V
       实现上不存完整 P
       ```
   17. **小修正 2：最大值变了时，不是“旧分母直接加”，而是“缩放后的旧分母再加”**

       你最后一句稍微改一下就完美：

       你说：

       > 最大值变了的话就对旧分子分母都先乘 `exp(旧最大值 - 新最大值)`，然后再用新最大值算新一块。
       >

       这句是对的。

       然后后面应该说：

       ```
       新分母 = 缩放后的旧分母 + 第二块的 exp(当前值 - 新最大值) 之和

       新分子 = 缩放后的旧分子 + 第二块的 exp(当前值 - 新最大值) × V 之和
       ```

       也就是：

       ```
       l_new = l_old × exp(m_old - m_new) + sum(exp(s_new - m_new))
       ```

       ```
       A_new = A_old × exp(m_old - m_new) + sum(exp(s_new - m_new) × V_new)
       ```

       最后：

       ```
       O_new = A_new / l_new
       ```

       这里的重点是：  
       **旧分子、旧分母已经先被缩放过了，不能用原来的旧分子旧分母直接加。**

       ---
   18. **你这段可以改成最终版**

       ```
       普通 Attention 会先计算完整的注意力分数 S = QK^T，
       再对 S 做 softmax 得到归一化概率 P，
       最后用 P 乘 V 得到输出 O。

       Flash Attention 不显式保存完整的 softmax 概率矩阵 P。
       它分块计算注意力分数，对每一行维护三个状态：
       m：当前见过的最大注意力分数
       l：当前 softmax 分母
       A：当前未归一化的加权 V 分子

       每个新块来了以后，先判断最大值是否变化。

       如果最大值不变：
       l_new = l_old + sum(exp(s_block - m))
       A_new = A_old + sum(exp(s_block - m) × V_block)

       如果最大值变了：
       先把旧分母和旧分子缩放到新最大值标准下：
       l_old = l_old × exp(m_old - m_new)
       A_old = A_old × exp(m_old - m_new)

       然后再加当前块贡献：
       l_new = l_old + sum(exp(s_block - m_new))
       A_new = A_old + sum(exp(s_block - m_new) × V_block)

       最后输出：
       O = A_new / l_new

       所以 Flash Attention 的核心是：
       不保存完整 P，而是边分块计算边维护分子 A 和分母 l，最后再归一化。
       ```
6. **MoE：Mixture of Experts，混合专家模型**。MoE 就是把 Transformer 里的 FFN 层换成多个 FFN 专家。每个 token 经过 Router 打分，只选择 Top-K 个专家计算，然后把这些专家输出按 Router 权重加权求和。这样模型总参数量可以很大，但每个 token 实际只激活少量参数，所以计算更省。每个 Expert 是一套不同的 FFN 参数，它们会在训练中逐渐学会处理某些类型的 hidden state，不同专家的知识有些不一样，因为训练时，有些 token 会经常被 Router 分到某些专家那里，久而久之，这些专家会更擅长处理某些模式，但这不是人工规定的，是训练自己形成的。Router 负责判断当前 token 的 hidden state 更适合交给哪些 Expert。所有 token 可以同时过 Router，但每个 token 的专家选择是独立的。token 不是“原始单词”直接去选专家，而是它当前层的 **hidden state** 去选，也就是都带着上下文信息的。**MoE 中，Router 与专家 FFN 一起训练。Router 根据每个 token 在当前层的隐藏状态给所有专家打分，选择 Top-k 个专家处理该 token；训练过程中，最终 loss 的反向传播会同时优化 Router 的分配规则和专家的能力，使 Router 逐渐学会把不同隐藏状态交给更合适的专家。**

   1. **MoE 替换的是 Transformer 里的 FFN 层**

      普通 Transformer block 大概是：

      ```
      Self-Attention
      ↓
      Add & Norm
      ↓
      FFN
      ↓
      Add & Norm
      ```

      MoE 版本把中间的 **FFN** 换成：

      ```
      很多个 FFN 专家 + 一个 Router
      ```

      也就是图左边写的：

      ```
      Switching FFN Layer
      ```

      这里的 expert 通常不是一整个完整大模型，而是 ​**一个 FFN 子网络**。

      所以 MoE 不是说有 8 个完整 GPT 模型在里面，而是：

      ```
      Attention 层大多共享
      FFN 层变成多个专家
      每个 token 只走其中几个
      ```

      ---
   2. **Router 是干嘛的？**

      Router 就像分诊台。

      一个 token 进来，比如：

      ```
      x = “More”
      ```

      Router 会算：

      ```
      这个 token 更适合交给哪些专家处理？
      ```

      假设有 8 个专家：

      ```
      Expert 1, Expert 2, Expert 3, ..., Expert 8
      ```

      Router 可能打分：

      ```
      Expert 1: 0.1
      Expert 2: 0.8
      Expert 3: 0.05
      Expert 4: 0.6
      Expert 5: 0.2
      ...
      ```

      如果是 ​**Top-K \= 2**，就只选分数最高的两个专家。

      比如选中：

      ```
      Expert 2 和 Expert 4
      ```

      其他专家直接不用。

      这就是图里写的：

      ```
      8 experts → 2 experts
      k = 2
      ```

      ---
   3. **公式是什么意思？**

      图右边这个公式：

      ```
      y = Σ G_i(x) E_i(x)
      ```

      可以拆开看。

      ### E\_i(x)

      这个是第 i 个专家对 token x 的处理结果。

      比如：

      ```
      E_2(x) = Expert 2 处理 x 后得到的向量
      E_4(x) = Expert 4 处理 x 后得到的向量
      ```

      ### G\_i(x)

      这个是 Router 给第 i 个专家的权重。

      比如 Router 最后给出：

      ```
      G_2(x) = 0.7
      G_4(x) = 0.3
      ```

      那么输出就是：

      ```
      y = 0.7 * E_2(x) + 0.3 * E_4(x)
      ```

      一句话：

      > Router 决定找谁，Expert 负责加工，最后按 Router 的权重加权求和。
      >

      ---
   4. **TopK + Softmax 是什么？**

      图里写：

      ```
      G(x) = Softmax(TopK(x · Wg))
      ```

      意思是：

      ### 第一步：Router 打分

      ```
      x · Wg
      ```

      这里的 `Wg` 是 Router 的参数矩阵。

      它把 token 向量 x 变成对每个专家的分数。

      比如有 8 个专家，算出来：

      ```
      [0.1, 0.8, -0.3, 0.4, 0.2, -0.5, 0.7, 0.0]
      ```

      ### 第二步：TopK 只保留前 K 个

      如果 K \= 2，只保留最大的两个：

      ```
      Expert 2: 0.8
      Expert 7: 0.7
      ```

      其他专家变成不用，可以理解成：

      ```
      [-∞, 0.8, -∞, -∞, -∞, -∞, 0.7, -∞]
      ```

      ### 第三步：Softmax 归一化

      只对选中的专家算概率：

      ```
      Softmax(0.8, 0.7)
      ```

      可能得到：

      ```
      [0.525, 0.475]
      ```

      所以最后：

      ```
      y = 0.525 * Expert2(x) + 0.475 * Expert7(x)
      ```
   5. **一开始专家和 Router 都是随机的；训练过程中，微小随机差异被逐渐放大，不同专家因为接收到不同数据而产生能力差异，Router 又通过最终 loss 学会把不同隐藏状态送到更合适的专家。两者互相塑造，最终形成分工。**

      对，​**你抓到 MoE 最神奇的核心了**。

      一开始确实是：

      - 每个专家 FFN 的结构通常完全相同；
      - 每个专家的参数都是随机初始化；
      - Router 的参数也是随机初始化；
      - 并没有人为规定“专家 1 学数学、专家 2 学代码”。

      也就是说，刚开始它们就像一群​**能力差不多、分工为零的新员工**。

      但由于随机初始化不可能完全一样，专家之间最初会有极其微小的差异。Router 初期也会因为随机参数，把不同 token 稍微偏向不同专家：

      $$
      x \rightarrow \operatorname{Router}(x) \rightarrow E_i
      $$

      假设某一批 token 偶然更多地进入专家 3，那么专家 3 就会更多地收到这些 token 产生的梯度，于是它会更适应这一类隐藏状态。

      接着形成一个正反馈：

      $$
      \text{某类 token 更多进入专家 3}
      $$

      $$
      \Downarrow
      $$

      $$
      \text{专家 3 更擅长处理这类 token}
      $$

      $$
      \Downarrow
      $$

      $$
      \text{把这类 token 交给专家 3，更容易降低 loss}
      $$

      $$
      \Downarrow
      $$

      $$
      \text{Router 更倾向于选择专家 3}
      $$

      然后这种趋势不断强化。最终就形成了你说的：

      > 不同 FFN 专家逐渐产生差异，而 Router 也逐渐学会了如何与这些不同专家配合。
      >

      最妙的是，​**专家能力和 Router 的分配规则不是分开训练好再拼起来的，而是一起长出来的**。

      可以把一次输出简化成：

      $$
      y=\sum_{i\in \operatorname{TopK}(x)}p_i(x)E_i(x)
      $$

      这里：

      - $E_i(x)$ 是第 $i$ 个专家的输出；
      - $p_i(x)$ 是 Router 给它的权重；
      - 最终 loss 同时依赖 Router 和专家。

      所以反向传播时，梯度会同时调整两边：

      $$
      \frac{\partial L}{\partial W_{\text{router}}}
      $$

      告诉 Router：

      > 这次分配得好不好，下次类似输入应该更偏向谁？
      >

      而：

      $$
      \frac{\partial L}{\partial W_{\text{expert},i}}
      $$

      告诉被选中的专家：

      > 你处理这类输入时，内部参数应该怎么改？
      >

      于是它们形成一种​**共同适应，co-adaptation**：

      > Router 根据专家当前的能力学习分配；专家又根据 Router 分配过来的数据发展能力。
      >

      不过这里还有一个现实问题：如果任由这种正反馈发展，可能会出现“赢家通吃”。

      例如专家 3 一开始稍微好一点：

      $$
      \text{Router 更常选专家 3}
      \rightarrow
      \text{专家 3 获得更多训练}
      \rightarrow
      \text{专家 3 更强}
      \rightarrow
      \text{Router 更常选它}
      $$

      最后其他专家全饿死，所有 token 都挤向一个专家，MoE 就废了。

      所以训练 MoE 时通常还会加入​**负载均衡损失**，鼓励 Router 不要总选少数专家：

      $$
      L_{\text{total}}
      =
      L_{\text{language}}
      +
      \lambda L_{\text{balance}}
      $$

      它相当于告诉 Router：

      > 既要把 token 送给合适的专家，也不能让少数专家过载、其他专家完全没活干。
      >

      所以完整过程很像一个自动形成的公司：

      - 所有员工初始能力随机；
      - 分配员也是新人；
      - 分配员随机派任务；
      - 员工做得多的任务越来越熟练；
      - 分配员观察哪种任务交给谁效果更好；
      - 公司又强制任务不能全部压给一个人；
      - 最后自然产生分工和协作。

      而且它们并不一定形成我们能直接命名的“数学专家”“英文专家”。实际分工可能很抽象，例如：

      - 某类语法结构；
      - 某些隐藏状态方向；
      - 某类实体信息；
      - 某些推理中间模式；
      - 某种特定上下文组合。

      所以你的理解完全正确：

      > **一开始专家和 Router 都是随机的；训练过程中，微小随机差异被逐渐放大，不同专家因为接收到不同数据而产生能力差异，Router 又通过最终 loss 学会把不同隐藏状态送到更合适的专家。两者互相塑造，最终形成分工。**
      >

      这确实不是“人类设计好了分工”，而更像是我们搭了一个允许分工产生的环境，然后分工自己长出来了。
7. **KV cache** 就是把过去 token 在每一层算出来的 K、V 存起来。生成新 token 时，只算新 token 的 Q/K/V，然后用新 Q 去查过去缓存的 K/V，避免每一步重复计算整个历史。K cache = 过去所有资料的索引，V cache = 过去所有资料的内容，q_new = 当前问，每生成一个新 token，就是拿当前问题 `q_new`​ 去查历史资料库 `[K_cache, V_cache]`。KV cache 主要用于自回归推理生成阶段。推理时模型参数固定，过去 token 的 K/V 算过后不会变，可以缓存并复用。 训练时通常整段序列并行计算，而且参数每轮都会更新，旧的 K/V 不能跨 step 复用，所以常规训练不靠 KV cache 加速。

   1. **为什么要 cache K 和 V？**

      因为生成文本是一个 token 一个 token 出来的。

      比如已经有：

      ```
      I love eating
      ```

      要生成下一个 token，模型需要处理：

      ```
      I love eating
      ```

      生成了：

      ```
      apples
      ```

      下一步又要处理：

      ```
      I love eating apples
      ```

      如果没有 KV cache，每一步都要重新给前面所有 token 算一遍 K、V：

      ```
      第1步：重新算 I love eating 的 K/V
      第2步：重新算 I love eating apples 的 K/V
      第3步：重新算 I love eating apples very 的 K/V
      ...
      ```

      这就很浪费。

      因为前面 token 的内容没变，它们的 K、V 在当前层里也不会变。

      所以 KV cache 的想法是：

      > **以前 token 的 K、V 算过就存下来，下次直接用。**
      >

      ---
   2. **为什么只缓存 K、V，不缓存 Q？**

      因为生成新 token 时，真正要发起查询的是​**当前新 token 的 Q**。

      比如现在新 token 是 `chill`：

      ```
      q_new = chill 的 query
      ```

      它要问：

      ```
      我现在这个 chill，应该看前面哪些 token？
      ```

      所以它拿自己的 `q_new` 去和所有过去的 K 做匹配：

      ```
      q_new · K_prev
      ```

      但过去 token 的 Q 已经没用了。

      比如前面的 `cold`​ 的 query，是当时 `cold`​ 自己作为当前位置时用的。  
      现在轮到 `chill`​ 生成后续内容了，需要的是 `chill`​ 的 query，而不是 `cold` 的 query。

      所以：

      ```
      K：未来 token 要拿来匹配，所以要存
      V：未来 token 要拿来取信息，所以要存
      Q：只在当前 token 查询时用一次，用完就没必要存
      ```

      一句话：

      > **Q 是“当前问题”，K/V 是“过去资料库”。未来还会查过去资料库，所以缓存 K/V；但不会再用过去的问题，所以不缓存 Q。**
      >

      ---
   3. **KV cache 的完整流程**

      假设已经有 4 个 token：

      ```
      [我, 喜欢, 吃, 苹果]
      ```

      在某一层里，已经缓存了：

      ```
      K_cache = [k_我, k_喜欢, k_吃, k_苹果]
      V_cache = [v_我, v_喜欢, v_吃, v_苹果]
      ```

      现在要生成下一个 token，比如模型刚生成了：

      ```
      。
      ```

      那新 token 进入下一步时，会算：

      ```
      q_new
      k_new
      v_new
      ```

      然后：

      ```
      K_cache = [k_我, k_喜欢, k_吃, k_苹果, k_new]
      V_cache = [v_我, v_喜欢, v_吃, v_苹果, v_new]
      ```

      注意力计算就是：

      ```
      attention score = q_new × K_cache^T
      ```

      得到当前 token 对所有历史 token 的注意力分数。

      再 softmax：

      ```
      P = softmax(q_new × K_cache^T)
      ```

      最后：

      ```
      O_new = P × V_cache
      ```

      这个 `O_new` 就是当前 token 融合上下文后的新向量。

      ---
   4. **它省了什么？**

      没有 KV cache：

      ```
      每生成一个新 token，都重新算整个前缀的 K/V。
      ```

      有 KV cache：

      ```
      每生成一个新 token，只算新 token 的 k_new 和 v_new。
      过去的 K/V 直接从缓存读。
      ```

      所以它主要加速的是​**推理生成阶段**，尤其是长文本生成。

      ---
   5. **它和 Flash Attention 的区别**

      这俩别混了。

      **Flash Attention：**

      ```
      我还是要算 Attention，
      但我不存完整 n×n 注意力矩阵，
      用分块 + online softmax 减少显存读写。
      ```

      **KV cache：**

      ```
      我生成新 token 时，
      不重新计算过去 token 的 K/V，
      直接复用缓存。
      ```

      所以：

      ```
      Flash Attention 解决：Attention 中间矩阵太大、显存 IO 太多。
      KV cache 解决：自回归生成时过去 token 的 K/V 重复计算太浪费。
      ```
8. 每个可训练参数都有自己的梯度。梯度本质上就是 loss 对这个参数的导数/偏导数。梯度绝对值越大，说明这个参数稍微变化一点，loss 的变化越明显；梯度的正负号表示局部方向：如果梯度为正，说明这个参数增大会让 loss 增大，所以训练时要把它调小；如果梯度为负，说明这个参数增大会让 loss 变小，所以训练时要把它调大。整体来看，梯度方向是 loss 上升最快的方向，所以梯度下降要沿着负梯度方向走。每个参数都有一个对应的梯度。参数是什么形状，梯度通常就是什么形状，参数是数字，梯度也是对应这些数字的数字，参数是矩阵，梯度也是对应形状的矩阵

   1. $$
      P_k^{(t+1)} = P_k^{(t)} - \eta \frac{\partial L(P,\mathcal{E},Q)}{\partial P_k^{(t)}}
      $$

      > **第** **$t+1$** **步的新** **$P_k$**​ **，等于第** **$t$** **步的旧** **$P_k$**​ **，减去学习率乘以它对 loss 的梯度。**
      >

      1. **每个符号什么意思？**

         $$
         P_k^{(t)}
         $$

         意思是：

         ```
         第 k 个 AdaLoRA 模块里的 P 矩阵
         在第 t 步训练时的值
         ```

         比如模型很多地方都插了 AdaLoRA：

         ```
         第1层 Wq：k = 1
         第1层 Wv：k = 2
         第2层 Wq：k = 3
         ...
         ```

         所以 $k$ 是第几个模块。

         ---

         $$
         t
         $$

         是训练步数。

         ```
         t = 0：刚初始化
         t = 1：训练一步后
         t = 2：训练两步后
         ...
         ```

         所以：

         $$
         P_k^{(t+1)}
         $$

         就是下一步的新 $P_k$。

         ---

         $$
         \eta
         $$

         是学习率，读作 eta。

         它控制每次更新走多大一步。

         ```
         η 大：每次改得猛
         η 小：每次改得慢
         ```

         ---

         $$
         L(P,\mathcal{E},Q)
         $$

         是 loss。

         这里的 $\mathcal{E}$ 可以理解成所有的 $\Lambda$。

         所以：

         ```
         L(P, E, Q)
         ```

         意思是：

         > 当前所有 AdaLoRA 参数 $P,\Lambda,Q$ 让模型产生的 loss。
         >

         ---
      2. **最关键：这个东西是什么？**

         $$
         \frac{\partial L(P,\mathcal{E},Q)}{\partial P_k^{(t)}}
         $$

         这个不是普通除法。

         它的意思是：

         > **loss 对** **$P_k$** **的偏导数，也就是** **$P_k$** **的梯度。**
         >

         如果 $P_k$ 是一个矩阵，那这个梯度也是一个矩阵，形状和 $P_k$ 一样。

         比如：

         $$
         P_k =
         \begin{bmatrix}
         p_{11} & p_{12} \\
         p_{21} & p_{22}
         \end{bmatrix}
         $$

         那它的梯度就是：

         $$
         \frac{\partial L}{\partial P_k}
         =
         \begin{bmatrix}
         \frac{\partial L}{\partial p_{11}} & \frac{\partial L}{\partial p_{12}} \\
         \frac{\partial L}{\partial p_{21}} & \frac{\partial L}{\partial p_{22}}
         \end{bmatrix}
         $$

         每个元素都有一个自己的方向：

         ```
         p11 应该变大还是变小
         p12 应该变大还是变小
         p21 应该变大还是变小
         p22 应该变大还是变小
         ```

         ---
      3. **为什么是减号？**

         因为梯度指向的是 ​**loss 上升最快的方向**。

         但我们想让 loss 下降。

         所以要反着走：

         $$
         新参数 = 旧参数 - 学习率 \times 梯度
         $$

         如果梯度是正的，减掉它，参数变小。

         如果梯度是负的，减掉负数，参数变大。

         比如：

         $$
         p = 10
         $$

         $$
         \frac{\partial L}{\partial p} = +3
         $$

         $$
         \eta = 0.1
         $$

         那么：

         $$
         p_{\text{new}} = 10 - 0.1 \times 3 = 9.7
         $$

         参数变小。

         如果梯度是：

         $$
         \frac{\partial L}{\partial p} = -3
         $$

         那么：

         $$
         p_{\text{new}} = 10 - 0.1 \times (-3) = 10.3
         $$

         参数变大。
   2. **每个参数都有一个偏导数，表示在当前状态下，单独微调这个参数会怎样影响 Loss。所有参数的偏导数组成梯度，优化器根据梯度同时调整大量参数。学习率决定每一步走多远，走太大可能越过或发散，走太小则训练缓慢。经过海量 batch 的反复更新，模型不一定找到绝对最低点，而是逐渐进入一个 Loss 较低、泛化能力较好的参数区域。**

      设模型所有参数为：

      $$
      \theta=(\theta_1,\theta_2,\ldots,\theta_n)
      $$

      Loss 是所有参数共同决定的：

      $$
      L=L(\theta_1,\theta_2,\ldots,\theta_n)
      $$

      对于参数 $\theta_i$，它的梯度是：

      $$
      \frac{\partial L}{\partial \theta_i}
      $$

      意思是：

      > 在当前这个位置，暂时把其他参数看作不变，只让 $\theta_i$ 发生一个极小变化，Loss 会以多快的速度、往哪个方向变化。
      >

      - 梯度为正：参数增大，Loss 倾向于增大，所以应该把参数调小。
      - 梯度为负：参数增大，Loss 倾向于减小，所以应该把参数调大。
      - 绝对值越大：这个参数在当前附近稍微变化，对 Loss 的影响越明显。

      因此更新公式是：

      $$
      \theta_i
      \leftarrow
      \theta_i-\eta\frac{\partial L}{\partial\theta_i}
      $$

      其中 $\eta$ 是学习率。

      1. **但不是逐个参数单独修改**

         虽然求每个偏导数时，可以理解为“暂时固定其他参数”，但真正更新时，模型会把所有参数的梯度组成一个整体：

         $$
         \nabla_\theta L=
         \left[
         \frac{\partial L}{\partial\theta_1},
         \frac{\partial L}{\partial\theta_2},
         \ldots,
         \frac{\partial L}{\partial\theta_n}
         \right]
         $$

         然后大量参数一起更新：

         $$
         \theta
         \leftarrow
         \theta-\eta\nabla_\theta L
         $$

         所以更准确地说：

         > 每个参数都有自己的局部调整建议，所有建议合在一起，构成整个模型参数空间中的下降方向。
         >

         就像几十亿个人同时收到一句反馈：

         - 你往左一点；
         - 你往右一点；
         - 你别动太多；
         - 你需要大幅调整。

         大家一起动一步，模型的整体输出就发生变化。
      2. **确实可能“一步迈过头”**

         假设 Loss 曲线像山谷：

         $$
         L(\theta)
         $$

         梯度告诉你下坡方向，但不直接保证一步应该走多远。学习率控制步长：

         $$
         \Delta\theta=-\eta\nabla_\theta L
         $$

         如果学习率太大，就可能从山谷一侧直接跨到另一侧：

         $$
         \text{左边山坡}
         \rightarrow
         \text{越过谷底}
         \rightarrow
         \text{右边山坡}
         $$

         严重时会来回震荡，甚至越走越远，叫做训练发散。

         如果学习率太小，则每次只挪一点点，训练特别慢，也可能长期困在比较平坦的地方。

         所以实际训练会使用：

         - 学习率预热；
         - 学习率衰减；
         - Adam、AdamW 等优化器；
         - 梯度裁剪；
         - 动量等机制。

         它们都是为了让参数调整得更稳。
      3. **不一定真的找到“最低点”**

         你说的“尽量找到最低点”方向没错，但大模型训练通常不是保证找到整个空间里的绝对最低点，即全局最小值。

         因为几十亿参数对应的是一个极高维、极复杂的 Loss 地形，里面可能有：

         - 很多低谷；
         - 平台区域；
         - 鞍点；
         - 陡峭方向；
         - 平坦方向。

         训练更像是在寻找一个：

         > Loss 足够低，而且对新数据表现也比较好的区域。
         >

         甚至训练集 Loss 最低也未必最好。假如模型把训练数据死记硬背了，训练 Loss 很低，但面对没见过的数据表现很差，这就是过拟合。
      4. **还有一点：每次看到的 Loss 都有些不同**

         大模型通常不会拿全部训练数据算一次梯度，而是每次取一个 batch：

         $$
         L_{\text{batch}}(\theta)
         $$

         再根据这个 batch 更新参数。

         下一个 batch 的内容不同，梯度方向也可能不同：

         $$
         \nabla L_{\text{batch 1}}
         \neq
         \nabla L_{\text{batch 2}}
         $$

         所以参数不是沿着一条完美光滑的路线下山，而是：

         > 大方向往下，但每一步都有一些抖动和噪声。
         >

         这种噪声反而可能帮助模型离开某些不好的局部区域。
9. **feed forward** 多半指 Transformer 里的 **Feed Forward Network，FFN，前馈神经网络层**；而“前向传播”是 **forward pass**，指把一句话输入模型，从 embedding、attention、FFN、softmax 一路算出下一个 token 概率，它是整个计算流程。

   1. **FFN 是干嘛的？**

      Attention 负责：  
      **让 token 之间互相看，互相交换信息。**

      比如：

      > 我 爱 吃 苹果
      >

      Attention 会让“苹果”知道它和“吃”关系很近，让“我”知道自己是动作发出者。

      但 Attention 之后，每个 token 的向量只是“吸收了上下文信息”。接下来需要一个模块进一步加工这个向量，于是就有 FFN。

      FFN 负责：  
      **对每个 token 自己的向量做深度加工、提炼、变换。**

      可以粗暴理解：

      > Attention：开会交流信息。  
      > FFN：每个人回自己工位，把刚才得到的信息消化、整理、加工成更有用的表示。
      >
   2. **FFN 怎么算？**

      假设每个 token 是 512 维向量。

      FFN 通常是：

      ```
      512维 → 2048维 → 激活函数 → 512维
      ```

      公式大概是：

      ```
      FFN(x) = W2 · activation(W1 · x + b1) + b2
      ```

      比如：

      ```
      x 原来是 512维
      先升维到 2048维
      经过非线性激活
      再降回 512维
      ```

      为什么要升维再降维？

      因为模型需要一个更大的“中间工作台”来组合特征。

      类似你原来只有一张小桌子，信息放不开；FFN 先给你一张大桌子，把各种特征展开、组合、筛选，然后再压缩回原来的 512 维。
   3. **FFN 会不会让 token 之间交流？不会。**

      这是重点。

      **Attention 是 token 和 token 之间交流。**   
      **FFN 是每个 token 自己内部加工。**

      比如句子有 5 个 token：

      ```
      我    爱    吃    苹果    。
      ```

      Attention 会让它们互相看。

      但 FFN 是分别处理：

      ```
      FFN(我)
      FFN(爱)
      FFN(吃)
      FFN(苹果)
      FFN(。)
      ```

      每个 token 都用同一套 FFN 参数加工，但它们之间在 FFN 这一步不交流。

      ---
   4. **Encoder 和 Decoder 可以叠很多层吗？可以，而且本来就是这么设计的。**

      原始 Transformer 是：

      ```
      Encoder 堆 6 层
      Decoder 堆 6 层
      ```

      现代大模型会堆更多层。

      比如 GPT 这类纯 Decoder 模型，本质是：

      ```
      Decoder Block
      Decoder Block
      Decoder Block
      ...
      Decoder Block
      ```

      很多层叠起来，每一层都让 token 表示更高级。

      可以这样理解：

      第一层：看字面关系。  
      中间层：看语法、短语、上下文。  
      更高层：看语义、意图、逻辑、任务目标。

      当然这不是严格固定分工，但大概可以这么想。
   5. **一层 Encoder 里有什么？**

      经典 Encoder Layer 是：

      ```
      输入 x
      ↓
      Self-Attention
      ↓
      Add & Normalize
      ↓
      Feed Forward
      ↓
      Add & Normalize
      ↓
      输出
      ```

      更准确地写：

      ```
      x1 = AddNorm(x + SelfAttention(x))
      x2 = AddNorm(x1 + FFN(x1))
      ```

      所以一层 Encoder 里主要有两个大模块：

      ```
      Self-Attention
      FFN
      ```

      每个模块后面都跟一个：

      ```
      Add & Normalize
      ```
   6. **一层 Decoder 里有什么？**

      原始 Transformer 的 Decoder Layer 是：

      ```
      输入 x
      ↓
      Masked Self-Attention
      ↓
      Add & Normalize
      ↓
      Cross-Attention
      ↓
      Add & Normalize
      ↓
      Feed Forward
      ↓
      Add & Normalize
      ↓
      输出
      ```

      其中：

      **Masked Self-Attention**​：只能看前面的 token，不能偷看未来。  
      ​**Cross-Attention**​：看 Encoder 的输出。  
      ​**FFN**：加工每个 token 自己的向量。

      但 GPT 这种纯 Decoder 模型通常没有 Encoder，所以也没有 Cross-Attention，主要是：

      ```
      Masked Self-Attention
      Add & Norm
      FFN
      Add & Norm
      ```

      一层一层叠很多次。
   7. **Add & Normalize 是干嘛的？**

      这个名字拆开：

      ```
      Add = 残差连接 Residual Connection
      Normalize = 层归一化 LayerNorm
      ```

      先讲 Add。

      1. **Add 是什么？**

         假设某一层输入是：

         ```
         x
         ```

         经过 Attention 后得到：

         ```
         Attention(x)
         ```

         正常你可能以为输出就是：

         ```
         Attention(x)
         ```

         但 Transformer 不这么做，它会：

         ```
         x + Attention(x)
         ```

         也就是把原来的输入 x 加回来。

         这叫 ​**残差连接**。

         为什么要加回来？

         因为模型不想让一层直接“覆盖”原信息，而是让这一层只负责“修正、补充”。

         类似：

         > 原文档不要删掉，只在旁边写批注。
         >

         所以：

         ```
         新表示 = 原表示 + 本层学到的补充信息
         ```

         这和你之前问 LoRA 时的感觉有点像：

         ```
         原来的东西保留
         新学到的东西作为修正加上去
         ```
      2. **Add 有什么好处？**

         第一，防止信息丢失。

         假设 Attention 这一层算得不好，至少原来的 x 还在，不至于全毁。

         第二，让深层网络更容易训练。

         模型堆几十层、上百层的时候，梯度要从最后传回最前面。如果没有残差连接，梯度很容易越传越弱。

         残差连接相当于给梯度开了一条高速公路：

         ```
         后面层的梯度可以更顺畅地传回前面
         ```

         所以深层 Transformer 才能训练起来。
   8. **Normalize 是什么？**

      Normalize 指 ​**LayerNorm，层归一化**。

      它做的事情是：  
      把一个 token 向量里的数值拉回比较稳定的范围。

      比如某个 token 向量本来是：

      ```
      [20, -35, 8, 100, -60, ...]
      ```

      数值太乱，后面的层训练会不稳定。

      LayerNorm 会把它调整成比较稳定的分布，比如大概变成：

      ```
      [0.3, -0.7, 0.1, 1.4, -1.1, ...]
      ```

      不是变成完全一样，而是让整体尺度稳定。
   9. **为什么要 Normalize？**

      因为每一层都在变换向量。

      Attention 变一次，FFN 又变一次，堆很多层后，数值可能越来越大、越来越乱。

      Normalize 就像每一层之后都帮模型“整理仪表盘”：

      > 数值别爆炸，别太偏，保持稳定，方便下一层继续算。
      >

      所以 Add & Normalize 的作用是：

      ```
      Add：保留原信息，方便梯度传播
      Normalize：稳定数值，方便训练
      ```
   10. 整体用一个比喻串起来

       假设每个 token 是一个学生。

       一句话里的所有 token 坐在教室里。

       ### Attention：

       大家互相交流：

       > “我这个词应该关注谁？”  
       > “谁和我关系最大？”  
       > “我要从谁那里拿信息？”
       >

       ### Add：

       交流完之后，不是把自己原来的想法删掉，而是：

       > “我保留自己的理解，再加上别人告诉我的信息。”
       >

       ### Normalize：

       老师说：

       > “大家情绪稳定一点，音量控制一下，别有人太夸张。”
       >

       ### FFN：

       每个学生回到自己座位，独立思考：

       > “我刚才收到的信息到底意味着什么？”  
       > “我要把它加工成更高级的理解。”
       >

       ### Add & Normalize：

       再一次：

       > “保留原来的自己，加上新思考结果，然后稳定一下。”
       >

       这样就是一层 Transformer。

       然后重复很多层：

       ```
       交流 → 整理 → 思考 → 整理
       交流 → 整理 → 思考 → 整理
       交流 → 整理 → 思考 → 整理
       ...
       ```

       最后每个 token 的向量就越来越“懂上下文”。

       ---

       一句话总结：

       **Feed Forward 不是前向传播，而是 Transformer 每一层里的 FFN 模块；Attention 负责 token 之间交流，FFN 负责每个 token 自己加工；Encoder 和 Decoder 都可以堆很多层；Add & Normalize 负责保留原信息、稳定数值、让深层模型更容易训练。**
10. **hidden state**  **=**  **模型每一层里，每个 token 当前的“中间表示向量”，** 可以把它理解成：一个 token 经过模型处理到某一层时，模型对它目前的理解状态。

    1. 假设输入是：

       ```
       我 爱 猫
       ```

       分词后有 3 个 token。

       每个 token 一开始会变成 embedding，比如隐藏维度是 4：

       ```
       我 = [0.2, 0.5, -0.1, 0.7]
       爱 = [0.8, -0.3, 0.4, 0.1]
       猫 = [0.6, 0.9, -0.2, 0.3]
       ```

       合起来就是一个矩阵：

       ```
       H0 = 3 × 4
       ```

       这个 `H0`​ 就是​**第 0 层 hidden state**，也就是最初的 token embedding。

       然后进入第 1 层 Transformer。

       第 1 层做 attention、FFN、残差连接、LayerNorm 之后，会输出新的表示：

       ```
       H1 = 第1层输出的 hidden state
       ```

       再进入第 2 层：

       ```
       H2 = 第2层输出的 hidden state
       ```

       一直到最后：

       ```
       H0 → H1 → H2 → H3 → ... → HL
       ```

       所以 hidden state 就是每一层传给下一层的中间结果。
    2. **形象理解**

       一开始，“猫”的 embedding 只是一个词本身的向量。

       但经过 attention 后，它会结合上下文。

       比如句子是：

       ```
       我 爱 猫
       ```

       最后 “猫” 的 hidden state 里不只是“猫”这个词的信息，还会混入：

       ```
       它被“我”喜欢
       它是“爱”的对象
       它出现在这个句子结尾
       ```

       所以越往高层，hidden state 越像是：

       > 这个 token 在当前上下文中的综合语义表示。
       >
    3. **hidden state 和 Q/K/V 的关系**

       这点很重要。

       某一层的输入 hidden state 是：

       ```
       H
       ```

       然后这一层会用它算出：

       ```
       Q = H Wq
       K = H Wk
       V = H Wv
       ```

       所以：

       ```
       hidden state H 是原材料
       Q/K/V 是 H 经过不同矩阵投影出来的临时工具
       ```

       可以这样理解：

       ```
       H：每个 token 当前的综合状态

       Q：这个 token 想找什么信息
       K：这个 token 有什么可被查找的标签
       V：这个 token 真正能提供什么内容
       ```

       attention 算完后，会得到新的向量，再经过后面的 FFN 等操作，形成下一层的 hidden state。
    4. **一个完整流程**

       某一层里大概是：

       ```
       输入 hidden state H
       ↓
       算 Q/K/V
       ↓
       attention 得到上下文信息
       ↓
       残差连接 + LayerNorm
       ↓
       FFN
       ↓
       残差连接 + LayerNorm
       ↓
       输出新的 hidden state H_next
       ```

       然后：

       ```
       H_next 作为下一层的输入
       ```

       所以 hidden state 是层与层之间传递的东西。
    5. **和 prefix tuning 的关系**

       你前面问 prefix tuning：

       ```
       Q = H Wq
       K = H Wk
       V = H Wv
       ```

       这里的 `H` 就是当前层的 hidden state。

       Prefix tuning 做的是：

       ```
       K' = [prefix_K ; K]
       V' = [prefix_V ; V]
       ```

       但 `Q` 还是由真实 token 的 hidden state 算出来：

       ```
       Q = H Wq
       ```

       也就是说：

       ```
       真实 token 的 hidden state → 算出 Q
       Q 去查 prefix_K + 真实K
       再从 prefix_V + 真实V 里拿信息
       最后生成新的 hidden state
       ```

       一句话总结：

       **hidden state 就是每个 token 在模型某一层里的当前向量状态。它是层与层之间传递的中间表示，Q/K/V 都是从 hidden state 投影出来的。**
11. **大模型的“参数量”，指的是模型内部有多少个可训练数字，不是预训练数据量。预训练数据是“教材”，参数是“学完之后脑子里的权重”，** 再精确一点：**大模型参数量**  **=**  **所有可训练矩阵/向量里的数字总数，** 不是数据集大小。也就是：**一个参数**  **=**  **模型矩阵里的一个数字，比如2*2矩阵的参数量就是4，** 真实大模型里有很多很多矩阵：

    $$
    W_q,\ W_k,\ W_v,\ W_o
    $$

    还有 FFN 里的矩阵：

    $$
    W_1,\ W_2,\ W_3
    $$

    还有 embedding 表、输出层矩阵、LayerNorm 的参数等等。

    这些矩阵里的数字全部加起来，就是模型参数量。

‍
