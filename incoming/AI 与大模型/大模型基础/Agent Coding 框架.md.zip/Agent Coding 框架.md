1. Codex 启动时读取所有 Skill 的 `name、description、路径`，把它们作为临时“技能菜单”放进当前会话；每次提问模型都能参考这份菜单，但不会每次都重新从硬盘读取全部文件，只有 Skill 被触发时才加载完整正文。

   **是的，**​**​`name`​**​ **和** **​`description`​**​ **都是必选项。**

   你可以把整个机制理解成：

   ```
   启动 Codex
       ↓
   扫描所有可用 Skill
       ↓
   读取每个 SKILL.md 的 name、description 和文件路径
       ↓
   把这份“Skill 目录”放进当前会话上下文
       ↓
   你每次提问时，模型都能看到这份目录
       ↓
   匹配到某个 Skill 后，才读取它的完整 SKILL.md
   ```
   1. **​`name`​**​ **和** **​`description`​**​ **必须写**

      一个最小可用的 `SKILL.md` 是：

      ```
      ---
      name: frontend-design
      description: Design distinctive, production-ready frontend interfaces. Use when creating or redesigning websites, landing pages, dashboards, ecommerce pages, or web applications.
      ---

      # Frontend Design

      这里开始写完整工作流程……
      ```
      其中：

      - `name`​：Skill 的唯一名称，也是你写 `$frontend-design` 时使用的名字。
      - `description`​：告诉模型这个 Skill ​**能做什么、什么时候应该调用**。

      OpenAI 的 Skill 规范明确要求 `SKILL.md`​、YAML frontmatter、`name`​、`description`​ 和正文都必须存在；而且 Codex 判断是否启用 Skill 时，主要看的就是 `name`​ 和 `description`。

      尤其是 `description`，不能只写：

      ```
      description: 前端设计
      ```
      这太模糊，模型不知道什么时候该触发。

      更合理的是：

      ```
      description: Design and implement distinctive frontend interfaces with strong typography, layout, responsive behavior, accessibility, and visual polish. Use when building or redesigning websites, ecommerce pages, landing pages, dashboards, and web applications.
      ```
      也就是同时说明：

      ```
      它会做什么
      +
      什么任务下使用它
      ```
      因为完整正文只有在 Skill 被触发以后才会加载，所以“什么时候使用”最好直接写在 `description`，而不是只写在正文里。
   2. **读取完以后存在哪里？**

      它不会存进模型参数，也不会变成模型永久记忆。

      它会被整理成类似下面的临时目录，放入​**当前 Codex 会话的上下文**：

      ```
      Available skills:

      - frontend-design
        Description: Design distinctive production-ready frontend interfaces...
        File: D:\vide coding projects\project1\.agents\skills\frontend-design\SKILL.md

      - pdf
        Description: Read, create, edit, and inspect PDF documents...
        File: C:\Users\...\skills\pdf\SKILL.md

      - imagegen
        Description: Generate and edit visual assets...
        File: ...
      ```
      模型看到的主要是：

      ```
      name
      description
      SKILL.md 的路径
      ```
      而不是一启动就看到所有 Skill 的完整正文。

      OpenAI把它称为“渐进式加载”：

      1. 所有 Skill 的 `name + description` 始终在上下文里；
      2. 某个 Skill 被触发后，才读取其 `SKILL.md` 正文；
      3. `references`、脚本等附加资源只有真正需要时才读取或执行。
   3. **每次提问都会重新读取文件吗？**

      **通常不会每提问一次，就重新从硬盘读取所有** **​`SKILL.md`​**​ **。**

      需要区分两个概念。

      ### 从硬盘扫描

      Codex启动或建立工作区会话时，扫描 Skill 目录，解析每个文件的：

      ```
      name
      description
      ```
      形成当前会话的 Skill 列表。

      因此新放进去一个 Skill 后，最稳妥的方法是：

      ```
      退出当前 Codex
      从正确的项目根目录重新启动
      ```
      ### 放进模型上下文

      在当前会话中，`name + description + path` 会作为可用 Skill 信息保留在上下文里。逻辑上，模型每一轮都能参考它们，但这不等于 Codex每一轮都重新打开硬盘上的全部文件。

      可以理解为：

      ```
      第一次扫描硬盘：
      把菜单抄下来

      后续每次提问：
      模型看已经抄好的菜单

      需要 frontend-design 时：
      再去打开 frontend-design/SKILL.md 看完整菜谱
      ```
      官方文档称 Skill 元数据“始终在上下文中”，并指出这些内容会与系统指令、历史对话和用户任务共同占用上下文窗口。
   4. **完整** **​`SKILL.md`​**​ **触发后会怎样？**

      例如你输入：

      ```
      使用 $frontend-design 重新设计商城首页
      ```
      Codex 大致会做：

      ```
      看到 $frontend-design
              ↓
      根据路径读取 frontend-design/SKILL.md
              ↓
      把正文加入当前任务上下文
              ↓
      按照里面的流程工作
      ```
      如果是自动触发：

      ```
      重新设计这个商城首页，让它更有辨识度，避免模板化
      ```
      模型会比较各 Skill 的 `description`​，觉得它匹配 `frontend-design` 后，再打开正文。

      完整正文一旦读入，通常会作为当前会话历史的一部分继续存在一段时间；但不能把它当成永久缓存。出现以下情况时，Codex 可能重新读取：

      - 新开会话；
      - 上下文被压缩；
      - 切换项目或工作目录；
      - 你修改了 `SKILL.md`；
      - Codex需要确认最新内容；
      - 前面的正文已经被上下文裁剪。

      所以对重要任务，显式写：

      ```
      使用 $frontend-design 完成这个页面
      ```
      比单纯依赖自动匹配更稳。
   5. **为什么 Skill 不能太多、description 不能太长？**

      因为每个 Skill 的 `name + description` 都要占用上下文。

      例如你有 100 个 Skill，每个描述都写 300 字，那么即使一个都没触发，模型开局也要先看到一大堆 Skill 元数据。

      所以合理的设计是：

      ```
      name: frontend-design
      description: Design and implement distinctive frontend interfaces. Use for websites, ecommerce pages, landing pages, dashboards, and web applications.
      ```
      不要写成几千字的功能说明。完整细节应该放在下面的正文或 `references/`​ 中。OpenAI也明确建议采用三级加载，保持 `SKILL.md` 精简，把详细资料按需拆到引用文件中。
2. 一个任务可以同时使用多个 Skill

   例如你要“重新设计商城、生成商品图、再发布网站”，可以直接写：

   ```
   使用 $frontend-design 重新设计商城界面，
   使用 $imagegen 生成需要的产品视觉素材，
   最后使用 $sites-hosting 重新发布并检查网站。
   ```
   Codex 会大致按这个顺序执行：

   ```
   读取 frontend-design/SKILL.md
           ↓
   完成页面设计和代码修改
           ↓
   读取 imagegen/SKILL.md
           ↓
   生成并接入图片
           ↓
   读取 sites-hosting/SKILL.md
           ↓
   部署并检查访问结果
   ```
   Codex 的 Skill 使用规则本身就考虑了“多个 Skill 同时适用”的情况：它会选择​**覆盖任务所需的最小 Skill 集合**，并安排使用顺序，而不是限制一轮只能用一个。

   - **​`/skills`​**​ **界面可能一次只插入一个**

     这和“任务只能使用一个”不是一回事。

     假设 `/skills` 的选择器一次只能选中一个，你可以：

     1. 先选择 `$frontend-design`；
     2. 再次打开 `/skills`​，选择 `$imagegen`；
     3. 在同一条提示词里继续输入任务。

     最终提示词类似：

     ```
     $frontend-design $imagegen

     重新设计二手 iPhone 商城首页，并生成匹配页面风格的产品主视觉。
     ```
     也可以完全不打开菜单，直接手动输入多个名称：

     ```
     使用 $frontend-design、$imagegen 和 $sites-hosting 完成商城改版、视觉素材生成和发布。
     ```
   - **自动触发也可能调用多个**

     你即使不写 `$skill-name`，只说：

     ```
     重新设计商城，生成新的产品图，完成后发布并用浏览器检查。
     ```
     模型也可能根据各 Skill 的 `description` 自动判断需要：

     ```
     frontend-design
     imagegen
     sites-hosting
     chrome
     ```
     不过自动判断不一定每次都准确。重要任务最好显式指定关键 Skill：

     ```
     使用 $frontend-design 和 $sites-hosting 完成这个任务。
     需要预览验证时可以同时使用 chrome。
     ```
   - **不要无脑把所有 Skill 都点上**

     Skill 越多不一定越好。多个 Skill 可能：

     - 提供重复流程；
     - 对设计或实现提出冲突要求；
     - 增加上下文占用；
     - 让 Codex花时间执行不必要步骤。

     比较合理的是：

     ```
     做前端页面
     → frontend-design

     做前端并生成图片
     → frontend-design + imagegen

     做完还要部署
     → frontend-design + sites-hosting

     做完、部署并实际测试
     → frontend-design + sites-hosting + chrome
     ```
3. 一个 MCP Server 里可以放很多 Tool；Codex、Claude Code 等不同 AI 客户端，只要支持 MCP，就能复用同一套 Tool。一个mcp server，里面有很多的function calling，这个mcp server可以同时支持codex，claude code之类的不同的ai。配置文件记录可以连接哪些 MCP Server；每个 Server 运行后，通过 JSON 格式的 `tools/list` 动态汇报自己有哪些 Tool，客户端再把这些 Tool 告诉模型。

   **完全正确。你现在已经抓住 MCP 最重要的价值了。**

   假设你写了一个 GitHub MCP Server，里面暴露了这些 Tool：

   ```
   GitHub MCP Server
   ├── search_repository
   ├── read_issue
   ├── create_issue
   ├── read_pull_request
   └── comment_pull_request
   ```
   然后它可以同时接给：

   ```
   Codex ───────┐
   Claude Code ─┼── MCP 协议 ── GitHub MCP Server
   Cursor ──────┤
   你自己的 Agent ─┘
   ```
   只要这些 AI 应用都是 ​**MCP Client**，并且支持这个 Server 使用的连接方式，就可以复用同一个 MCP Server。Codex 和 Claude Code 当前都支持连接 MCP Server。

   - **但有个用词需要微调**

     不是说 MCP Server 里面有很多“Function Calling”，而是：

     > MCP Server 里面暴露了很多 ​**Tools**；不同 AI 模型通过各自的 Function Calling 机制，决定调用哪个 Tool。
     >

     完整流程是：

     ```
     Claude / GPT 模型
           ↓
     模型决定调用 read_issue
           ↓
     Codex 或 Claude Code 把调用转换成 MCP 的 tools/call
           ↓
     GitHub MCP Server 执行 read_issue
           ↓
     返回结果
           ↓
     模型根据结果继续回答
     ```
     MCP 协议统一的是中间这两件事：

     ```
     tools/list：这个 Server 有哪些工具？
     tools/call：调用其中某个工具
     ```
     每个 Tool 都会提供名称、描述和参数结构。Codex 和 Claude Code读到的是同一套 MCP Tool 定义，但它们背后的模型、提示词、审批方式和 Function Calling 实现可以不同。
   - **举一个具体例子**

     这个 MCP Server 对外公布：

     ```
     {
       "name": "get_order",
       "description": "根据订单号查询订单",
       "inputSchema": {
         "type": "object",
         "properties": {
           "orderId": {
             "type": "string"
           }
         },
         "required": ["orderId"]
       }
     }
     ```
     你在 Codex 里说：

     ```
     帮我查询订单 A1024 为什么失败。
     ```
     GPT 可能决定调用：

     ```
     get_order(orderId="A1024")
     ```
     你在 Claude Code 里说同一句，Claude 也可能决定调用：

     ```
     get_order(orderId="A1024")
     ```
     两边调用的是​**同一个 MCP Tool**，只不过做决策的大模型不同：

     ```
     GPT → Codex MCP Client → get_order
     Claude → Claude Code MCP Client → get_order
     ```
   - **这就是它比平台专属插件强的地方**

     没有 MCP，你可能得分别写：

     ```
     Codex 版本的订单 Tool
     Claude Code 版本的订单 Tool
     Cursor 版本的订单 Tool
     ```
     有 MCP 后，可以写一次：

     ```
     order-mcp-server
     ```
     然后让多个兼容客户端连接。

     不过并不保证百分之百“接上就完全一样”，还要看：

     - 客户端支持哪种传输方式，例如本地 STDIO 或远程 HTTP；
     - MCP 协议版本是否兼容；
     - 身份认证如何配置；
     - 客户端是否支持 Server 提供的全部能力；
     - 各客户端的权限审批策略。

     例如一个只提供标准 Tools 的 Server，通常最容易跨客户端复用；如果使用某些较新的或实验性的 MCP 特性，部分客户端可能暂时不支持。

     最准确的总结是：

     > **MCP Server 写一次，里面提供多个 Tool；Codex、Claude Code 等 MCP Client 都可以连接它，再由各自的大模型通过 Function Calling 选择和调用这些 Tool。**
     >

     这其实很像后端写了一套标准 REST API：网页端、手机端和桌面端都能调用，只不过 MCP 是专门为 AI 客户端设计的接口规范。
4. AI 客户端先连接 MCP Server，MCP Server 告诉客户端它提供哪些“工具”；客户端调用工具后，MCP Server 再去调用背后的 API 或本地程序。MCP Server 本质上就是把服务器内部的一些能力（函数、数据库查询、API调用等）按照 MCP 协议包装成 Tools，然后把这些 Tool 的名字、描述、参数 Schema 暴露给 AI 客户端，让模型决定什么时候调用哪个，以及如何填参数。

   流程大概是：

   ```
   Codex
     |
     | 连接 MCP Server
     ↓
   GitHub MCP Server
     |
     | 返回工具列表
     ↓
   Codex 得到：
   [
     {
       name: "search_repositories",
       description: "Search GitHub repositories",
       inputSchema: {
           query: string
       }
     },
     {
       name: "get_file_contents",
       description: "Get file content",
       inputSchema: {
           owner: string,
           repo: string,
           path: string
       }
     }
   ]
   ```
   然后这些信息会进入模型上下文。

   例如用户说：

   > 帮我看看这个项目有没有数据库连接泄漏
   >

   模型看到：

   ```
   可用工具：

   get_file_contents(repo,path)
   search_code(query)
   create_issue(...)
   ```
   于是模型推理：

   ```
   我要先找数据库连接相关代码
   ↓
   调用 search_code("database connection pool")
   ↓
   拿到结果
   ↓
   调用 get_file_contents()
   ↓
   分析
   ```
   ---

   但是有一个细节：

   ### MCP 里的 Tool 不一定等于一个简单函数

   你说：

   > “其实 MCP 里包装的是服务器里一个个函数”
   >

   这个理解在概念上没问题，但是更准确：

   **MCP Tool 是一个“可调用能力描述”，服务器收到调用后，可以执行任何逻辑。**

   例如：

   ```
   @mcp.tool()
   def search_github(query):
       result = github_api.search(query)
       return result
   ```
   这确实就是包装函数。

   但是也可以：

   ```
   @mcp.tool()
   def analyze_project(repo):
       clone_repo()
       run_static_analysis()
       call_security_scanner()
       summarize_result()
       return report
   ```
   这里背后可能执行几十个函数。

   所以：

   ```
   MCP Tool
       ↓
   服务器收到请求
       ↓
   执行任意代码/API/数据库操作
       ↓
   返回结果
   ```
   模型并不知道内部怎么实现。

   ---

   你可以把 MCP Server 想成一个“远程函数仓库”。

   以前 Function Calling：

   ```
   模型
    |
    | 调用
    ↓
   你的 Python 程序里的函数
   ```
   函数就在你的应用里面。

   MCP：

   ```
   模型
    |
    | MCP协议
    ↓
   MCP Server
    |
    ↓
   里面很多函数/API/数据库操作
   ```
   函数被搬到了一个独立服务器。

   ---

   还有一个关键区别：

   传统 Function Calling：

   你要提前写：

   ```
   tools:[
    {
      name:"query_mysql",
      description:"查询数据库",
      parameters:{}
    }
   ]
   ```
   然后塞给模型。

   MCP：

   你只需要：

   ```
   连接 GitHub MCP Server
   ```
   然后：

   ```
   MCP Server:
   “我有这些工具”
   ```
   自动发现。

   所以 MCP 最大价值之一就是：

   > **工具发现（tool discovery）和标准化接入。**
   >

   ---

   最后把三者串起来：

   ```
   Skill
     |
     | 告诉 Agent 怎么完成任务
     ↓
   Agent
     |
     | 选择工具
     ↓
   MCP Tool / Function
     |
     | 发请求
     ↓
   MCP Server
     |
     | 执行内部函数/API
     ↓
   结果返回
   ```
   比如：

   “帮我修 GitHub bug”

   可能就是：

   ```
   Bug Fix Skill
          ↓
          ↓
   GitHub MCP
          ↓
   search_code()
   get_file_contents()
   create_branch()
   create_pull_request()
   ```
   所以你现在的理解已经接近 Agent 系统的真实架构了。很多人会误以为 MCP 是“AI调用API的新方式”，其实更准确的是：

   > **MCP 是让 AI 世界拥有类似操作系统驱动/USB 标准一样的外部能力连接层。**   
   > Function 是设备上的具体功能，Skill 是使用设备完成任务的方法。
   >
